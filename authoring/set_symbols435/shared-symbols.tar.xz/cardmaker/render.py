"""SWCCG card renderer: card JSON + template → PNG (1632×2220 print master, 745×1039 Holotable/GEMP).

Layout numbers come from Bardez's 600 DPI GIMP templates (wiki.swccg.com/wiki/Making_Custom_SWCCG_Cards):
the card area is 1343×1931 at (144,144) on a 1632×2220 black bleed. A Holotable image (745×1039) is that
card area at half scale with a ~37 px black border, so one render serves both.
"""
from __future__ import annotations
import base64, json, os, re, sys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
OUT = Path(os.environ.get("CARDMAKER_OUT") or ROOT / "out")
W, H = 1632, 2220
# White-border printings (Premiere Unlimited, Revised, First/Second Anthology, two-player sets): card body corner
# radius in master px, measured on Premiere Unlimited Luke Skywalker (wiki Premiere-U-L-lukeskywalker.png, ~3 px at 350).
WHITE_BORDER_RADIUS = 14
# Rev 77 printing variants. Uniqueness dot colours the spec's bullet_colour may name ("red" = as printed, the default).
BULLET_COLOURS = {"white": "#fff", "black": "#000", "red": None}
# Lando In Millennium Falcon (Enhanced Cloud City): 1 in 20 printed the forfeit box with a thicker black border
# (Collecting Encyclopedia 3.2 p.47 photo, normal and variant side by side): the variant's black box is 1.79x the white
# deploy box's width against 1.27x on the normal printing, ~12 master px more black each side; it grows up to meet the
# deploy box. The spec's forfeit_box_border (0 = as printed) adds that many px round the frame's black box; use 12.

# Template geometry (x, y, w, h) in 1632×2220 space.
TEMPLATES = {
    "ds-character-imperial": {   # #52: frame and boxes fitted to 10 PC characters (VS24-27); see STANDARD.md Rev 79
        "frame": ("frames/ds-character-imperial.png", 142, 143),
        "art": (256, 666, 1121, 770),
        "title": (404, 200, 872, 90),   # bar end kept at x 1276
        "destiny": (1316, 209, 100, 84),
        "lore": (321, 377, 989, 193),
        "stats_y": 1510,
        "stats": [(311, 251), (619, 256), (930, 396)],   # (x, width): the three black stat boxes
        "game_text": (341, 1663, 971, 333),
        "deploy": (203, 1827, 45, 83),
        "forfeit": (203, 1932, 47, 85),
        "icon_slots": [(1354, 1649), (1354, 1755), (1354, 1861)],
        "set_icon_abs": (1370, 1945),
        "expansion_ring": (1382, 410),
        "copyright_x": 1388,
        "disc_at": (195, 183), "ring_disc_dy": 6, "stat_min": (22, 14),
    },
    "ds-effect": {   # #62: frame and boxes fitted to the PC and printed Decipher effects
        "frame": ("frames/ds-effect.png", 141, 141),
        "lore_x": (319, 1270, 80, 0, 0.0), "nolore_disc": (207, 404), "title_stroke": 0.6, "ctype_size": 62, "ctype_spacing": 11.3, "set_ring": (106, 80, -26), "set_ring_w": 24, "set_digit_size": 160, "title_size": 83.4, "title_ls": 0.55, "decipher_title": (0, 1274, 1248, 140), "decipher_tone": ("dark", "effect", (125.75, 108.54, 68.6)),
        "art": (254, 663, 1118, 765),
        "title": (403, 196, 871, 100), "title_long_left": 366,   # #62: the PC's bar runs to x 1274; long titles start at 366
        "destiny": (1312, 196, 104, 104),
        "lore": (321, 374, 989, 190),
        "card_type": (265, 1506, 1109, 61),
        "game_text": (320, 1667, 1000, 328),
        "banner_icon": (1292, 1492),
        "set_icon_abs": (1397, 1954), "set_icon_size": 68,
        "expansion_ring": (1382, 406), "expansion_size": 59,
        "copyright_x": 1420, "copy_size": 25.9, "copy_ls": 0.8,
    },
    "ls-interrupt": {
        "nolore_disc": (200, 415), "margin_disc_dx": 6, "margin_disc_dy": 2, "margin_disc_hole": True, "ctype_size": 62, "ctype_spacing": 11.3, "set_ring": (106, 80, -26), "set_ring_w": 24, "set_digit_size": 160, "title_size": 83.4, "title_ls": 0.6, "frame": ("frames/ls-interrupt.png", 140, 139), "decipher_title": (-8, 1274, 1248, 140), "decipher_tone": ("light", "interrupt", (119.8, 113.53, 70.9)),
        "art": (254, 663, 1122, 754),
        "title": (408, 194, 880, 90),
        "destiny": (1316, 196, 100, 104),
        "lore": (321, 373, 1010, 180),
        "card_type": (276, 1505, 1089, 61),
        "game_text": (320, 1668, 1000, 326),
        "set_icon_abs": (1397, 1942), "set_icon_size": 68,
        "expansion_ring": (1381, 407),
        "copyright_x": 1421, "copy_size": 25.9, "copy_ls": 0.8,
        "dark_text": True,
        "lore_indent": 0,
    },
    "ls-character-alien-rebel": {   # Bardez's Multiple Affiliation frame with the Alien + Rebel discs (A New Hope Chewbacca)
        "frame": ("frames/ls-character-alien-rebel.png", 143, 143),
        "art": (259, 656, 1130, 763),
        "title": (545, 205, 780, 90),
        "destiny": (1318, 196, 108, 108),
        "lore": (300, 395, 1040, 170),
        "stats_y": 1504,
        "stats": [(300, 275), (605, 285), (930, 420)],
        "game_text": (340, 1668, 990, 326),
        "deploy": (205, 1827, 45, 78),
        "forfeit": (205, 1931, 45, 84),
        "icon_slots": [(1367, 1653), (1367, 1757)],
        "set_icon_abs": (1372, 1935),
        "expansion_ring": (1385, 404),
        "expansion_size": 68,
        "copyright_x": 1428,
        "dark_text": True,
    },
    "ls-character-alien": {
        "frame": ("frames/ls-character-alien.png", 69, 131),
        "art": (259, 656, 1130, 763),
        "title": (400, 200, 900, 90),
        "destiny": (1318, 196, 108, 108),
        "lore": (300, 380, 1040, 170),
        "stats_y": 1504,
        "stats": [(300, 275), (605, 285), (930, 420)],
        "game_text": (340, 1668, 990, 326),
        "deploy": (205, 1827, 45, 78),
        "forfeit": (205, 1931, 45, 84),
        "icon_slots": [(1367, 1653), (1367, 1757)],
        "set_icon_abs": (1372, 1935),
        "expansion_ring": (1360, 396),
        "copyright_x": 1428,
        "dark_text": True,
    },

    "ds-character-alien": {
        "frame": ("frames/ds-character-alien.png", 144, 147),
        "art": (246, 669, 1137, 770), "title": (402, 208, 884, 90), "destiny": (1311, 209, 100, 99),
        "lore": (321, 380, 989, 193), "stats_y": 1509, "stats": [(305, 252), (613, 257), (924, 397)],
        "stats_wide": (613, 708), "game_text": (341, 1666, 971, 333),
        "deploy": (205, 1824, 45, 83), "forfeit": (205, 1930, 47, 85),
        "icon_slots": [(1353, 1650), (1353, 1756), (1353, 1862)], "set_icon_abs": (1359, 1936),
        "expansion_ring": (1380, 405), "copyright_x": 1404,
    },
    "ds-character-droid": {
        "frame": ("frames/ds-character-droid.png", 144, 147),
        "art": (246, 669, 1137, 770), "title": (402, 208, 884, 90), "destiny": (1311, 209, 100, 99),
        "lore": (321, 380, 989, 193), "stats_y": 1509, "stats": [(305, 252), (613, 257), (924, 397)],
        "stats_wide": (613, 708), "game_text": (341, 1666, 971, 333),
        "deploy": (205, 1824, 45, 83), "forfeit": (205, 1930, 47, 85),
        "icon_slots": [(1353, 1650), (1353, 1756), (1353, 1862)], "set_icon_abs": (1359, 1936),
        "expansion_ring": (1380, 405), "copyright_x": 1404,
    },
    "ds-interrupt": {
        "lore_x": (319, 1270, 80, 0, 0.0), "nolore_disc": (207, 404), "expansion_size": 59, "title_stroke": 0.6, "margin_disc_dx": 6, "margin_disc_dy": 2, "margin_disc_hole": True, "ctype_size": 62, "ctype_spacing": 11.3, "set_ring": (106, 80, -26), "set_ring_w": 24, "set_digit_size": 160, "title_size": 83.4, "title_ls": 0.55, "frame": ("frames/ds-interrupt.png", 141, 141), "decipher_title": (0, 1274, 1248, 140), "decipher_tone": ("dark", "interrupt", (125.75, 108.54, 68.6)),
        "art": (245, 661, 1134, 765), "title": (404, 196, 779, 100), "destiny": (1312, 197, 102, 99),
        "lore": (316, 374, 989, 193), "card_type": (272, 1507, 1091, 61), "game_text": (316, 1666, 997, 328),
        "banner_icon": (1292, 1495), "set_icon_abs": (1397, 1954), "set_icon_size": 68, "expansion_ring": (1382, 406), "copyright_x": 1420, "copy_size": 25.9, "copy_ls": 0.8,
    },
    "ds-weapon": {
        "frame": ("frames/ds-weapon.png", 150, 148),
        "art": (251, 662, 1133, 763), "title": (405, 210, 779, 100), "destiny": (1315, 208, 100, 99),
        "lore": (324, 380, 989, 193), "card_type": (267, 1505, 1105, 61), "game_text": (318, 1669, 997, 328),
        "set_icon_abs": (1391, 1940), "set_icon_size": 64, "expansion_ring": (1380, 405), "copyright_x": 1404,
    },
    "ds-shield": {
        "frame": ("frames/ds-shield-hybrid.png", 141, 147),
        "art": (254, 663, 1118, 765), "title": (398, 200, 779, 100), "destiny": (1308, 204, 104, 104),
        "lore": (321, 378, 989, 190), "card_type": (262, 1506, 1110, 61), "game_text": (314, 1665, 997, 328),
        "banner_icon": (1292, 1492), "set_icon_abs": (1391, 1940), "set_icon_size": 64, "expansion_ring": (1374, 405), "copyright_x": 1404,
    },
    "ls-character-rebel": {   # #52: frame and boxes fitted to 10 PC characters (VS24-27); see STANDARD.md Rev 79
        "frame": ("frames/ls-character-rebel.png", 133, 139),
        "art": (259, 656, 1130, 763), "title": (410, 196, 900, 90), "destiny": (1310, 198, 108, 108),
        "lore": (300, 380, 1040, 170), "stats_y": 1502, "stats": [(296, 275), (601, 285), (926, 420)],
        "stats_wide": (601, 745), "game_text": (340, 1668, 990, 326),
        "deploy": (203, 1827, 45, 78), "forfeit": (203, 1931, 45, 84),
        "icon_slots": [(1353, 1649), (1353, 1753)], "set_icon_abs": (1367, 1941),
        "expansion_ring": (1381, 409), "copyright_x": 1415, "dark_text": True,
        "disc_at": (189, 184), "ring_disc_dy": 8,
    },
    "ls-character-droid": {
        "frame": ("frames/ls-character-droid.png", 144, 133),
        "art": (246, 659, 1139, 767), "title": (405, 193, 900, 92), "destiny": (1318, 197, 105, 105),
        "lore": (318, 367, 1047, 197), "stats_y": 1502, "stats": [(305, 260), (620, 260), (940, 400)],
        "stats_wide": (620, 720), "game_text": (354, 1660, 932, 326),
        "deploy": (201, 1832, 48, 80), "forfeit": (201, 1936, 48, 82),
        "icon_slots": [(1367, 1653), (1367, 1757)], "set_icon_abs": (1372, 1935),
        "expansion_ring": (1380, 397), "expansion_size": 70, "copyright_x": 1428, "dark_text": True, "stats_wide_fill": "#c9c9cb",
        "stats_row3": ("frames/ls-stats-row3.png", 285, 1488), "stats_row3_boxes": [(311, 269), (630, 263), (944, 403)],
    },
    "ls-shield": {
        "frame": ("frames/ls-shield-hybrid.png", 146, 141),
        "art": (244, 661, 1143, 755), "title": (401, 206, 779, 100), "destiny": (1313, 202, 104, 104),
        "lore": (320, 376, 1019, 193), "card_type": (268, 1505, 1109, 61), "game_text": (317, 1658, 997, 328),
        "banner_icon": (1292, 1492), "set_icon_abs": (1397, 1942), "set_icon_size": 60, "expansion_ring": (1381, 405), "copyright_x": 1416, "dark_text": True, "lore_indent": 0,
    },
    "ls-effect": {   # #62: frame and boxes fitted to the PC and printed Decipher effects
        "frame": ("frames/ls-effect.png", 140, 139),
        "ctype_size": 62, "ctype_spacing": 11.3, "set_ring": (106, 80, -26), "set_ring_w": 24, "set_digit_size": 160, "title_size": 83.4, "title_ls": 0.6, "decipher_title": (-8, 1274, 1248, 140), "decipher_tone": ("light", "effect", (118.8, 113.5, 70.9)),
        "margin_disc_dx": 9, "margin_disc_dy": 6, "margin_disc_hole": "#b04244", "margin_disc_hole_pad": 8, "ring_disc_dy": 6, "nolore_disc": (201, 415),
        "art": (244, 661, 1143, 755), "title": (407, 194, 867, 100), "title_long_left": 366, "destiny": (1313, 197, 104, 104),
        "lore": (320, 372, 1019, 193), "card_type": (267, 1505, 1109, 61), "game_text": (320, 1658, 997, 328),
        "banner_icon": (1292, 1492), "set_icon_abs": (1397, 1942), "set_icon_size": 68, "expansion_ring": (1381, 406), "expansion_size": 62,
        "copyright_x": 1420, "copy_size": 25.9, "copy_ls": 0.8, "dark_text": True, "lore_indent": 0,
    },
    "ls-weapon": {
        "frame": ("frames/ls-weapon.png", 146, 145),
        "art": (254, 664, 1138, 751), "title": (401, 206, 779, 100), "destiny": (1312, 205, 106, 106),
        "lore": (320, 376, 1019, 193), "card_type": (271, 1505, 1109, 61), "game_text": (320, 1658, 997, 328),
        "set_icon_abs": (1397, 1942), "set_icon_size": 60, "expansion_ring": (1381, 407), "copyright_x": 1416, "dark_text": True, "lore_indent": 0,
    },
    "ls-starship-starfighter": {   # Bardez "LS - Starship" with his starfighter type icon in the top-left ring
        "frame": ("frames/ls-starship-starfighter.png", 65, 73),
        "art": (255, 662, 1137, 709),
        "title": (398, 200, 880, 90),
        "destiny": (1321, 208, 99, 101),
        "lore": (321, 385, 1010, 185),
        "card_type": (270, 1462, 1114, 61),
        "stats_y": 1582,
        "stats": [(270, 270), (600, 340), (985, 385)],
        "game_text": (349, 1729, 982, 279),
        "deploy": (203, 1835, 59, 81),
        "forfeit": (208, 1929, 47, 85),
        "icon_slots": [(1357, 1722), (1357, 1821)],
        "set_icon_abs": (1363, 1926),
        "expansion_ring": (1381, 405),
        "copyright_x": 1416,
        "dark_text": True,
        "lore_indent": 0,
        "scomp": (184, 1694),
        "ctype_spacing": 3,
    },
    "ds-starship-starfighter": {   # Bardez "DS - Starship.xcf" frame layer + his TIE type icon; boxes measured from the frame PNG
        "frame": ("frames/ds-starship-starfighter.png", 139, 148),
        "art": (241, 667, 1134, 710),
        "title": (398, 200, 880, 90),
        "destiny": (1305, 210, 100, 100),
        "lore": (316, 390, 985, 178),
        "card_type": (262, 1462, 1100, 61),
        "stats_y": 1588,
        "stats": [(268, 262), (581, 330), (962, 381)],
        "game_text": (344, 1732, 925, 265),
        "deploy": (199, 1826, 45, 82),
        "forfeit": (199, 1932, 46, 84),
        "icon_slots": [(1356, 1722), (1356, 1822)],
        "set_icon_abs": (1363, 1926),
        "expansion_ring": (1382, 405),
        "copyright_x": 1416,
        "scomp": (170, 1694),
        "ctype_spacing": 3,
    },
    "ls-vehicle": {   # Bardez "LS - Vehicle.xcf" frame layer ("Vehicle PC"); boxes as the LS starship (same card geometry)
        "frame": ("frames/ls-vehicle.png", 145, 146),
        "art": (246, 660, 1141, 716), "title": (398, 200, 880, 90), "destiny": (1321, 208, 99, 101), "lore": (321, 385, 1010, 185),
        "card_type": (270, 1462, 1114, 61), "stats_y": 1582, "stats": [(270, 270), (600, 340), (985, 385)],
        "game_text": (349, 1729, 982, 279), "deploy": (203, 1835, 59, 81), "forfeit": (208, 1929, 47, 85),
        "icon_slots": [(1357, 1722), (1357, 1821)], "set_icon_abs": (1363, 1926), "expansion_ring": (1381, 405),
        "copyright_x": 1416, "dark_text": True, "lore_indent": 0, "scomp": (184, 1694), "ctype_spacing": 3,
    },
    "ds-vehicle": {   # Bardez "DS - Vehicle.xcf" frame layer; boxes measured from the frame PNG
        "frame": ("frames/ds-vehicle.png", 143, 147),
        "art": (245, 666, 1134, 710), "title": (398, 200, 880, 90), "destiny": (1309, 209, 100, 100), "lore": (320, 390, 985, 178),
        "card_type": (262, 1462, 1100, 61), "stats_y": 1587, "stats": [(272, 262), (585, 330), (966, 381)],
        "game_text": (348, 1731, 925, 265), "deploy": (203, 1825, 45, 82), "forfeit": (203, 1931, 46, 84),
        "icon_slots": [(1353, 1720), (1353, 1826)], "set_icon_abs": (1363, 1926), "expansion_ring": (1371, 404),
        "copyright_x": 1416, "scomp": (170, 1694), "ctype_spacing": 3,
    },
    "creature": {   # Bardez "Creature.xcf" frame layer (one frame for both sides); boxes measured from the frame PNG
        "frame": ("frames/creature.png", 145, 146),
        "art": (249, 694, 1139, 686), "title": (373, 215, 841, 80), "destiny": (1329, 215, 104, 104), "lore": (324, 420, 987, 178),
        "stats_y": 1583, "stats": [(305, 350), (706, 622)],
        "game_text": (352, 1727, 925, 270), "deploy": (208, 1827, 45, 79), "forfeit": (206, 1930, 46, 85),
        "icon_slots": [(1353, 1651), (1353, 1756)], "set_icon_abs": (1363, 1926), "expansion_ring": (1375, 400),
        "copyright_x": 1416
    },
    "objective": {   # Bardez "DS - Objective.xcf" template, recoloured to the PC two-tone purple (make_objective_frames.py); black text box, white text
        "frame": ("frames/objective.png", 67, 73),
        "art": (236, 380, 1150, 855), "title": (382, 204, 878, 95), "destiny": (1310, 204, 105, 107),
        # text box (black) 260..1377 × 1324..2003; the slip's text starts 60 px in and its longest lines run to within
        # ~10 px of the right edge (62 px AGCn, 64 px pitch), so the box reaches almost to the edge and the fitter grows to it
        "game_text": (300, 1350, 1070, 652), "gt_lh_add": 2,
        # set sphere in the purple margin at the text box's bottom-right corner, as the slip prints it (centre 39 px right
        # of the box's right edge, 7 px above its bottom; 66 px across)
        "set_icon_abs": (1384, 1964), "set_icon_size": 66,
        "copyright_x": 1416, "no_type": True, "gt_grow": True,
    },
    "objective-ls": {   # Bardez "LS - Epic Objective.xcf" frame + Objective icon, re-hued to the Endor-era purple (make_objective_frames.py)
        "frame": ("frames/objective-ls.png", 0, 0),
        "art": (246, 378, 1148, 886), "title": (382, 204, 878, 95), "destiny": (1330, 204, 111, 113),
        "game_text": (305, 1358, 1085, 646), "gt_lh_add": 2,   # text box (white) 267..1395 × 1332..2005
        "set_icon_abs": (1401, 1965), "set_icon_size": 66,
        "copyright_x": 1416, "dark_text": True, "no_type": True, "gt_grow": True,
    },
    "ls-admirals-order": {   # Bardez "LS - Admiral's Order.xcf" Template layer: title bar + black text box over full-bleed art
        "frame": ("frames/ls-admirals-order.png", 0, 0),
        "art": (146, 146, 1344, 1929), "title": (400, 206, 900, 100), "destiny": (1330, 204, 111, 110),
        "game_text": (292, 1528, 1064, 420), "gt_ink": "#fff", "fill_boxes": [(146, 2024, 1344, 56, "#000")],
        "set_icon_abs": (1430, 1972), "set_icon_size": 60, "expansion_ring": (1379, 400), "expansion_size": 70,
        "dark_text": True, "no_type": True, "no_copyright": True,
    },
    # Decipher printed both sides' Admiral's Orders in the same frame (Nothing Can Get Through Our Shield = Taking Them With Us)
    "epic-event": {   # Bardez "DS - Epic Event.xcf" (Epic Event icon + Epic Objective frame + text box), recoloured to the
        # Reflections III purple the slips print (hue .773 / sat .66 / val .45; make via make_objective_frames.recolour)
        "frame": ("frames/epic-event.png", 0, 0),
        "art": (238, 372, 1146, 866), "title": (396, 206, 880, 100), "destiny": (1310, 203, 108, 108),
        "game_text": (290, 1340, 1060, 650), "gt_ink": "#fff", "gt_grow": True,
        "set_icon_abs": (1405, 1950), "set_icon_size": 62, "expansion_ring": (1391, 376), "expansion_size": 58,   # rev 84: printed sphere centre (1420, 405), 58 px (7 Dark Epic Event scans)
        "ring_disc_left": (204, 410, 56),   # rev 84: Episode I disc in the left margin (Boonta Eve, If The Trace Was Correct, Deep Hatred)
        "copyright_x": 1404, "dark_text": False, "no_type": True, "credit_mx": (180, 1411), "credit_ink": "#000",
    },
    # printed cards with no lore box (Jedi Tests, Reflections II combo cards) carry a TALL slip (VS12 #13, #42): Bardez's
    # Epic Objective frame with the art window shortened, the slip's banner and a tall text box below it
    "ls-jeditest-tall": {
        "frame": ("frames/ls-jeditest-tall.png", 0, 0),
        "art": (240, 372, 1146, 716), "title": (396, 206, 880, 100), "destiny": (1310, 203, 108, 108),
        "card_type": (271, 1170, 1109, 61), "game_text": (300, 1318, 1040, 666), "gt_grow": True,
        "set_icon_abs": (1405, 1950), "set_icon_size": 62, "expansion_ring": (1390, 373), "expansion_size": 70,
        "copyright_x": 1404, "dark_text": True, "credit_mx": (180, 1411), "credit_ink": "#fff",
    },
    # Landscape location (site). Bardez "Location - Site.xcf": doc 2220×1632, frame layer 2073×1497 whose card
    # area (1931×1343) sits at (70,68) inside it → frame at (74,76) puts the card at (144,144) like the portraits.
    # The frame is assembled per card (force icons, packed icon boxes, scomp rings) by loc_frame().
    "loc-site": {
        "landscape": True,
        "frame_xcf": "site",
        "frame_off": (74, 76),
        "art": (262, 458, 1695, 713),              # frame hole (188,382)-(1883,1095) + offset
        "ls_bar": (527, 1224, 90),                 # x0 of the Light title bar text area, y, h (frame 453,1148)
        "ls_bar_x1": 1657,                         # bar end when no icon boxes (frame 1583)
        "dc_title_cx": 1110,                       # rev 84 (sites 2): Decipher printings centre the title on the card's centre line
        "ds_bar": (580, 313, 1112, 90),            # Dark title bar (black) x, y, w, h  (frame 506,237)
        "ls_text": (250, 1344, 1719, 86),           # the box interior (frame 1268-1352)
        "ds_text": (250, 195, 1719, 99),
        "ls_slot0": 1855, "ds_slot0": 216,          # frame x of the centre of the right-most Light / left-most Dark icon box
        "slot_y": 1155, "slot_pitch": 111,
        "ls_scomp": (1790, 1142), "ds_scomp": (181, 236),
        "ls_force": (140, 1105), "ds_force": None,  # frame coords of the light-saber glow crop (DS = rotated mirror)
        "set_icon_abs": (1984, 193),   # PC set mark: top-right (the Dark half's end), as the PC sites print it (Maz's Castle: Antechamber)
        "expansion_ring": (1991, 453), "expansion_size": 50,
        "copyright": (2002, 560, 36, 600),
        "caption_y": 1494,
    },
    # Portrait system. Bardez "Location - System.xcf": no silver frame; the scan fills the card area and the two
    # bar assemblies (layer at (235,189)) sit on top. Light half at the bottom, Dark half rotated at the top.
    "loc-system": {
        "system": True,
        "frame_png": "frames/loc-system.png", "frame_off": (235, 189),
        "art": (144, 144, 1343, 1931),
        "ls_bar": (520, 1752, 660, 86), "ds_bar": (473, 377, 638, 90),
        "ls_text": (261, 1889, 1116, 140), "ds_text": (261, 210, 1116, 139),
        "ls_icon": (1232, 1797), "ds_icon": (406, 421),          # centres of the black icon boxes
        "ls_parsec": (1298, 1752, 89, 86), "ds_parsec": (250, 380, 88, 86),
        "ls_force": (230, 1700), "ds_force": (1110, 330),
        "set_icon_abs": (1410, 225), "set_icon_size": 72,   # PC set mark: top-right margin (mirrored half of the scans)
        "system_ring": (166, 196, 56),
        "copyright_split": ((176, 1686, 36, 420), (1424, 1686, 36, 420)),   # Lucasfilm left / Decipher right margin (Dagobah)   # the printed systems' expansion sphere, top-left margin (Hoth, Bespin scans)
        "caption_y": 2082,
    },
}


# Reflections Gold "wide vision" (Decipher's cancelled last set; Bill 2026-10-15): Effects / Interrupts printed landscape,
# full art, gold credit coins right of the text box, the set's gold sphere under the destiny lobe. Frames from Bardez's
# [Horizontal] XCFs (make_rg_frames.py); text positions from Andy Talaga's reconstructions (wiki "Reflections Gold").
_RG = {"wide": True, "art": (134, 138, 1952, 1356), "title": (436, 214, 924, 115), "destiny": (1850, 216, 108, 108),
       "card_type": (1196, 242, 580, 76), "ctype_size": 64, "ctype_spacing": 3, "game_text": (330, 1162, 1585, 214),
       "gt_size": 66, "expansion_ring": (1927, 392), "expansion_size": 62, "no_copyright": True,
       "expansion_hole": ("#c0141f", 8), "ring_disc_dy": -6,   # the RG-GEMP renders set the sphere and Episode I disc in red rings (#174)
       "coins": (1938, 1386, 39), "caption_y": 1532,
       # rev 84: centres (master px) of the two halves of the copyright line in the black border, measured on the
       # playtest photos mapped to the card body (Local Trouble 1957 px: left x 114, y 177-508; right x 2116, y 185-521;
       # Strangle right y 197-523; the run is 12 % longer than our Decipher line: 31.5 px); drawn only when the card has a line (original playtest set 15o; Remastered prints none)
       "rg_copy": ((112, 352), (2116, 348)), "rg_copy_size": 31.5}
for _side, _ink in (("ls", True), ("ds", False)):
    for _kind in ("interrupt", "effect"):
        TEMPLATES[f"rg-{_side}-{_kind}"] = dict(_RG, frame=(f"frames/rg-{_side}-{_kind}.png", 0, 0), dark_text=_ink)


# rev 84 (sites 2): the PC's portrait starships (Virtual Sets), measured on Ghost, Bright Hope, Azure Angel, Booster In
# Pulsar Skate, Bravo Fighter (V), Acclamator-Class Assault Ship, Blockade Support Ship (GEMP 745 px faces): the set mark
# 8 px lower and 2 px right (digit centre (664.5, 961) at 745 with 1-2 boxes, (669, 973) under a stack of 3-4), its digit
# 34 px tall (ours 38); 3-4 icon boxes stacked up from a fixed foot as printed (pc_stack), not shrunk to fit above the mark
for _k, _dx in (("ls-starship-starfighter", 0), ("ds-starship-starfighter", -1)):   # Dark: the mark 1 px left, 4 px lower (745)
    TEMPLATES[_k].update(pc_set_icon_abs=(1368, 1942), pc_set_digit_size=127,
                         pc_stack={"bottom": 1976, "span": 356, "k": 0.955, "mark": (1377 + _dx, 1965 - 8 * _dx)})


# rev 84 (sites 2): the PC's landscape (ALT) Effects (I Must Be Allowed To Speak (V) (ALT) 200_41^ALT, Bow To The First
# Order (ALT) 204_47^ALT) on the Reflections Gold frames, measured on their printed faces (wiki V0-L- / V4-D-..._ai.gif,
# 745 px): banner smaller (cap 19 px at 745, not 22) and 18 px left (printed 652..726); game text 8 px lower (printed
# first line 557 at 745); "Original concept by ..." 19 px higher (745) and a little larger, the art credit upright; the sphere 51 px lower in its red ring (printed ring 925..961 x 183..219); the
# Episode VII disc in the left margin in a red ring (ep7-disc-red.png, as on the Finalizers); the PC set mark at the text
# box's lower right (printed "4" 937..960 x 642..675, Set 0's gold "0" in the same place); labels turned into the right
# margin as on the Finalizers
for _side in ("ls", "ds"):
    for _kind in ("interrupt", "effect"):
        TEMPLATES[f"rg-{_side}-{_kind}-pc"] = dict(TEMPLATES[f"rg-{_side}-{_kind}"], card_type=(1160, 233, 580, 76), ctype_size=55,
            game_text=(330, 1170, 1585, 214), expansion_ring=(1929, 443), expansion_size=58,
            ring_disc_left=(252, 474, 82), ring_disc_left_files={"episode7": "icons/ep7-disc-red.png"},
            set_icon_abs=(1938, 1340), set_icon_size=70, set_ring=(100, 80, -33), labels_rotated=True,
            label_presets={"art_credit": {"italic": False, "size": 51}, "concept": {"y": -196, "size": 56.5}})


# Dark Side wide weapon (Bill 2026-10-15: precedent = Maul's Double-Bladed Lightsaber, Reflections III, printed landscape)
TEMPLATES["ds-weapon-wide"] = {
    "wide": True, "frame": ("frames/ds-weapon-wide.png", 0, 0), "art": (134, 138, 1952, 1356),
    "title": (430, 222, 820, 110), "card_type": (1230, 244, 560, 64), "ctype_size": 52, "ctype_spacing": 4,
    "destiny": (1859, 225, 110, 110), "lore": (360, 404, 1480, 140), "lore_x": (360, 1840, 60, 0, 0.0),
    "game_text": (350, 1172, 1550, 196), "gt_size": 58, "expansion_ring": (1932, 418), "expansion_size": 66,
    "no_copyright": True, "caption_y": 1532, "dark_text": False,
}


# Dark Side wide capital starship (Executor, Flagship Executor, Finalizer (AI) print landscape): make_rg_frames.py starship
TEMPLATES["ds-starship-wide"] = {
    "wide": True, "frame": ("frames/ds-starship-wide.png", 0, 0), "art": (134, 138, 1952, 1356),
    "title": (442, 233, 800, 112), "card_type": (921, 239, 869, 65), "ctype_size": 50, "ctype_spacing": 3,
    "destiny": (1885, 239, 121, 118), "lore": (354, 414, 1492, 160), "lore_x": (354, 1846, 60, 0, 0.0),
    "stats_y": 1120, "stats": [(394, 316), (781, 328), (1161, 404)],
    "game_text": (382, 1238, 1648, 144), "gt_size": 56, "deploy": (257, 1238, 55, 83), "forfeit": (256, 1345, 59, 73),
    "icon_slots": [(1600, 1100), (1700, 1100), (1800, 1100), (1900, 1100)], "scomp": (196, 1100),
    "expansion_ring": (1945, 414), "expansion_size": 66, "no_copyright": True, "caption_y": 1532, "dark_text": False,
}

# rev 84 (frames): measured on the printed Executor (4_167) and Flagship Executor (9_157): the banner is set larger and
# tight (cap height 42 px, not 34; run ~865 px, centred at x 1360, 6 px lower) and the game text at the printed 62 px
# body size (two lines at a 65 px pitch; we set it at 56). The round type disc replaces Bardez's square icon crop in
# the frame (tools/fix_starship_wide_disc.py)
TEMPLATES["ds-starship-wide"].update(card_type=(900, 239, 920, 65), ctype_size=60, ctype_spacing=0.5,
    game_text=(382, 1238, 1610, 144),   # printed lines end by x 1972-1976 (ours ran to 2020, on the box's bevel)
    destiny=(1885, 227, 121, 118),      # the printed number sits centred in the circle, 12 px higher than ours
    ctype_centre_to=1845)               # banner centred between the title's end and x 1845 (Executor 1225, Flagship 1366)
TEMPLATES["ds-starship-wide"].pop("gt_size")
TEMPLATES["ds-starship-wide-nolore"] = dict(TEMPLATES["ds-starship-wide"], frame=("frames/ds-starship-wide-nolore.png", 0, 0))   # Finalizer (AI): no lore box
# rev 84 (PC wide starships): the Players Committee's landscape Finalizer and Finalizer (AI) (Virtual Set 4, both
# printed 1039 x 745) on the same frame, measured on their printed faces (wiki V4-D-finalizer.gif / _ai.gif, 745 px,
# x 2 + Holotable offset = master): banner left-set 108 px after the title's end (printed 345..837 at 745, title end 291),
# wider (ctype_spacing 3) and 6 px higher; title 8 px left; Episode VII disc in the left margin (centre (252, 476), 76 px:
# the scan's own ring), not in the sphere ring; the Virtual Set 4 mark after the icon boxes (printed ring centre
# (1948, 1152)); labels (caption, (AI) stamp, art credit) turned a quarter left into the right margin, the credit upright
for _k in ("ds-starship-wide", "ds-starship-wide-nolore"):
    TEMPLATES[_k + "-pc"] = dict(TEMPLATES[_k], ctype_centre_to=None, ctype_after_title=108, ctype_spacing=0.95,
                                 card_type=(900, 233, 1100, 65), title=(434, 219, 800, 112),
                                 ring_disc_left=(252, 476, 82), ring_disc_left_files={"episode7": "icons/ep7-disc-blue.png"}, set_icon_abs=(1916, 1104), set_icon_size=70, set_ring=(100, 80, -33),
                                 icon_slots=[(x - 6, y + 10) for x, y in TEMPLATES[_k]["icon_slots"]],
                                 labels_rotated=True, label_presets={"art_credit": {"italic": False, "size": 51}})   # credit upright, 231 px long at 745
# Decipher's printed creatures (Worrt, Bog-wing): black title and the banner (GUARD CREATURE) — card maker; the VS
# remasters keep "creature" as approved (white title, empty banner)
TEMPLATES["creature-dc"] = dict(TEMPLATES["creature"], card_type=(271, 1466, 1109, 61), title_ink="#000", ctype_ink="#000")
# rev 84 (frames): measured on the printed creatures (Bog-wing, Bubo, Worrt, Rancor, Sarlacc, Dragonsnake; card body
# registered to the master): the frame itself matches print within 2 px, but the title starts 29 px further right and
# 5 px higher; the lore is set flush left (no first-line indent) from x 318 to ~1294 at its 60 px pitch, first line
# 8 px higher; the banner is set tight (cap height 39 px, not 43; tracking ~3.6 px, not 11: AVIAN CREATURE 353 px wide,
# GIGANTIC PREDATOR CREATURE 653) and 11 px higher; the creature icon box sits beside the text box top (centre
# (1402, 1758), not (1398, 1694))
TEMPLATES["creature-dc-pc"] = dict(TEMPLATES["creature-dc"])   # Players Committee creatures (Porg): kept as before rev 84
TEMPLATES["creature-dc"].update(
    title=(402, 210, 812, 80), lore=(318, 410, 990, 196), lore_x=(318, 1300, 0, 0, 0.0),
    card_type=(271, 1458, 1109, 61), ctype_size=54.5, ctype_spacing=3.2, ctype_stroke=1.4,   # heavy, as the stat labels
    stat_val_gap=19,   # FLIGHT 2, ARMORED HIDE 5: the value 19 px after the label (30 elsewhere)
    icon_slots=[(1357, 1715), (1357, 1820)])


def is_wide(t: dict) -> bool:
    """Landscape canvas (2220x1632): locations (site) and the Reflections Gold wide cards."""
    return bool(t.get("landscape") or t.get("wide"))


# Optional era templates (Bill 2026-10-13): the red→cyan fade the Original Virtual Remaster slips used for Defensive
# Shields (make_shield_fade.py). The hybrid (hard cut) above stays the primary shield template; a card opts in with
# "shield_style": "fade" (build_vs.py sets it for the Original Virtual sets).
# the Light Effect boxes as they were before #62 (Rev 68): the templates built from them keep them until their own Stories
_LS_EFFECT_PRE62 = {
    "art": (244, 661, 1143, 755), "title": (401, 206, 779, 100), "destiny": (1313, 202, 104, 104),
    "lore": (320, 376, 1019, 193), "card_type": (271, 1505, 1109, 61), "game_text": (311, 1656, 1019, 330),
    "banner_icon": (1292, 1492), "set_icon_abs": (1397, 1942), "set_icon_size": 60, "expansion_ring": (1378, 410), "expansion_size": 70,
    "copyright_x": 1416, "dark_text": True, "lore_indent": 0,
}
_EFFECT_PRE62 = {"ls": {"card_type": (271, 1505, 1109, 61), "set_icon_abs": (1397, 1942)},
                 "ds": {"card_type": (271, 1508, 1109, 61), "set_icon_abs": (1391, 1940)}}
TEMPLATES["ls-jeditest-epic"] = dict(_LS_EFFECT_PRE62, frame=("frames/ls-jeditest-epic.png", 0, 0))   # Jedi Test frame (olive) with the slip's purple Epic Event foot
# Light Epic Events (Attack Run, Boonta Eve Podrace) print on the Light Objective frame with the Epic Event disc
# printed Objectives carry the expansion sphere right of the art, under the destiny (Rev 77 sphere): measured on 20 printed
# Light and 10 Dark scans (SE, Endor, DSII, R2, Coruscant, R3, Theed, Enhanced CC / JP, both faces): Light centre at
# 745-px (678.5, 159.5) = master (1427, 391), Dark (676, 166) = (1422, 404), ~29 px across incl. its black ring = 58 master;
# clear of the destiny circle (the old (1412, 295) 70-px sphere sat on it). Light Epic Events share it (Attack Run, Deactivate)
for _k, _xy in (("objective-ls", (1398, 362)), ("objective", (1393, 375))):
    TEMPLATES[_k].setdefault("expansion_ring", _xy); TEMPLATES[_k].setdefault("expansion_size", 58)
# rev 84: printed Episode I-era Objectives and Epic Events (Theed Palace, Coruscant, Tatooine, Reflections III and the
# PC's Virtual ones) carry the Episode I (or VII) disc in the LEFT margin under the card-type disc, not under the sphere:
# measured on 18 faces (half-level edge, 745 px): centre x 67.2, Light y 163 / Dark y 168.5, ~28 px across = master
# (205, 397) Light, (204, 410) Dark, 56 px. Epic Events of both sides print it at the same spot as the Objectives.
TEMPLATES["objective-ls"]["ring_disc_left"] = (205, 397, 56)
TEMPLATES["objective"]["ring_disc_left"] = (204, 410, 56)
# rev 84 (frames): Decipher's printed Jedi Test frame (Dagobah #1-#5, Death Star II #6; the PC's It Is The Future You See
# (V) prints it too), rebuilt from the six printed faces by tools/make_jeditest_frame.py: silver title bar bulging round
# the stone disc and the destiny circle, olive paint chipped to silver in the margins, window 243..1386 x 387..1107,
# banner 1160..1258, text box 1290..2015. Text measured on the faces: left edge 310, first line 1318, a fixed 57.3 px
# pitch on every card (Decipher did not grow or shrink it: Domain Of Evil leaves the box's foot empty)
TEMPLATES["ls-jeditest-olive"] = dict(TEMPLATES["ls-jeditest-tall"], frame=("frames/ls-jeditest-olive.png", 0, 0),
    art=(243, 387, 1144, 721), title=(405, 196, 880, 100), destiny=(1308, 201, 104, 104),
    card_type=(262, 1178, 1110, 61), game_text=(308, 1306, 1046, 684), gt_size=60, gt_lh_add=-2.7, gt_grow=False)
TEMPLATES["ls-epic-event"] = dict(TEMPLATES["objective-ls"], frame=("frames/ls-epic-event.png", 0, 0))
# Virtual Block Missions (make_mission_frames.py): full art under the Admiral's Order title bar, tan panel at the foot
for _sd, _D in (("ls", 324), ("ds", 336)):
    _e = dict(TEMPLATES[f"{_sd}-effect"], **_EFFECT_PRE62[_sd]); _P = 1080
    TEMPLATES[f"{_sd}-mission"] = dict(TEMPLATES["ls-admirals-order"], frame=(f"frames/{_sd}-mission.png", 0, 0),
        art=(146, 146, 1344, _P + 40 - 146), card_type=(_e["card_type"][0], _e["card_type"][1] - _D) + _e["card_type"][2:],
        game_text=(_e["game_text"][0], _e["game_text"][1] - _D, _e["game_text"][2], _e["game_text"][3] + _D),
        set_icon_abs=_e["set_icon_abs"], no_type=False)
    TEMPLATES[f"{_sd}-mission"].pop("gt_ink", None)
    # rev 73 (tools/legacy/refit_mission_frames.py): banner and text box where the PC prints them (banner Light
    # 1124-1218 / Dark 1084-1190, text box from 1240 / 1252); the banner's right end holds the Setup / faction icon
    # (In The Hands Of The ISB, Kessel Run (V), Hunt Down The Dark Acolyte), measured by template match on the PC gifs
    _m = TEMPLATES[f"{_sd}-mission"]; _ct, _gt = _m["card_type"], _m["game_text"]
    _dc, _dg = (40, 69) if _sd == "ls" else (74, 70)
    _m["card_type"] = (_ct[0], _ct[1] - _dc) + _ct[2:]
    _m["game_text"] = (_gt[0], _gt[1] - _dg, _gt[2], _gt[3] + _dg)
    _m["banner_icon"] = (1274, 1118) if _sd == "ls" else (1314, 1086)
    _m["banner_icon_size"] = 106
    if _sd == "ds":
        _m["game_text"] = _m["game_text"][:2] + (_m["game_text"][2] + 30, _m["game_text"][3])   # box widened 30 px (refit)
    _m["mission_disc"] = (207, 1291) if _sd == "ls" else (189, 1267)   # Objective disc left of the text box (Rebel / Imperial Aces)
    if _sd == "ds":
        TEMPLATES["ds-mission"].pop("dark_text", None); TEMPLATES["ds-mission"]["ctype_ink"] = TEMPLATES["ds-mission"]["title_ink"] = "#000"
    TEMPLATES[f"{_sd}-mission"]["ctype_ink"] = "#322d33" if _sd == "ls" else "#504b49"   # rev 73: grey MISSION ink as printed
# rev 73: Rise Of The Dark Lord (Virtual Block 7) prints its Setup icon in the right margin at the text box top
# (PC gif: 47 px box at (664, 623) of 745 px); the template had no place for it. Only cards with a Setup icon draw it.
TEMPLATES["epic-event"]["banner_icon"] = (1398, 1318)
TEMPLATES["epic-event"]["banner_icon_size"] = 94
TEMPLATES["game-aid-chart"] = {"chart": True, "frame": ("frames/game-aid.png", 0, 0), "art": (144, 144, 1343, 1931),
    "title": (300, 230, 1030, 190), "game_text": (250, 480, 1200, 1430), "set_icon_abs": (1340, 1950), "set_icon_size": 70,
    "dark_text": False, "no_type": True, "no_copyright": True}
TEMPLATES["ds-admirals-order"] = dict(TEMPLATES["ls-admirals-order"])   # Decipher printed both sides' Admiral's Orders in one frame
# Decipher's own Defensive Shield frames (all-cyan Light / its Dark twin, shield icon) for the card maker's printed cards
TEMPLATES["ls-shield-dc"] = dict(TEMPLATES["ls-shield"], frame=("frames/ls-shield.png", 148, 142))
TEMPLATES["ds-shield-dc"] = dict(TEMPLATES["ds-shield"], frame=("frames/ds-shield.png", 144, 146))
# Devices (card maker): the weapon frames with Bardez's Device type icon (DS / LS - Device.xcf) — Deflector Shield Generators
TEMPLATES["ds-device"] = dict(TEMPLATES["ds-weapon"], frame=("frames/ds-device.png",) + TEMPLATES["ds-weapon"]["frame"][1:])
# LS Device (Bill 2026-11-01): its own frame, Bardez "LS - Device.xcf" layer 11 (the Gigapixel frame with the Device icon), cropped
# to its bbox at (145,145). It used to be the LS Weapon frame with the icon swapped, which carried the Weapon-only bolts under the
# icon and the burn mark left of the lore box (Decipher prints those on LS Weapons, never on Devices). Art box = the frame's window.
TEMPLATES["ls-device"] = dict(TEMPLATES["ls-weapon"], frame=("frames/ls-device.png", 145, 145), art=(248, 665, 1136, 752),
                              # game text box as wide as the PC sets it: their LS Device lines run to x≈1341 (Obi-Wan's Journal
                              # Errata; Han's Medal, Jedi Holocron, Cyborg Construct to 1325-1331), 47 px inside the plate's edge
                              game_text=(320, 1658, 1020, 328))
TEMPLATES["ds-shield-fade"] = dict(TEMPLATES["ds-shield"], frame=("frames/ds-shield-fade.png", 0, 0))
TEMPLATES["ls-shield-fade"] = dict(TEMPLATES["ls-shield"], frame=("frames/ls-shield-fade.png", 0, 0))
# Virtual Block Dark shields (No Escape (V)): Decipher's Dark shield frame, cyan fading to red at the foot
# Decipher's printed Light droid disc is brass-gold (2X-3KPR, C-3PO); Bardez's frame has it copper
TEMPLATES["ls-character-droid-dc"] = dict(TEMPLATES["ls-character-droid"], frame=("frames/ls-character-droid-dc.png",) + TEMPLATES["ls-character-droid"]["frame"][1:])
TEMPLATES["ds-character-droid-dc"] = dict(TEMPLATES["ds-character-droid"], frame=("frames/ds-character-droid-dc.png",) + TEMPLATES["ds-character-droid"]["frame"][1:])
TEMPLATES["ds-shield-vb"] = dict(TEMPLATES["ds-shield-dc"], frame=("frames/ds-shield-vb.png",) + TEMPLATES["ds-shield-dc"]["frame"][1:])

# Game text boxes measured from the PC's own faces (Bill 2026-11-01): text extents of 4-14 Holotable gifs per template from
# Virtual Sets 0-27 (the leftmost glyph, the longest line + 2 px, the first line's cap top), converted to the 1632 px master.
# The PC sets every one of them at 62 px on 64 px lines (32 px pitch at 745) and makes long text fit by rewording, not by
# shrinking; Decipher's printed cards use the same boxes. Variants on the same plate (shields, -dc, -fade, -vb) share the box.
# Measurement script and table: cm-lsdevice/ts (many.py, measure.py). ds-effect-tall, Jedi Tests, Epic Events and Objectives
# had too few PC samples and keep their boxes (Epic Event: shifted to the PC's left edge).
GT_BOX_PC = {
    "creature": (338, 1727, 952, 270),
    "creature-dc": (338, 1727, 952, 270),
    "creature-dc-pc": (338, 1727, 952, 270),
    "ds-character-alien": (353, 1663, 951, 336),
    "ds-character-droid": (353, 1663, 945, 336),
    "ds-character-droid-dc": (353, 1663, 945, 336),
    "ds-character-imperial": (354, 1662, 942, 334),
    "ds-device": (313, 1663, 1015, 334),
    "ds-effect": (314, 1664, 1020, 335),   # #62: line tops 1 px low against the PC and printed
    "ds-interrupt": (315, 1663, 1011, 329),   # #63: text 1 px low against the PC
    "ds-shield": (314, 1660, 1020, 335),
    "ds-shield-dc": (314, 1660, 1020, 335),
    "ds-shield-fade": (314, 1660, 1020, 335),
    "ds-shield-vb": (314, 1660, 1020, 335),
    "ds-starship-starfighter": (354, 1726, 928, 271),
    "ds-vehicle": (354, 1726, 932, 270),
    "ds-weapon": (314, 1663, 1014, 334),
    "epic-event": (304, 1332, 1060, 676),   # PC Epic Events print 10-11 lines down to y 1998
    "ls-character-alien": (354, 1659, 956, 335),
    "ls-character-alien-rebel": (351, 1660, 957, 334),
    "ls-character-droid": (354, 1661, 946, 326),
    "ls-character-droid-dc": (354, 1661, 946, 326),
    "ls-character-rebel": (353, 1658, 953, 336),
    "ls-device": (312, 1655, 1018, 331),
    "ls-effect": (311, 1654, 1019, 330),   # #62
    "ls-interrupt": (312, 1654, 1022, 333),   # #63: text 3.5 px low against the PC
    "ls-jeditest-epic": (311, 1656, 1019, 330),
    "ls-shield": (311, 1656, 1019, 330),
    "ls-shield-dc": (311, 1656, 1019, 330),
    "ls-shield-fade": (311, 1656, 1019, 330),
    "ls-starship-starfighter": (346, 1720, 998, 288),
    "ls-vehicle": (345, 1719, 999, 289),
    "ls-weapon": (312, 1655, 1018, 331),
}
for _k, _b in GT_BOX_PC.items():
    if _k in TEMPLATES:
        TEMPLATES[_k] = dict(TEMPLATES[_k], game_text=_b)
# #62: the PC's no-lore Effects (Begin Landing Your Troops & Fighters Straight Ahead, Steady, Steady & Bargaining Table,
# the VB4 There Is No Try & Oppressive Enforcement slip) print the Effect frame itself, lore window merged into the art
# window (grown_frame), banner and text box raised by NOLORE_GROW. ds-effect-tall was a fixed full-card frame whose
# banner sat 30 px (745) higher than the PC's; the Light ones were built on Bardez's recoloured Epic Objective top.
NOLORE_GROW = 276   # master px; Light and Dark Effect and Interrupt combos (banner and text 7 px (745) low with 290)
TEMPLATES["ds-effect-tall"] = dict(TEMPLATES["ds-effect"], nolore_grow=NOLORE_GROW)
# rev 84: the window corners, sphere and copyright line of the no-lore combos (Reflections II, Coruscant and the PC's
# reissues) as printed — see COMBO_CORNERS / combo_corners()
for _k, _c in (("ls-effect", "light"), ("ls-interrupt", "light"), ("ds-effect", "dark"), ("ds-interrupt", "dark"), ("ds-effect-tall", "dark")):
    TEMPLATES[_k] = dict(TEMPLATES[_k], combo_corners=_c)

ICON_FILES = {
    # column icons: the PC's own Game Aid icons, frame included (COL_ prefix = drawn without the Bardez icon box)
    "pilot": "icons/col-pilot-dark.png", "warrior": "icons/col-warrior.png", "pilot-light": "icons/col-pilot-light.png", "warrior-light": "icons/col-warrior.png",
    "alter": "icons/VS-icon-immune-alter.png", "control": "icons/VS-icon-immune-control.png",
    "sense": "icons/VS-icon-immune-sense.png", 
    "grabber": "icons/grabber-fist.png", "pilotpower": "icons/VS-icon-pilot-power-x.png", "pilotpower-dark": "icons/VS-icon-pilot-power-x-dark.png",
    "lightsaber": "icons/inline-permanent-weapon.png", "permanent-weapon": "icons/inline-permanent-weapon.png",
    "republic": "icons/col-republic.png", "republic-square": "icons/inline-republic-square.png", "maintenance": "icons/inline-maintenance.png", "nav": "icons/inline-nav.png",
    "astromech": "icons/astromech-bardez.png",
    "independent": "icons/inline-independent.png", "presence": "icons/col-presence.png",
    "republic-crest": "icons/inline-republic-crest.png",
    "ds2": "icons/set-ds2-decipher.png",   # Death Star II icon in the column (Luke Skywalker, Rebel Scout (V))
    "light-force": "icons/inline-force-light.png", "dark-force": "icons/inline-force-dark.png",   # Game Aid g036 / g050 (Imperial Decree (V))
    "episode1": "icons/inline-episode1.png",   # Game Aid g033 (Hopping Mad (V): "non-[Episode I] C-3PO")   # the Republic affiliation icon itself (The Emperor (V): "Gains [Republic] at opponent's Senate")   # Presence = Game Aid g013 (droid on red), as on IG-88
    "permanent-pilot": "icons/col-pilot-dark.png", "permanent-pilot-light": "icons/col-pilot-light.png",   # same helmet icon as Pilot on the printed cards
    # Players Committee column icons (framed): wiki 180 px / PC Game Aid sheet (Feb 2024) / cut from PC scans (Bill 2026-10-15)
    "selective-creature": "icons/col-selective-creature.png", "independent-starship": "icons/col-independent-starship.png",
    "trade-federation": "icons/col-trade-federation.png", "clone-army": "icons/col-clone-army.png",
    "separatist": "icons/col-separatist.png", "resistance": "icons/col-resistance.png", "first-order": "icons/col-first-order.png",
    "vader": "icons/col-vader.png", "setup": "icons/col-setup.png",
}
# rev 84 (sites 2): icons whose box is printed differently from the in-text icon: the Nav Computer box as printed (red field
# to a thin silver rim, tools/make_col_nav.py), not the in-text icon (grey inner frame) inside icon-box.png
BOX_ICON_FILES = {"nav": "icons/col-nav.png"}
RING_DISCS = {   # discs printed under the expansion sphere (or in its place when the card has none)
    "episode1": "icons/ep1-disc.png", "episode7": "icons/ep7-disc.png",
    "sidious": "icons/disc-sidious.png", "skywalker": "icons/disc-skywalker.png",
    "personal-force": "icons/disc-personal-force.png",   # #62: drawn by make_personal_force.py from the PC's Commando Training (V)
}
MARGIN_DISCS = ("sidious", "skywalker", "personal-force")   # printed in the right margin at the text box top, stacked downward


# lore typography (Bill 2026-10-13: lore must break and weigh as on the printed card) — tuned on printed 745 px scans
LORE_CSS = {"ff": "AGLightCn", "fs": 58, "ls": 0.25, "lh": 60, "pt": 4, "ind": 60}
# where the printed lore text starts and how far right it may run (card px), measured on 46 printed 745 px scans:
# Dark frames' lore window runs to x≈1349, Light ones' to ≈1366–1378; text starts at x≈319 (Dark) / 326 (Light)
# fitted (fit on 26 Dark / 21 Light printed cards: line counts and line ends): (text left, right limit, first-line
# indent, first-line cut for the window's bevelled corner, tracking)
LORE_X = {"Dark": (319, 1270, 90, 0, 0.0), "Light": (326, 1290, 75, 40, 0.0)}   # 16/26 Dark, 17/21 Light exact

# Rev 84 (Decipher text setting): game text and lore as Decipher set them on its own printings (card "decipher_print").
# Measured on printed faces (wiki hires scans 1497 px, Decipher archive / web scans 350-367 px; the wiki's 745 px gifs of
# Decipher cards are the PC's errata re-renders and were left out), registered to our renders by the card body:
# x-height = ours (game text 32 px at 62, lore 30 px at 58), so the size stays; the glyphs are WIDER than Holotable Text
# (printed line ink width / our advance width at tracking 0: game text 1.026, lore 1.044 on the hires faces), so the box is
# set at width / k and stretched by k (scaleX), which wraps and inks like the wider face; tracking 0 (ours: -0.4 / +0.25);
# line pitch 63.5 (game text, 29 faces 63.0-64.5) and 60.5 (lore, 20 faces); 3-line lore keeps its pitch (the box grows to
# min_h instead of the fitter tightening it to 54). The right edge ("dw", added to the box width before the stretch) was fitted
# on the printed line breaks of 56 text blocks (sim over the measure): characters -18, Effects / Interrupts of Premiere and
# A New Hope -33 (their printed lines are a word shorter than Hoth's onward), others 0; lore Dark -3, Light +21.
DC_TEXT_FAMILY = re.compile(r"^(ls|ds)-(character|effect|interrupt|weapon|device|starship-starfighter|vehicle|shield-dc|admirals-order)(-(?!wide)[a-z-]+)?$"
                            r"|^creature(-dc)?$|^objective(-ls)?$|^ls-jeditest-olive$")
# Rev 84 (2): per-template Decipher settings where the print differs from the family above (measured on printed faces:
# Objectives both faces 8, Jedi Tests 5 incl. the 1497 px A Jedi's Strength, Defensive Shields 6 and Admiral's Orders 5
# take the family values). "size" = the box's starting size (the fitter only shrinks: Decipher's Objectives fill to 62).
DC_TPL = {"objective": {"size": 62, "lh": 63.5}, "objective-ls": {"size": 62, "lh": 63.5},
          "ls-jeditest-olive": {"size": 58.5, "lh": 58.4, "dw": -16},
          "ls-admirals-order": {"dw": -36, "lh": 64.5, "dh": 45}, "ds-admirals-order": {"dw": -36, "lh": 64.5, "dh": 45}}
DC_TEXT = {"gt": {"k": 1.026, "lh": 63.5, "dy": 1, "dw": {"character": -18, "early": -33}, "stroke": {"Light": 0.2, "Dark": -0.5}},
           "lore": {"k": 1.044, "lh": 60.5, "x": 317, "indent": 75, "dw": {"Dark": -6, "Light": 6}, "min_h": 187,
                    "stroke": {"Light": 0.3, "Dark": -0.35}}}
DC_EARLY = ("Premiere", "A New Hope")   # sets whose Effects / Interrupts print the narrower measure
# rev 84 (3): Reflections II's combo Effects / Interrupts (tall text box, no lore) set a wider measure: printed lines run
# to x 1337-1349 (ours 1315-1326) on 15 faces; fitted on their printed breaks: +32 px
DC_WIDE = {"Reflections II": 32}
# Ink weight: printed black text (Light cards) is heavier than Holotable Text and printed white text (Dark cards, reversed
# out of black) lighter: ink coverage printed / ours 1.04-1.08 (game text) and 1.15 (lore) on Light, 0.83-0.88 / 0.77-0.90
# on Dark (7 hires faces). "stroke" (master px): > 0 = a text-stroke in the text colour, < 0 = in the box's black (thins).


def dc_stroke(card: dict, t: dict, box: str) -> str:
    white = (t.get("gt_ink") or ("#000" if t.get("dark_text") else "#fff")).lower() in ("#fff", "#ffffff") if box == "gt" else not t.get("dark_text")
    s = DC_TEXT[box]["stroke"]["Dark" if white else "Light"]
    return f"-webkit-text-stroke:{abs(s)}px {'currentColor' if s > 0 else '#000'}"


def dc_text(card: dict, t: dict) -> bool:
    """Rev 84: set this card's game text and lore the way Decipher set them (its own printings only)."""
    return bool(card.get("decipher_print") and DC_TEXT_FAMILY.match(card.get("template", "")) and not card.get("pc_type")
                and card.get("lang") != "ja" and not t.get("landscape") and not t.get("chart")
                and (not t.get("gt_grow") or card.get("template") in DC_TPL))


def _dc_key(tok: str) -> str:
    w = "".join(_pc_words(tok))
    return w if w else (tok if tok in ("+", "=", "<", ">", "–", "-", "−", "&") else "")


def dc_hint(text: str, card: dict, key: str, fallback=None) -> tuple:
    """Rev 84 (2): the printed card's own line breaks (card "dc_lines", adapter.decipher_lines) -> (text with U+2029
    at each printed line start, extra CSS). The words (and signs such as + or =, which may open or close a printed
    line) must match the text's; otherwise the text is set normally. With the printed breaks the lines do not re-wrap
    (nowrap): a line Decipher tracked tighter than the measure makes the fitter tighten the tracking, as Decipher did."""
    dl = card.get("dc_lines") or {}
    cands = [dl.get(key) or fallback] + ([dl.get("game_text_back")] if key == "game_text" else [])
    toks = re.split(r"([ \t]+|¶|\n)", text)
    keys = [(i, _dc_key(x)) for i, x in enumerate(toks) if x and not x.isspace() and x not in "¶\n"]
    keys = [(i, k) for i, k in keys if k]
    for lines in cands:
        if not lines or len(lines) < 2:
            continue
        # flat printed keys: [key, opens a line, breaks inside the word after its hyphen ("non-" / "frozen")]
        flat, carry = [], None
        for l in lines:
            ws = l.split()
            first = True
            if carry is not None and ws:
                w0 = ws.pop(0); flat[carry][0] = _dc_key(flat[carry][3] + w0); flat[carry][2] = True; first = False
            carry = None
            for j, x in enumerate(ws):
                k = _dc_key(x)
                if not k:
                    continue
                flat.append([k, first, False, x]); first = False
                if j == len(ws) - 1 and x.endswith("-") and len(x) > 1:
                    carry = len(flat) - 1
        if [f[0] for f in flat] != [k for _, k in keys]:
            continue
        starts = {keys[n][0] for n, f in enumerate(flat) if f[1] and n > 0}
        inner = {keys[n][0] for n, f in enumerate(flat) if f[2]}
        out = []
        for i, x in enumerate(toks):
            if i in starts:   # this token opens a printed line: the run of spaces / paragraph marks before it becomes the break
                while out and (not out[-1] or out[-1].isspace() or out[-1] in ("¶", "\n")):
                    out.pop()
                out.append("\u2029")
            elif x in ("¶", "\n"):
                x = " "   # Decipher ran USED: / LOST: on where its lines say so
            if i in inner and "-" in x:   # Decipher broke this word at its hyphen
                x = x.replace("-", "-\u2029", 1)
            out.append(x)
        return "".join(out), ";white-space:nowrap"
    return text, ""


_DC_TOKEN = re.compile(r"(?<![\w’'/-])([\w’']+(?:[-/][\w’']+)+)(?![\w’'])")


def _dc_designation(tok: str) -> bool:
    parts = [p for p in re.split(r"[-/]", tok) if p]
    return (any(re.search(r"\d", p) or len(p) == 1 or (p.isupper() and len(p) > 1) for p in parts)
            or ("/" in tok) or all(p[:1].isupper() for p in parts))


def dc_nobreak(html: str) -> str:
    """Rev 84 (4): Decipher never breaks inside a hyphenated designation or name (Z-95, X-wing, B-wing, R2-D2, 2-1B,
    TIE/ln, AT-AT, Obi-Wan): 0 of 58 hyphenated words on 746 printed lines; it does break ordinary compounds at the
    hyphen (A Jedi Test's "upside-" / "down", "non-" / "unique"). The PC breaks inside names too (R2- / D2, Obi- / Wan
    on its Virtual Legacy slips), so this applies to Decipher's setting only. Text outside tags only."""
    out = []
    for part in re.split(r"(<[^>]*>)", html):
        if part.startswith("<"):
            out.append(part)
        else:
            out.append(_DC_TOKEN.sub(lambda m: f'<span style="white-space:nowrap">{m.group(1)}</span>' if _dc_designation(m.group(1)) else m.group(1), part))
    return "".join(out)


def dc_gt_box(card: dict, t: dict) -> str:
    """The game text box's style under dc_text: measure / k, stretched by k, Decipher's pitch and tracking."""
    p = DC_TEXT["gt"]; x, y, w, h = t["game_text"]; tpl = card.get("template", "")
    o = DC_TPL.get(tpl, {})
    dw = o.get("dw", p["dw"]["character"] if "-character" in tpl else
               p["dw"]["early"] if re.search(r"-(effect|interrupt)", tpl) and card.get("dc_expansion") in DC_EARLY else
               DC_WIDE.get(card.get("dc_expansion"), 0) if re.search(r"-(effect|interrupt)", tpl) else 0)
    k = p["k"]; fs = f"font-size:{o['size']}px;" if o.get("size") else ""
    h += o.get("dh", 0)   # Admiral's Orders print seven lines at full pitch, 45 px further down than the PC's box
    return (f"left:{x}px;top:{y + p['dy']}px;width:{(w + dw) / k:.2f}px;height:{h - p['dy']}px;transform:scaleX({k});"
            f"transform-origin:left top;{fs}letter-spacing:0px;line-height:{o.get('lh', p['lh'])}px;{dc_stroke(card, t, 'gt')}")

_EDGE_CACHE: dict = {}


def stat_boxes(t: dict, n: int):
    """The stat boxes' interiors (x, width) as painted in the template's frame, measured on a row through their middle
    (Bill 2026-10-13: the text must sit in the printed boxes as on the Decipher cards). Dark frames: black wells;
    Light frames: grey wells right of a dark bevel. Falls back to the template's own numbers."""
    key = (t["frame"], t["stats_y"])
    if key not in _EDGE_CACHE:
        fr, fx, fy = t["frame"]
        c = Image.new("RGBA", (1632, 2220), (0, 0, 0, 255)); c.alpha_composite(Image.open(ASSETS / fr).convert("RGBA"), (fx, fy))
        import numpy as np
        a = np.array(c.convert("L")).astype(int)
        y = t["stats_y"] + 34
        row = a[y - 4:y + 5].mean(0)
        boxes = []
        if row[t["stats"][0][0] + 40] < 40:          # dark wells
            run = None
            for x in range(200, 1450):
                if row[x] < 30 and run is None: run = x
                if row[x] >= 30 and run is not None:
                    if x - run > 120: boxes.append((run, x - run))
                    run = None
        else:                                        # light wells: grey run (150–215) after a dark bevel (< 150)
            x = 200
            while x < 1430:
                if row[x] < 150:
                    j = x
                    while j < 1430 and row[j] < 160: j += 1
                    k = j
                    while k < 1450 and (150 <= row[k] <= 215 or (k + 6 < 1450 and (150 <= row[k + 6] <= 215))): k += 1
                    if k - j > 120:
                        boxes.append((j, k - j)); x = k; continue
                    x = j
                x += 1
        _EDGE_CACHE[key] = boxes if len(boxes) >= 2 else None
    b = _EDGE_CACHE[key]
    return b[:n] if b and len(b) >= n else None


def data_uri(path: Path) -> str:
    mime = "font/otf" if path.suffix == ".otf" else "font/ttf" if path.suffix == ".ttf" else "image/png" if path.suffix == ".png" else "image/gif"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode()


def icon_img(name: str, h: int = 64) -> str:
    f = (dc_inline(name) or ICON_FILES[name])
    if name == "episode1" and not card_ctx.get("lang") == "ja":
        if card_ctx.get("decipher_print") and not card_ctx.get("_pc_icons"):
            # rev 84 (inline icons 2): Decipher printed its own Episode I disc inline (tall I, dim EPISODE; We Have A
            # Plan 14_52, Jedi Council Summons 12_55, My Lord, Is That Legal? 12_179 hires) with a thin light ring on its
            # black text boxes (12_179)
            ring = "box-shadow:0 0 0 3px #d8d8d4;" if not card_ctx.get("_dark_text") else ""
            css = DC_ICON_CSS if card_ctx.get("_dc_text") else f"height:{h * 29 // 37}px"
            return f'<img class="gt-icon" src="{data_uri(ASSETS / "icons/ep1-disc.png")}" style="{css};border-radius:50%;{ring}margin:0 6px">'
        if str(card_ctx.get("set_mark") or "").startswith("pc:"):
            f = "icons/inline-episode1-pc.png"   # the PC's printed circle (median of 15 faces, tools/inline_icons)
    if card_ctx.get("_dc_text") and h == 64:
        return f'<img class="gt-icon" src="{data_uri(ASSETS / f)}" style="{DC_ICON_CSS}">'
    if h == 64 and str(card_ctx.get("set_mark") or "").startswith("pc:") and card_ctx.get("lang") != "ja" and not card_ctx.get("decipher_print"):
        # rev 84 (inline icons): the PC's Virtual Sets print these inline icons 28 px tall at 745 (Light / Dark Side Force,
        # Independent, Maintenance, Republic, pilot power; 211_31, 202_3, 200_50, 207_3, 210_12, 200_59, 200_2) and the
        # Episode I circle 36 px (Captain Rex, 501st Legion): ours were 32
        h = 72 if name == "episode1" else 56
    return f'<img class="gt-icon" src="{data_uri(ASSETS / f)}" style="height:{h}px">'


# rev 84 (inline icons): Decipher printed some inline game-text icons in its own colours (measured on the 1497 px hires
# faces; tools/make_inline_decipher.py): the dark slate Independent square (the PC draws it bright blue) and a duller
# green selective-creature icon. Used on Decipher's own printings (card decipher_print), never on PC / Japanese cards.
DC_INLINE = {"independent": "icons/inline-independent-decipher.png", "independent-starship": "icons/inline-independent-decipher.png",
             "selective-creature": "icons/selective-creature-decipher.png"}
# and smaller: printed inline icons are 23-26 px tall at 745 (Light / Dark Side Force, Independent, selective creature,
# 6 hires faces) against our 28-33, from about the baseline to the cap height; the inline set spheres 20-24 px with a
# heavier dark ring (Rendezvous Point On Tatooine, You Will Go To The Dagobah System, Corporal Beezer)
DC_ICON_CSS = "height:48px;vertical-align:-3px"
DC_SPHERE_CSS = "height:42px;vertical-align:-2px;border-radius:50%;box-shadow:0 0 0 4px #111;margin:0 6px"


def dc_inline(name: str):
    if card_ctx.get("decipher_print") and not card_ctx.get("_pc_icons") and card_ctx.get("lang") != "ja":
        return DC_INLINE.get(name)
    return None


card_ctx: dict = {}   # set by render() so tokens can see the card (virtual_set for {ovs})


def dc_star_img(h: float, extra: str = "") -> str:
    """rev 84: Decipher's printed creature star (Bog-wing, Rancor, Sarlacc: FEROCITY and "Ferocity = ..."): an
    eight-pointed burst with a fat centre (inner radius 0.46 of the outer), white, where the slips print the six-point ✶"""
    import math
    pts = " ".join(f"{(10 if k % 2 == 0 else 4.6) * math.sin(k * math.pi / 8):.2f},{-(10 if k % 2 == 0 else 4.6) * math.cos(k * math.pi / 8):.2f}" for k in range(16))
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-10.5 -10.5 21 21"><polygon points="{pts}" fill="#fff"/></svg>'
    return f'<img src="data:image/svg+xml;base64,{base64.b64encode(svg.encode()).decode()}" style="height:{h}px;{extra}">'


def game_text_html(text: str) -> str:
    """{pilot:2} → pilot-power icon + number; {alter} {control} {sense} {maintenance} {grabber} {lightsaber} → icons.
    ▲ / ▼ (PC shorthand triangles) pass through as text. *bold* → bold."""
    out = []
    pos = 0
    pend = [False]   # rev 84: the printed Jedi Test stone keeps its keyword on its line (Domain Of Evil)

    def close_nowrap(seg):
        if not pend[0]:
            return seg
        pend[0] = False
        w = re.match(r"\S*", seg).end()
        out.append(esc(seg[:w]) + "</span>")
        return seg[w:]
    for m in re.finditer(r"\{([\w-]+)(?::([^}]*))?\}", text):
        seg = close_nowrap(text[pos:m.start()])
        hy = re.search(r"(\S+-)$", seg)   # "non-{icon}" stays on one line, as the PC sets it (Endless Legions, #63)
        if hy:
            out.append(esc(seg[:hy.start()]) + '<span style="white-space:nowrap">' + esc(hy.group(1)))
        else:
            out.append(esc(seg))
        name, arg = m.group(1), m.group(2)
        n_out = len(out)
        if name in ("u", "ub"):   # rev 77: an underlined run as Takara printed some terms ({u:密閉型}, Blizzard Walker (Japanese));
            out.append(f'<u>{esc(arg or "")}</u>' if name == "u" else f'<b><u>{esc(arg or "")}</u></b>')   # rev 82 {ub:…} bold too (Attack Run)
        elif name == "pilot":   # Dark Side cards print the DS (TIE pilot) icon, Light Side the Rebel one (Bill 2026-10-12)
            out.append(icon_img("pilotpower-dark" if card_ctx.get("side") == "Dark" else "pilotpower") + f" {esc(arg or '')}")
        elif name in ("alter", "control", "sense"):
            # the slips' red "no" circle with the letter: drawn (transparent), not a pasted raster
            out.append(f'<span class="noicon"><span class="nol">{name[0].upper()}</span></span>')
        elif name == "icon" and arg in ("maintenance-star", "maintenance-skull", "maintenance-flag"):
            # Decipher's maintenance-cost glyphs, cut from the Remaster sheet at 1200 DPI (black on transparent)
            g = {"maintenance-star": "glyph-star", "maintenance-skull": "glyph-skull", "maintenance-flag": "glyph-flag"}[arg]
            hpx = {"glyph-star": 46, "glyph-skull": 60, "glyph-flag": 48}[g]   # the flag (VS16 Jedi Survivor) cut at 1200 DPI   # the star is cap-height, the skull a little taller than the x-height+descender
            out.append(f'<img class="gt-icon" src="{data_uri(ASSETS / f"icons/{g}.png")}" style="height:{hpx}px;vertical-align:{-4 if g == "glyph-star" else -10}px;margin-right:{6 if g == "glyph-star" else 0}px{";filter:invert(1)" if not card_ctx.get("_dark_text") else ""}">')
        elif name == "ovs":   # the slip prints its own Original Virtual set sphere inline (= "the (V) version of")
            out.append(f'<img class="gt-icon" src="{data_uri(ASSETS / f"icons/ovs-set-{arg or card_ctx.get('virtual_set', 3)}.png")}" style="height:56px">')
        elif name == "vset":   # VS17 slips: the Committee's diamond set mark with a number = "Virtual Set N's" (e.g. {vset:9})
            svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 86">'
                   '<polygon points="50,3 97,43 50,83 3,43" fill="#111" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>'
                   '<polyline points="12,47 50,76 88,47" fill="none" stroke="#fff" stroke-width="7" stroke-linejoin="miter"/>'
                   f'<text x="50" y="53" text-anchor="middle" font-family="Helvetica Neue, Arial, sans-serif" font-weight="700" font-size="{40 if len(arg or "") < 2 else 36}" fill="#fff">{esc(arg or "")}</text></svg>')
            out.append(f'<img class="gt-icon" src="data:image/svg+xml;base64,{base64.b64encode(svg.encode()).decode()}" style="height:60px;vertical-align:-12px">')
        elif name == "ga" and arg == "jedi-test" and card_ctx.get("template") == "ls-jeditest-olive":
            # rev 84: the printed Jedi Tests set the bare stone (no disc) before Deploy / Target / Attempt / Place:
            # 30 x 17 px at 745 (Domain Of Evil); cut from the Game Aid icon (assets/icons/jedi-test-stone.png)
            out.append(f'<span style="white-space:nowrap"><img class="gt-icon" src="{data_uri(ASSETS / "icons/jedi-test-stone.png")}" style="height:36px;vertical-align:-1px;margin-right:6px">')
            pend[0] = True
        elif name == "ga":   # a Players Committee Game Aid icon (Feb 2024 reference sheet), e.g. {ga:separatist}
            gf = ASSETS / (dc_inline(arg) or f"icons/pc-gameaid-x4/{arg}.png")
            if not gf.exists() and str(arg).startswith("disc-"):   # rev 73: a printed disc of our own ({ga:disc-vader}, Virtual Block 7)
                gf = ASSETS / f"icons/{arg}.png"
            out.append(f'<img class="gt-icon" src="{data_uri(gf)}" style="height:56px;border-radius:50%">' if gf.exists() and str(arg).startswith("disc-")
                       else f'<img class="gt-icon" src="{data_uri(gf)}" style="{DC_ICON_CSS if card_ctx.get("_dc_text") else "height:56px"}">' if gf.exists() else esc(f"[{arg}]"))
        elif name in ("vb", "pcset"):   # inline set marks: [Virtual Block 4] -> {vb:4}, [Set 13] -> {pcset:13}
            out.append(inline_set_mark(("vb:" if name == "vb" else "pc:") + (arg or "")))
        elif name == "set":   # expansion-set symbol inline, e.g. {set:anh} = "the A New Hope R2-D2"
            sf = ASSETS / f"icons/set-{arg}-decipher.png"   # Decipher's own sphere (Bill 2026-10-14)
            if not sf.exists():
                sf = ASSETS / f"icons/set-{arg}-grainy.png"
            out.append(f'<img class="gt-icon" src="{data_uri(sf)}" style="{DC_SPHERE_CSS if card_ctx.get("_dc_text") else "height:56px;border-radius:50%;box-shadow:0 0 0 3px #000"}">')
        elif name == "icon" and arg in ICON_FILES:   # {icon:pilot}, {icon:warrior} …
            # rev 84 (inline icons): a Light card prints the Light pilot icon inline (Ellorrs Madak), as in its column
            out.append(icon_img("pilot-light" if arg == "pilot" and card_ctx.get("side") == "Light" else arg))
        elif name == "icon" and (ASSETS / f"icons/pc-gameaid-x4/{arg}.png").exists():
            out.append(f'<img class="gt-icon" src="{data_uri(ASSETS / (dc_inline(arg) or f"icons/pc-gameaid-x4/{arg}.png"))}" style="{DC_ICON_CSS if card_ctx.get("_dc_text") else "height:56px"}">')
        elif name in ICON_FILES:
            out.append(icon_img(name))
        else:   # unknown code: print it as typed rather than fail the card
            out.append(esc(m.group(0)))
        if card_ctx.get("_pc_icons") and len(out) > n_out and not out[-1].startswith(esc(m.group(0))):
            # rev 74: the PC set an inline icon over a fixed run of spaces (6.6 pt = 55 px at the master): every icon
            # takes that room on the line, whatever its own width (Han Solo, Innocent Scoundrel's pilot icon)
            ic = "".join(out[n_out:]); tail = ""
            if name == "pilot":
                ic, tail = ic.rsplit(" ", 1); tail = " " + tail
            out[n_out:] = [f'<span class="pcic">{ic}</span>{tail}']
        if hy:
            out.append("</span>")
        pos = m.end()
    out.append(esc(close_nowrap(text[pos:])))
    if pend[0]:
        out.append("</span>")
    html = "".join(out)
    html = html.replace("•", '<span class="dot">•</span>')
    html = re.sub(r"\*(.+?)\*", r"<b>\1</b>", html, flags=re.S)
    html = re.sub(r"(?<![A-Za-z0-9])_(.+?)_(?![A-Za-z0-9])", r"<i>\1</i>", html, flags=re.S)   # italics may span the slip's line breaks
    if card_ctx.get("template") == "creature-dc":   # rev 84: the printed eight-point star, set close to its word (✶Ferocity)
        html = re.sub(r"✶ ?", lambda _m: dc_star_img(40, "vertical-align:5px;margin-right:4px"), html)
        # the printed creatures never break a hyphenated name (Bog-wing, Ree-Yees): keep it on one line
        html = "".join(x if x.startswith("<") else re.sub(r"(\w+(?:-\w+)+)", r'<span style="white-space:nowrap">\1</span>', x)
                       for x in re.split(r"(<[^>]*>)", html))
    html = html.replace("▲", "<span class=tri>▲</span>").replace("▼", "<span class=tri>▼</span>")
    html = html.replace("◇", "<span class=dia>◇</span>")   # Decipher's non-unique-location mark (Defensive Shields: "opponent’s ◇ site")
    return html.replace("\n", "<br>").replace("¶", "<br>").replace("\u2029", "<br>")   # ¶ = a paragraph break that keeps normal wrapping (card maker)


def esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def margin_ink(frame_path, x: int, top: int, bot: int) -> str:
    """Credit ink by the margin it sits on, as the slips print it (Bill 2026-10-13: Endor Shield (V), Mara Jade (V),
    Stinger (V)): black on the bright margins and on red ones (Light frames, Dark Effects / Interrupts), white on the
    darker grey, blue and green Dark frames (characters, starships)."""
    try:
        import numpy as np
        im = Image.open(frame_path).convert("RGBA").crop((x - 10, top, x + 50, bot))
        al = np.array(im)[:, :, 3] > 200
        if not al.any():
            return "#fff"
        h, s_, v = np.median(np.array(im.convert("RGB").convert("HSV")).astype(float)[al] / 255, axis=0)
        red = (h < 0.08 or h > 0.92) and s_ > 0.3
        return "#000" if v > 0.7 or red else "#fff"
    except Exception:
        return "#fff"


def loc_title(card: dict, bar: str = "Light") -> str:
    """Location bar title as the Remaster slips letter it (Bill 2026-10-14): AG Bold Condensed caps. The uniqueness
    dot / diamond is red on the bar of the card's own side and in the bar's text colour on the other (VS13 slips:
    Light cards print a white dot on the Dark bar, Dark cards a black dot on the Light bar)."""
    t = card.get("card_type") or card["title"]
    h = esc_i(t)
    cls = "dot" if bar == card.get("side", "Light") else "dot plain"
    return '<span class="lt">' + re.sub(r"^([•◊＊]+)", lambda m: f'<span class="{cls}">{m.group(1)}</span>', h) + '</span>'


def title_dots(h: str, card: dict) -> str:
    """Rev 77: a card title's leading uniqueness dots in the spec's bullet_colour (unchanged when none is set)."""
    c = bullet_colour(card)
    return re.sub(r"^([•◊]+)", lambda m: f'<span style="color:{c}">{m.group(1)}</span>', h) if c else h


def title_html(s: str) -> str:
    """esc_i() for card titles (Holotable Title carries é è á à ó ú É and curly quotes itself, #118)."""
    return esc_i(s)


def esc_i(s: str) -> str:
    """esc() plus _italic_ markup (the slips italicise ship names in titles/banners: _Imperial_-Class Star Destroyer)."""
    return re.sub(r"(?<![A-Za-z0-9])_(.+?)_(?![A-Za-z0-9])", r"<i>\1</i>", esc(s))


# rev 84 (systems): the art library keeps a system's picture as the strip between its two bars, cut from the whole printed
# card normalised to 350x490 (art_library_all.system_box: x 14..336, y ~95..395). The card body (the master's 1343x1931
# art area) is the 745 px Holotable face's 37..708.5 x 36..1001.5, i.e. 17.38..332.85 x 16.98..472.33 of that 350x490
# card. Placed there (not cover-fitted to the whole art area, which drew the planet 1.4-1.6x too large: Bespin, Fondor,
# Kessel); the rows above / below the strip (under the bars, the margins beside them) are the strip mirrored outward.
SYS_BODY_350 = (37 * 350 / 745, 36 * 490 / 1039, 708.5 * 350 / 745, 1001.5 * 490 / 1039)


def system_library_art(card: dict, im: Image.Image) -> str:
    import numpy as np
    x0, y0, x1, y1 = card["art"]["card350"]
    s = im.width / (x1 - x0)                          # library px per card350 unit (orig 1, x4 4)
    bx0, by0, bx1, by1 = SYS_BODY_350
    _, _, aw, ah = TEMPLATES[card["template"]]["art"]
    ext = ((bx0 - x0) * s, (by0 - y0) * s, (bx1 - x0) * s, (by1 - y0) * s)
    crop = im.transform((aw, ah), Image.EXTENT, ext, Image.BICUBIC)
    top = max(0, int(np.ceil((y0 - by0) / (by1 - by0) * ah)) + 2)       # first full row of the strip (+2: soft edge)
    bot = min(ah, int((y0 + im.height / s - by0) / (by1 - by0) * ah) - 2)
    lft = max(0, int(np.ceil((x0 - bx0) / (bx1 - bx0) * aw)) + 2)
    rgt = min(aw, int((x1 - bx0) / (bx1 - bx0) * aw) - 2)
    if lft > 2:
        crop.paste(crop.crop((lft, 0, 2 * lft, ah)).transpose(Image.FLIP_LEFT_RIGHT), (0, 0))
    if rgt < aw - 2:
        w_ = aw - rgt; crop.paste(crop.crop((rgt - w_, 0, rgt, ah)).transpose(Image.FLIP_LEFT_RIGHT), (rgt, 0))
    y = top                                            # upward from the strip's top, its rows flipped
    while y > 0:
        h = min(195, y, bot - top); crop.paste(crop.crop((0, top, aw, top + h)).transpose(Image.FLIP_TOP_BOTTOM), (0, y - h)); y -= h
    y = bot                                            # downward from its foot
    while y < ah:
        h = min(195, ah - y, bot - top); crop.paste(crop.crop((0, bot - h, aw, bot)).transpose(Image.FLIP_TOP_BOTTOM), (0, y)); y += h
    p = OUT / f"_art_{card['id']}-sys.png"
    crop.save(p)
    return data_uri(p)


def _edge_trim(idx, n):
    """Rev 84: drop a stray bright line at the image's very edge, apart from the card body (Decipher's 350 x 490
    Tatooine GIFs carry a white last column: the Podracer scans mapped 5 % wide, their own frame and copyright line
    showed inside the window). Only a run that touches the image edge, is under 1 % of it and is cut off from the
    body by a gap of 3+ px is dropped."""
    import numpy as np
    if len(idx) < 2:
        return idx
    runs = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
    if len(runs) > 1 and runs[0][0] == 0 and len(runs[0]) < 0.01 * n and runs[1][0] - runs[0][-1] > 3:
        runs = runs[1:]
    if len(runs) > 1 and runs[-1][-1] == n - 1 and len(runs[-1]) < 0.01 * n and runs[-1][0] - runs[-2][-1] > 3:
        runs = runs[:-1]
    return np.concatenate(runs)


def art_crop(card: dict, win=None, tag: str = "") -> str:
    """Crop the art window out of a Decipher scan (any size: the silver frame is located, then mapped)."""
    src = Path(card["art"]["src"])
    im = Image.open(src)
    if im.mode == "P" and "transparency" in im.info:   # Virtual Block "-pre" GIFs mark their brightest highlight transparent
        bg = Image.new("RGBA", im.size, (255, 255, 255, 255)); bg.alpha_composite(im.convert("RGBA")); im = bg
    im = im.convert("RGB")
    import numpy as np
    a = np.array(im).astype(int)
    if card["art"].get("card350") and TEMPLATES[card["template"]].get("system") and not win:
        return system_library_art(card, im)
    if card["art"].get("rect") and (not win or tag == "-rect"):
        # the scan's own art rectangle, cover-fitted to the window (tall-slip cards whose window shape differs)
        x0, y0, x1, y1 = card["art"]["rect"]
        aw_, ah_ = TEMPLATES[card["template"]]["art"][2:] if not win else win[2:]
        if (x1 - x0) / (y1 - y0) > aw_ / ah_:
            cw_ = (y1 - y0) * aw_ / ah_; x0, x1 = (x0 + x1 - cw_) / 2, (x0 + x1 + cw_) / 2
        else:
            ch_ = (x1 - x0) * ah_ / aw_; y0, y1 = (y0 + y1 - ch_) / 2, (y0 + y1 + ch_) / 2
        crop = im.crop(tuple(int(round(v)) for v in (x0, y0, x1, y1))).resize((aw_, ah_), Image.LANCZOS)
        p = OUT / f"_art_{card['id']}{tag}.png"; crop.save(p); return data_uri(p)
    if card["art"].get("bbox"):
        fx0, fy0, fx1, fy1 = card["art"]["bbox"]
    elif TEMPLATES[card["template"]].get("system"):
        # no silver frame on a system: the card is everything that is not the black border
        m = a.max(axis=2) > 40
        rows = np.where(m.mean(axis=1) > 0.05)[0]
        cols = np.where(m.mean(axis=0) > 0.05)[0]
        fx0, fy0, fx1, fy1 = cols.min(), rows.min(), cols.max(), rows.max()
        # archive scans are often cut short on one edge: keep the card's true proportions (uniform scale from
        # the taller axis) and let the missing strip be filled with starfield below
        sc = max((fy1 - fy0) / 1931, (fx1 - fx0) / 1343)
        missing = (int(1343 - (fx1 - fx0) / sc), int(1931 - (fy1 - fy0) / sc))   # strip lost at right / bottom
        fx1, fy1 = fx0 + 1343 * sc, fy0 + 1931 * sc
    else:
        bright = a.sum(axis=2) > 120
        rows = _edge_trim(np.where(bright.mean(axis=1) > 0.5)[0], a.shape[0])
        cols = _edge_trim(np.where(bright.mean(axis=0) > 0.5)[0], a.shape[1])
        fx0, fy0, fx1, fy1 = cols.min(), rows.min(), cols.max(), rows.max()   # silver frame bbox in the scan
    cw, ch = (1931, 1343) if TEMPLATES[card["template"]].get("landscape") else (1343, 1931)
    sx = (fx1 - fx0) / cw
    sy = (fy1 - fy0) / ch
    if not card["art"].get("bbox") and abs(sy / sx - 1) > 0.015:
        # the scan is cut short on one edge: trust the width, anchor on the edge that is inside the image
        sy = sx
        if fy0 <= 1:
            fy0 = fy1 - ch * sx
        else:
            fy1 = fy0 + ch * sx
    ax, ay, aw, ah = win or TEMPLATES[card["template"]]["art"]
    box = (fx0 + (ax - 144) * sx, fy0 + (ay - 144) * sy, fx0 + (ax + aw - 144) * sx, fy0 + (ay + ah - 144) * sy)
    box = [int(round(v)) for v in box]
    if card.get("art_trim"):
        # Episode I frames (Coruscant/Theed/Tatooine) put the art window a little differently from the classic frame:
        # trim silver-frame rows/columns (bright, unsaturated) off the mapped box's edges, up to 12 % per edge
        x0, y0, x1, y1 = box
        sub = a[max(y0, 0):y1, max(x0, 0):x1]
        def silver(line):   # mean brightness high, mean saturation low
            mx, mn = line.max(axis=1), line.min(axis=1)
            return line.mean() > 100 and (mx - mn).mean() < 45
        h, w = sub.shape[:2]
        # cut at the innermost silver line found in each edge zone (the frame's black inner line may sit between
        # the silver band and the mapped edge)
        def innermost(lines, n):
            cut = 0
            for i in range(n):
                if silver(lines(i)): cut = i + 1
            return cut
        t = innermost(lambda i: sub[i], int(h * 0.15))
        b = innermost(lambda i: sub[h - 1 - i], int(h * 0.15))
        l = innermost(lambda i: sub[:, i], int(w * 0.15))
        r = innermost(lambda i: sub[:, w - 1 - i], int(w * 0.15))
        box = [x0 + l, y0 + t, x1 - r, y1 - b]
        if card.get("legacy_scan") and b == 0:
            # Virtual Block slips sit a coloured banner where the classic window ends (Vader's Anger (V)): drop the
            # foot of the mapped window, and the same share of the width so the picture keeps its shape
            hh, ww = box[3] - box[1], box[2] - box[0]
            box = [box[0] + int(ww * 0.03), box[1], box[2] - int(ww * 0.03), box[3] - int(hh * 0.06)]
    crop = im.crop(tuple(box))
    crop = crop.resize((aw, ah), Image.LANCZOS)
    if TEMPLATES[card["template"]].get("system"):
        # the scan's own printed bars sit a little off the template's: hide them under a starfield band cloned
        # from the middle of the scan (margins are left alone so the scan's set icon and TM lines stay)
        mw, mh = missing if not card["art"].get("bbox") else (0, 0)
        if mw > 0:
            x0 = 1343 - mw - 2
            crop.paste(crop.crop((x0 - mw - 2 - 20, 0, x0 - 20, 1931)).transpose(Image.FLIP_LEFT_RIGHT), (x0, 0))
        if mh > 0:
            y0 = 1931 - mh - 2
            crop.paste(crop.crop((0, y0 - mh - 2 - 20, 1343, y0 - 20)).transpose(Image.FLIP_TOP_BOTTOM), (0, y0))
        # the slip replaces the whole Light half, margins included: its TM lines go too (starfield from the
        # same margins higher up)
        for x0, x1 in ((0, 95), (1248, 1343)):
            mb = crop.crop((x0, 700, x1, 1100))
            for y in range(1560, 1931, mb.height):
                crop.paste(mb.crop((0, 0, mb.width, min(mb.height, 1931 - y))), (x0, y))
        # mirror the picture just inside the bars outward over them (continuous planets/starfield, no cloned
        # band from elsewhere: Yavin 4's gas giant showed twice, Bill 2026-10-15 QA)
        def mirror_fill(y0, y1, up, xa=80, xb=1265):
            y = y0 if not up else y1
            src_edge = y0 if not up else y1
            while (y < y1) if not up else (y > y0):
                h = min(195, (y1 - y) if not up else (y - y0))
                if not up:   # fill downward from y0 with the rows above y0, flipped
                    piece = crop.crop((xa, src_edge - h, xb, src_edge)).transpose(Image.FLIP_TOP_BOTTOM); crop.paste(piece, (xa, y)); y += h
                else:        # fill upward from y1 with the rows below y1, flipped
                    piece = crop.crop((xa, src_edge, xb, src_edge + h)).transpose(Image.FLIP_TOP_BOTTOM); crop.paste(piece, (xa, y - h)); y -= h
        # where the scan's own bar assemblies are: rows that are silver across most of the width (the printings put
        # them at slightly different heights: Death Star II, Rendezvous Point); none = a half the card doesn't print
        hsv = np.array(crop.convert("HSV")).astype(int)[:, 150:1200]
        sil = (hsv[:, :, 1] < 45) & (hsv[:, :, 2] > 105)
        silver = (sil.mean(axis=1) > 0.8) & (sil[:, :120].mean(axis=1) > 0.7) & (sil[:, -120:].mean(axis=1) > 0.7)
        top = [y for y in range(0, 560) if silver[y]]
        bot = [y for y in range(1380, 1931) if silver[y]]
        if top:
            mirror_fill(0, min(top[-1] + 22, 580), True, 0, 1343)
        if bot:
            mirror_fill(max(bot[0] - 22, 1360), 1931, False, 0, 1343)
    p = OUT / f"_art_{card['id']}{tag}.png"
    crop.save(p)
    return data_uri(p)


# rev 77: two-picture art of the Reflections II combo cards (Do, Or Do Not & Wise Advice, Ghhhk & Those Rebels Won't
# Escape Us). Measured on 24 printed combo scans (12 Light, 12 Dark; Ghhhk at 745 px true colour, the rest 354 px GIFs):
# a straight stripe rising from lower left to upper right at 60.0° from horizontal (dx/dy -0.577 on every scan), its
# centre line crossing the window's mid-height 0.508 of the window width from the left (master x 821 in a window
# 240..1384; it meets the top edge at ~0.70 and the bottom edge at ~0.31 of the width). Width across the stripe: Light
# 36 master px (20.5 px horizontally at 745), Dark 38 (22 px). Two bevel facets split along the middle: Light silver,
# the lower-left facet lighter (226/225/222) than the upper-right (200/200/198); Dark red, the lower-left darker
# (176/28/45) than the upper-right (214/31/53, Ghhhk true colour; the GIFs carry the same split darker). Edges ~1 px soft.
SPLIT_DEFAULT = {"angle": 60.0, "x": 0.508}
SPLIT_WIDTH = {"light": 36, "dark": 38}
SPLIT_STOPS = {   # (position across the stripe 0 = lower-left edge .. 1 = upper-right edge, RGB)
    "silver": [(0.0, (206, 206, 203)), (0.1, (225, 224, 222)), (0.45, (228, 228, 224)), (0.52, (211, 208, 203)),
               (0.6, (200, 200, 197)), (0.92, (202, 202, 200)), (1.0, (190, 191, 189))],
    "red": [(0.0, (160, 29, 40)), (0.12, (174, 27, 45)), (0.3, (185, 29, 45)), (0.45, (180, 28, 45)), (0.52, (204, 30, 50)),
            (0.58, (213, 32, 55)), (0.9, (215, 30, 52)), (1.0, (198, 36, 57))],
}


def split_params(card: dict) -> dict:
    """The stripe of a two-picture window: spec `split` over the measured defaults (side from the template)."""
    sp = dict(card.get("split") or {})
    dark = str(card.get("template") or "").startswith("ds-") or card.get("side") == "Dark"
    out = {"angle": float(sp.get("angle") or SPLIT_DEFAULT["angle"]),
           "x": float(sp["x"]) if sp.get("x") is not None else SPLIT_DEFAULT["x"],
           "width": float(sp["width"]) if sp.get("width") is not None else SPLIT_WIDTH["dark" if dark else "light"],
           "color": sp.get("color") or ("red" if dark else "silver"),
           "texture": sp.get("texture") or "bevel",
           "fit1": sp.get("fit1") or {}, "fit2": sp.get("fit2") or {}}
    out["angle"] = min(max(out["angle"], 15.0), 89.0); out["x"] = min(max(out["x"], 0.0), 1.0)
    out["width"] = min(max(out["width"], 0.0), 200.0)
    return out


def _split_picture(card: dict, p: dict, n: int) -> Image.Image:
    """One picture of a split window, as a plain image: an art rectangle (library art, upload) or a Decipher scan whose
    standard art window is mapped (art_crop with the template's art box)."""
    if p.get("rect"):
        im = Image.open(p["src"])
        if im.mode == "P" and "transparency" in im.info:
            bg = Image.new("RGBA", im.size, (255, 255, 255, 255)); bg.alpha_composite(im.convert("RGBA")); im = bg
        return im.convert("RGB").crop(tuple(int(round(v)) for v in p["rect"]))
    tmp = {k: v for k, v in card.items() if k not in ("art_trim", "legacy_scan")}
    tmp.update(art={k: v for k, v in p.items() if k in ("src", "bbox")}, id=f"{card['id']}-p{n}")
    art_crop(tmp, TEMPLATES[card["template"]]["art"], "-split")
    return Image.open(OUT / f"_art_{tmp['id']}-split.png").convert("RGB")


def _place(im: Image.Image, W_: int, H_: int, box: tuple, fx_default: float, fit: dict) -> Image.Image:
    """Picture for one side of a split window, cut to that side's box (bx, by, bw, bh). As Decipher composed the combos,
    each picture is at the scale of the WHOLE window (cover-fitted to it, times `zoom` >= 1) and pushed against the
    stripe, its outer part cut off (Ghhhk & Those Rebels Won't Escape Us: Ghhhk's right edge at the stripe's top end,
    the TIE picture's left edge at its bottom end): fx 1 for picture 1, 0 for picture 2. `fx` / `fy` in 0..1 slide it
    across the range that keeps the box covered (0 = its left / top part shows, as the editor's upload framing)."""
    bx, by, bw, bh = box
    iw, ih = im.size
    z = min(max(float(fit.get("zoom") or 1), 1.0), 6.0)
    sc = max(W_ / iw, H_ / ih) * z
    pw, ph = iw * sc, ih * sc
    fx = min(max(float(fit["fx"] if fit.get("fx") is not None else fx_default), 0.0), 1.0)
    fy = min(max(float(fit["fy"] if fit.get("fy") is not None else 0.5), 0.0), 1.0)
    L = bx - fx * (pw - bw)   # picture's left edge (window px)
    T = by - fy * (ph - bh)
    x0, y0 = (bx - L) / sc, (by - T) / sc
    return im.resize((bw, bh), Image.LANCZOS, box=(x0, y0, x0 + bw / sc, y0 + bh / sc))


def split_art(card: dict, win: tuple, tag: str = "-split") -> str:
    """Rev 77: compose the window of a two-picture card. Picture 1 (`art`) fills the left / lower part, picture 2
    (`art2`) the right / upper part, the stripe is drawn over the seam; all of it is the window `win` (x, y, w, h)."""
    import math
    import numpy as np
    sp = split_params(card)
    W_, H_ = int(win[2]), int(win[3])
    th = math.radians(sp["angle"]); s_, c_ = math.sin(th), math.cos(th)
    xm, ym = sp["x"] * W_, H_ / 2
    hw = sp["width"] / 2
    yy, xx = np.mgrid[0:H_, 0:W_].astype(float)
    d = (xx + 0.5 - xm) * s_ + (yy + 0.5 - ym) * c_   # signed distance from the centre line, > 0 = right / upper side
    cot = c_ / s_
    pad = hw / s_ + 4
    # each picture is fitted to the box of its own side of the seam (the stripe hides the join)
    r1 = (0, 0, int(min(W_, math.ceil(xm + ym * cot + pad))), H_)
    x2 = int(max(0, math.floor(xm - (H_ - ym) * cot - pad)))
    r2 = (x2, 0, W_ - x2, H_)
    canvas = []
    for n, (p, box, cen, fit) in enumerate(((card.get("art"), r1, 1.0, sp["fit1"]), (card.get("art2"), r2, 0.0, sp["fit2"])), 1):
        bx, by, bw, bh = box
        c = np.zeros((H_, W_, 3), float)
        if p:
            c[by:by + bh, bx:bx + bw] = np.array(_place(_split_picture(card, p, n), W_, H_, box, cen, fit)).astype(float)
        canvas.append(c)
    a2 = np.clip(d + 0.5, 0, 1)[..., None]   # 1 px anti-aliased seam (hidden under a stripe of any width)
    out = canvas[0] * (1 - a2) + canvas[1] * a2
    col = sp["color"]
    if hw > 0 and col != "none":
        if col in SPLIT_STOPS:
            stops = SPLIT_STOPS[col]
        else:
            m = re.fullmatch(r"#?([0-9a-fA-F]{6})", str(col))
            rgb = tuple(int(m.group(1)[i:i + 2], 16) for i in (0, 2, 4)) if m else (200, 200, 200)
            lo, hi = tuple(int(v * 1.06) for v in rgb), tuple(int(v * 0.92) for v in rgb)   # the same two facets
            stops = [(0, lo), (0.48, lo), (0.54, hi), (1, hi)]
        if sp["texture"] == "flat":
            mean = np.mean([s[1] for s in stops], axis=0); stops = [(0, mean), (1, mean)]
        t = np.clip((d + hw) / (2 * hw), 0, 1)
        pos = [s[0] for s in stops]
        stripe = np.stack([np.interp(t, pos, [s[1][k] for s in stops]) for k in range(3)], axis=-1)
        a = np.clip(hw - np.abs(d) + 0.5, 0, 1)[..., None]
        out = out * (1 - a) + stripe * a
    p = OUT / f"_art_{card['id']}{tag}.png"
    Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8)).save(p)
    return data_uri(p)


LOC = ASSETS / "loc"
LOC_ICON_FILES ={k: f"icon-{k}.png" for k in
                  ("grabber", "underground", "interior", "planet", "space", "exterior", "underwater", "creature", "mobile", "starship", "vehicle")}


def nolore_frame(card: dict, t: dict, fr: Path, fx: int, fy: int):
    """Tall slip over a printed card WITHOUT a lore box (Reflections II combos: Abyssin Ornament & Wounded Wookiee (V),
    Uncharted Settlements (V)). Bill 2026-10-14: start from the base card's frame and build the taller card from the
    bottom. Top = the no-lore frame of the base card's family (title bar, chamfered window corners under it):
    Bardez's scratched LS Epic Objective frame recoloured to the LS Effect red (ls-nolore-top.png) or the Dark
    no-lore red frame (ds-effect-tall.png); bottom = this template's own frame (window bottom edge, banner, text box),
    raised by `text_grow`; window sides stretched between; the card-type disc and destiny hole are this template's."""
    import numpy as np
    D = int(card.get("text_grow") or 0)
    ax, ay, aw, ah = t["art"]; gx, gy, gw, gh = t["game_text"]
    c = Image.new("RGBA", (1632, 2220), (0, 0, 0, 0)); c.alpha_composite(Image.open(fr).convert("RGBA"), (fx, fy))
    F = np.array(c)
    light = card.get("side") == "Light"
    T = np.array(Image.open(ASSETS / ("frames/ls-nolore-top.png" if light else "frames/ds-effect-tall.png")).convert("RGBA"))
    Wt, Wtb = (377, 1265) if light else (379, 1085)
    Wb = ay + ah
    G = np.zeros_like(F)
    k = Wt + 170
    G[:k] = T[:k]
    b0 = Wb - 40
    G[b0 - D:gy + 30 - D] = F[b0:gy + 30]
    if D:
        G[gy + 30 - D:gy + 30] = np.array(Image.fromarray(F[gy + 40:gy + gh - 40]).resize((F.shape[1], D), Image.LANCZOS))
    G[gy + 30:] = F[gy + 30:]
    X = 40   # cross-fade the stretched top frame into the bottom frame over X rows (no seam)
    mid = np.array(Image.fromarray(T[k:Wtb - 60]).resize((F.shape[1], b0 - D - k + X), Image.LANCZOS)).astype(float)
    G[k:b0 - D] = mid[:b0 - D - k].astype(np.uint8)
    w = np.linspace(1, 0, X)[:, None, None]
    G[b0 - D:b0 - D + X] = (mid[b0 - D - k:] * w + G[b0 - D:b0 - D + X].astype(float) * (1 - w)).round().astype(np.uint8)
    # the template's own disc and destiny hole, with their bevels, over the top frame's
    yy, xx = np.mgrid[0:G.shape[0], 0:G.shape[1]]
    for cx, cy, r in t.get("nolore_holes", [(258, 230, 80), (t["destiny"][0] + t["destiny"][2] // 2, t["destiny"][1] + t["destiny"][3] // 2, 80)]):
        m = (xx - cx) ** 2 + (yy - cy) ** 2 <= r * r
        G[m] = F[m]
    p = OUT / f"_frame_{card['id']}.png"; Image.fromarray(G).save(p)
    t = dict(t, card_type=(t["card_type"][0], t["card_type"][1] - D, t["card_type"][2], t["card_type"][3]),
             game_text=(gx, gy - D, gw, gh + D), _artwin=(ax, Wt - 10, aw, Wb - D + 6 - (Wt - 10)),
             expansion_ring=(1390, 373), expansion_size=70,   # the no-lore frame's own ring, clear of the art (Bill)
             _nolore_disc=t.get("nolore_disc"))   # #62: the PC sets the Episode I disc in the left margin by the window top
    if "banner_icon" in t:
        t["banner_icon"] = (t["banner_icon"][0], t["banner_icon"][1] - D)
    return p, t, 0, 0


def captive_frame(card: dict, t: dict, fr: Path, fx: int, fy: int):
    """Carbonite captives printed without art (Jabba's Prize): lore box, then the stat bar right under it, then a text
    box running to the foot of the card. The frame below the art window is lifted to the lore box; the text box is
    filled with mirrored tiles of its own clean band."""
    import numpy as np
    ax, ay, aw, ah = t["art"]; gx, gy, gw, gh = t["game_text"]
    lx, ly, lw, lh = t["lore"]
    c = Image.new("RGBA", (1632, 2220), (0, 0, 0, 0)); c.alpha_composite(Image.open(fr).convert("RGBA"), (fx, fy))
    F = np.array(c); G = np.zeros_like(F)
    cut = ly + lh + 25; src0 = ay + ah + 12; D = src0 - cut
    G[:cut] = F[:cut]
    G[cut:gy + 30 - D] = F[src0:gy + 30]
    band = F[gy + 40:gy + 120]; rows = []
    while sum(len(r) for r in rows) < D:
        rows.append(band if len(rows) % 2 == 0 else band[::-1])
    G[gy + 30 - D:gy + 30] = np.concatenate(rows)[:D]
    G[gy + 30:] = F[gy + 30:]
    p = OUT / f"_frame_{card['id']}.png"; Image.fromarray(G).save(p)
    t = dict(t, game_text=(gx, gy - D, gw, gh + D), stats_y=t["stats_y"] - D, _noart=True)
    return p, t, 0, 0


# rev 84 (Bill 2026-11-12, Do, Or Do Not & Wise Advice against its printed card): the printed no-lore combos (Reflections
# II, Coruscant; the PC's reissues the same) cut the window's top corners round the type disc and the destiny circle.
# Measured on the 745 px true-colour scans (Ghhhk & Those Rebels Won't Escape Us, Houjix & Out Of Nowhere), checked on
# the 354 px GIFs of the other 22 Reflections II combos: master px = 2 x (745 px + 35 / 36).
#   Dark: straight 30 deg chamfers — left from the window's left edge 82 px down, 144 px wide; right 78 px down, 136 wide.
#   Light: a rounded step under the disc lobe — 74 px down, flat for 12 px, then an S-curve rising over 118 px (steepest
#   ~43 deg); right the same round the destiny lobe, 70 px down, flat 12, curve 118.
# side: (drop, flat, run, shape) per corner.
COMBO_CORNERS = {
    "dark": {"left": (82, 0, 144, "line"), "right": (78, 0, 136, "line")},
    "light": {"left": (74, 12, 118, "smooth"), "right": (70, 12, 118, "smooth")},
}
COMBO_SPHERE = {"dark": (1420, 404, 56), "light": (1425, 411, 56)}   # sphere centre and size (black ring included)
# the ring round it: Light red paint ~4 px (745) on the silver, Dark a lighter rim ~2 px (745)
COMBO_SPHERE_HALO = {"dark": ("radial-gradient(circle, rgba(0,0,0,0) 60%, rgba(255,120,140,.45) 78%, rgba(255,120,140,0) 100%)", 6),
                     "light": ("#d44a43", 8)}
COMBO_COPYRIGHT_CY = 798   # centre of the copyright run (printed 210..519 at 745 on Ghhhk, 220..503 on Houjix)


def combo_corners(G, top: int, kind: str):
    """Reshape the top corners of a merged no-lore window (rev 84). G: the grown frame (H x W x 4, uint8), `top` the
    window opening's top row. Each column of a corner is moved down by its drop s(x) from the top of the window's
    edge band (opening top - 25) — the bevel band bends into the chamfer / step with its own shading, the window
    sides start lower — and the rows it opens are filled with the frame's own margin, taken from the same rows of
    the side margin 260 rows lower (mirror-tiled across), feathered into the margin above."""
    import numpy as np
    prof = COMBO_CORNERS[kind]
    Hh, Ww = G.shape[:2]
    mid = top + 200
    cx = Ww // 2
    hole = G[mid, :, 3] < 20
    xl = cx
    while xl > 0 and hole[xl - 1]: xl -= 1
    xr = cx
    while xr < Ww - 1 and hole[xr + 1]: xr += 1
    bl = xl - 32; br = xr + 30   # outer edge of the side bevels (26-28 px wide on the four templates)
    s = np.zeros(Ww)
    X = np.arange(Ww).astype(float)
    for side, (D, flat, run, shape) in prof.items():
        if side == "left":
            u = (X - (xl + flat)) / run; inside = X >= bl
        else:
            u = ((xr - flat) - X) / run; inside = X <= br
        u = np.clip(u, 0, 1)
        f = (1 - u) if shape == "line" else (1 - (u * u * (3 - 2 * u)))
        s = np.where(inside & (f > 0), np.maximum(s, D * f), s)
    s = np.round(s).astype(int)
    y0 = top - 25
    Smax = int(s.max())
    span = 420   # rows moved down in each column (the side bevel is uniform there)
    src = G.copy()
    # the opened rows are filled with the side margin next to the window's side bevel at the same rows: its per-row
    # median colour (keeps the frame's shading, drops splatter chips) plus its fine grain (mirror-tiled across)
    from PIL import ImageFilter
    fills = {}
    for side, (m0, m1) in (("left", (max(bl - 56, 0), bl - 2)), ("right", (br + 2, min(br + 56, Ww)))):
        st = src[y0:y0 + Smax + 1, m0:m1, :3].astype(float)
        med = np.median(st, axis=1)                                        # rows x 3
        bl_ = np.array(Image.fromarray(st.clip(0, 255).astype(np.uint8)).filter(ImageFilter.BoxBlur(3))).astype(float)
        grain = np.clip(st - bl_, -10, 10)
        fills[side] = (med, grain, m1 - m0)
    ab = src[y0 - 4:y0 - 1, :, :3].astype(float).mean(axis=0)   # the margin row above, smoothed across (no streaks)
    kern = np.ones(41) / 41
    above = np.stack([np.convolve(np.pad(ab[:, k], 20, mode="edge"), kern, mode="valid") for k in range(3)], axis=1)
    for x in np.nonzero(s)[0]:
        d = int(s[x])
        G[y0 + d:y0 + span, x] = src[y0:y0 + span - d, x]
        med, grain, w = fills["left" if x < cx else "right"]
        k = (x - bl) % (2 * w) if x < cx else (br - x) % (2 * w)
        k = k if k < w else 2 * w - 1 - k
        gx_ = (w - 1 - k) if x < cx else k
        # blend into the colour of the row just above (no hard edge where the opened rows begin)
        top_off = above[x] - med[0]
        wv = np.clip(1 - np.arange(d) / 16.0, 0, 1)[:, None]
        G[y0:y0 + d, x, :3] = np.clip(med[:d] + top_off * wv + grain[:d, gx_], 0, 255).round().astype(np.uint8)
        G[y0:y0 + d, x, 3] = 255
    if kind == "light":
        wt = (y0 + s).astype(float)
        wt[(X < bl) | (X > br)] = 1e9   # outside the window: nothing below to keep clear
        combo_lobes(G, wt)
    return G


# Light: the disc and destiny lobes as circles (cx, cy, R, master px) fitted to the printed rim's lower edge on Houjix
# (745 px: left through (48,142), (97,157), (150,136); right through (590,139), (648,152), (690,139)); rim 6 px (745)
COMBO_LOBES = [(264, 216, 170), (1366, 228, 148)]
COMBO_LOBE_RIM = 12


def combo_lobes(G, wtop):
    """Light combos (rev 84): the printed silver title bar bulges round the type disc and the destiny circle (rim
    bottom 157 at 745 px, Houjix & Out Of Nowhere) where the Effect / Interrupt frame's bar runs flat at 141. Paint
    each lobe below the bar: silver body (the bar's own colour just above, per column, with its grain), a white rim
    band and an anti-aliased edge into the red margin. `wtop`: per column, the first row of the window edge band."""
    import numpy as np
    Hh, Ww = G.shape[:2]
    rim = COMBO_LOBE_RIM
    src = G.copy()
    op = np.nonzero(G[600, :, 3] > 200)[0]
    xmin = int(op.min()) + 26 if len(op) else 170   # inside the card's outer edge bevel
    xmax = int(op.max()) - 26 if len(op) else 1460
    for cx, cy, R in COMBO_LOBES:
        for x in range(max(cx - R, xmin), min(cx + R + 1, xmax)):
            dx = x - cx
            yc = cy + (R * R - dx * dx) ** 0.5
            ys = int(250 + (max(0, 90 * 90 - dx * dx)) ** 0.5) + 4   # below the disc / destiny ring (centre y ~250, r ~90)
            col = src[ys:ys + 120, x, :3].astype(int)
            red = np.nonzero((col[:, 0] - col[:, 1]) > 60)[0]
            if not len(red):
                continue
            yb = ys + int(red[0])
            if yc + 2 <= yb:
                continue
            body_rows = src[max(yb - 30, ys):yb - 14, x, :3].astype(float)
            if not len(body_rows):
                body_rows = src[yb - 16:yb - 12, x, :3].astype(float)
            body = np.median(body_rows, axis=0)
            for y in range(yb - 12, min(int(yc) + 3, int(wtop[x]) - 4)):
                r = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if r > R + 1.5:
                    continue
                gy = yb - 16 - ((y - yb) % 12)
                grain = np.clip(src[gy, x, :3].astype(float) - body, -8, 8)
                if r <= R - rim:
                    c = body + grain
                else:
                    u = min((r - (R - rim)) / rim, 1.0)   # 0 inner .. 1 outer edge of the rim
                    hi = np.array([246.0, 246.0, 246.0]); lo = np.array([206.0, 206.0, 210.0])
                    c = (body + (hi - body) * (u / 0.4)) if u < 0.4 else (hi if u < 0.8 else hi + (lo - hi) * ((u - 0.8) / 0.2))
                a = float(np.clip(R + 0.5 - r, 0, 1))
                G[y, x, :3] = np.clip(c * a + G[y, x, :3].astype(float) * (1 - a), 0, 255).round().astype(np.uint8)
                G[y, x, 3] = 255


def grown_frame(card: dict, t: dict, fr: Path, fx: int, fy: int):
    """A tall slip (VS15 Anger, Fear, Aggression (V), Knowledge And Defense (V)): the slip's banner sits higher and its
    text box is taller, as the PC's own reissues print it (V0 Knowledge And Defense): the art window gets shorter with
    its own corners, banner and text-box top move up by `text_grow` px, the text box stretches. A base card with no
    lore box (Reflections II combos) also merges the lore window into the art window (Uncharted Settlements (V)).
    Works on a full-card canvas; returns (frame path, template, 0, 0) and t["_artwin"] = the new art window."""
    import numpy as np
    D = int(card.get("text_grow") or 0)
    ax, ay, aw, ah = t["art"]
    gx, gy, gw, gh = t["game_text"]
    c = Image.new("RGBA", (1632, 2220), (0, 0, 0, 0)); c.alpha_composite(Image.open(fr).convert("RGBA"), (fx, fy))
    F = np.array(c); G = np.zeros_like(F)
    top = (t["lore"][1] + 5) if card.get("no_lore_box") and t.get("lore") else ay
    bot = ay + ah - D
    T0, T1 = ay - 25, ay + 70                  # art window top edge with its corners
    B0, B1 = ay + ah - 95, gy + 30             # art window bottom edge with its corners, banner, text-box top
    G[:top - 25] = F[:top - 25]
    G[top - 25:top - 25 + (T1 - T0)] = F[T0:T1]
    m0 = top - 25 + (T1 - T0)
    m1 = bot - 95    # straight window sides: the frame's own, stretched to fit
    G[m0:m1] = np.array(Image.fromarray(F[T1:B0]).resize((F.shape[1], m1 - m0), Image.LANCZOS))
    G[m1:m1 + (B1 - B0)] = F[B0:B1]
    e = m1 + (B1 - B0)                         # = gy + 30 - D
    if D and "stats_y" in t:
        # characters: the deploy/forfeit slots sit low in the left column — fill with the clean band above them,
        # mirrored tiles (no stretched slot, no seam)
        band = F[gy + 40:gy + 120]; rows = []
        while sum(len(r) for r in rows) < gy + 30 - e:
            rows.append(band if len(rows) % 2 == 0 else band[::-1])
        G[e:gy + 30] = np.concatenate(rows)[:gy + 30 - e]
    elif D:
        G[e:gy + 30] = np.array(Image.fromarray(F[gy + 40:gy + gh - 40]).resize((F.shape[1], gy + 30 - e), Image.LANCZOS))
    G[gy + 30:] = F[gy + 30:]
    if card.get("no_lore_box") and t.get("lore") and t.get("combo_corners"):
        G = combo_corners(G, top, t["combo_corners"])   # rev 84: as printed (Reflections II / Coruscant combos, PC reissues)
    elif card.get("no_lore_box") and t.get("lore"):
        # the printed no-lore cards chamfer the window's top corners under the title bar (Bill 2026-10-14,
        # Abyssin Ornament (V)): shear the corner rows so the window edge runs in diagonally, bevel included
        def run(row, c):
            a = c; b = c
            while a > 0 and row[a - 1]: a -= 1
            while b < len(row) - 1 and row[b + 1]: b += 1
            return a, b
        cx = ax + aw // 2
        A0, A1 = run(F[ay + ah // 2, :, 3] < 20, cx)
        op = np.nonzero(F[ay + ah // 2, :, 3] > 200)[0]; E0, E1 = op.min() + 30, op.max() - 30
        Hc = 100
        y_top = top - 25
        X = np.arange(G.shape[1])
        for y in range(y_top, y_top + Hc + 30):
            sh = int(np.clip(Hc - (y - y_top - 10), 0, Hc))
            if not sh:
                continue
            src = np.interp(X, [0, E0, A0 + sh, cx, A1 - sh, E1, X[-1]], [0, E0, A0, cx, A1, E1, X[-1]]).round().astype(int)
            G[y] = G[y][src]
    p = OUT / f"_frame_{card['id']}.png"; Image.fromarray(G).save(p)
    t = dict(t, game_text=(gx, gy - D, gw, gh + D), _artwin=(ax, top, aw, bot - top))
    if card.get("no_lore_box") and t.get("lore") and t.get("combo_corners"):
        # rev 84: the sphere sits right of the window top, just under the destiny circle, without the lore-box ring's
        # extra hole; the copyright line runs from just under it (printed: alongside the upper window)
        hole = np.array(Image.open(p))[top + 200, :, 3] < 20   # the art covers the whole opening (no black sliver)
        hx = np.nonzero(hole[:W // 2 + 1][::-1] == False)[0]
        hl = W // 2 - (int(hx[0]) - 1) if len(hx) else ax
        hx = np.nonzero(hole[W // 2:] == False)[0]
        hr = W // 2 + int(hx[0]) if len(hx) else ax + aw
        x0_, x1_ = min(ax, hl), max(ax + aw, hr)
        t["_artwin"] = (x0_, top, x1_ - x0_, bot - top)
        scx, scy, ssz = COMBO_SPHERE[t["combo_corners"]]
        t["expansion_ring"] = (scx - ssz // 2, scy - ssz // 2); t["expansion_size"] = ssz; t["expansion_bare"] = True
        t["expansion_halo"] = COMBO_SPHERE_HALO[t["combo_corners"]]
        t["copyright"] = (t.get("copyright_x", 1404), COMBO_COPYRIGHT_CY - ah // 2, 36, ah)
    if card.get("no_lore_box") and t.get("nolore_disc"):   # #62: the PC sets the Episode I disc in the left margin by the window top
        t["_nolore_disc"] = t["nolore_disc"]
    if "card_type" in t:
        t["card_type"] = (t["card_type"][0], t["card_type"][1] - D, t["card_type"][2], t["card_type"][3])
    if "stats_y" in t:   # characters: the stat bar rides up with the text box (carbonite captives: The Mythrol)
        t["stats_y"] = t["stats_y"] - D
    if "banner_icon" in t:
        t["banner_icon"] = (t["banner_icon"][0], t["banner_icon"][1] - D)
    return p, t, 0, 0


def loc_grow(card: dict) -> tuple[int, int]:
    """Two-line site texts: the slips print a taller text box (by ~14 slip px = 28 px here) and move that half's title
    bar and icons toward the art (VS13: Outpost, AT-AT: Deployment Platform, Dungeon, ISB Sector Office)."""
    if card.get("lang") == "ja":   # rev 83: Takara's taller site text boxes (lang_ja.site_frame_rows; the art window is kept)
        import lang_ja
        return lang_ja.SITE_SHIFT, lang_ja.SITE_SHIFT
    if not card.get("text_lines"):
        return 0, 0
    return (28 if "\n" in card.get("game_text", "") else 0), (28 if "\n" in card.get("dark_text", "") else 0)


def starship_frame(frame: Image.Image, card: dict, t: dict, DL: int, DD: int) -> Image.Image:
    """Starship / vehicle site frames as Decipher prints them (Bill 2026-10-14): the frame field is painted blue while
    the title bars, Force slots and text boxes keep their silver (Light) and black (Dark) with silver bevels.
    ls-starship = Home One: War Room (Death Star II): blue paint worn through to the silver in chips and scuffs;
    ds-starship = Executor: Comm Station (Dagobah): smooth deeper blue. Colours sampled from those scans."""
    import numpy as np
    fa = np.array(frame).astype(float)
    H, Wd = fa.shape[:2]
    keep = np.zeros((H, Wd), bool)
    def E(n, slot0):
        return (slot0 - (n - 1) * t["slot_pitch"] - 55 - 4) if n else 1790
    lb = max(1574, E(len(card.get("light_icons", [])), t["ls_slot0"]))
    db = 2072 - max(1581, E(len(card.get("dark_icons", [])), t["ls_slot0"]))
    m = 4   # bevels stay silver
    for x0, y0, x1, y1 in ((163, 1135 - DL, 444, 1252 - DL), (440, 1135 - DL, lb + 2, 1252 - DL),   # Light slot, bar
                           (163, 1252 - DL, 1900, 1370),                                              # Light text box
                           (163, 106, 1900, 225 + DD),                                                # Dark text box
                           (db - 2, 225 + DD, 1634, 336 + DD), (1630, 225 + DD, 1900, 336 + DD)):     # Dark bar, slot
        keep[max(0, y0 - m):y1 + m, max(0, x0 - m):x1 + m] = True
    if card["frame_style"] == "ls-starship":   # Home One keeps a silver rim round the art window
        ax0, ay0, ax1, ay1 = 188, 382 + DD, 1883, 1095 - DL
        ring = np.zeros_like(keep); ring[ay0 - 12:ay1 + 12, ax0 - 12:ax1 + 12] = True; ring[ay0:ay1, ax0:ax1] = False
        keep |= ring
    rgb = fa[:, :, :3]
    silver = (np.abs(rgb[:, :, 0] - rgb[:, :, 2]) < 30) & (rgb.mean(axis=2) > 80) & (fa[:, :, 3] > 0)
    paint = silver & ~keep
    lum = rgb.mean(axis=2, keepdims=True) / 172.0
    dc = bool(card.get("decipher_print"))   # rev 84: Decipher's printed blue, sampled on the margins of 9 printed sites
    if card["frame_style"] == "ls-starship" and dc:
        # printed Light: Sandcrawler: Loading Bay (33, 105, 165), Home One: War Room (36, 107, 157); ours was (41, 128, 175)
        col = np.array([32.4, 97.7, 149.0], float)
        # rev 84 (site wear): Decipher's worn paint, the per-pixel median of four printed Light faces
        # (tools/make_site_wear.py): large scratched patches, heaviest on the strips beside the picture, a silver rim
        wm = np.array(Image.open(ASSETS / "frames/site-wear-light.png").convert("L")) > 127
        if DL or DD:   # a taller text box moved the frame's rows (loc_frame): move the wear with them
            old = wm.copy()
            if DL:
                wm[1096 - DL:1320 - DL] = old[1096:1320]; wm[1320 - DL:1320] = old[1272:1272 + DL]
            if DD:
                wm[160 + DD:381 + DD] = old[160:381]; wm[160:160 + DD] = old[122:122 + DD]
        paint &= ~wm
    elif card["frame_style"] == "ls-starship":
        col = np.array([38, 118, 162], float)
        import zlib   # rev 57: str hash() is salted per process, so the worn-paint pattern changed on every run
        rng = np.random.default_rng(zlib.crc32(card["id"].encode("utf-8")))
        from PIL import ImageFilter
        chips = np.zeros((H, Wd))
        for sc, wgt in ((24, 1.0), (9, 0.6), (4, 0.35)):   # worn paint: multi-scale blotches, more of them near the rim
            n = rng.random((H // sc + 2, Wd // sc + 2))
            chips += wgt * np.array(Image.fromarray((n * 255).astype(np.uint8)).resize((Wd + 2 * sc, H + 2 * sc), Image.BICUBIC))[sc:sc + H, sc:sc + Wd] / 255.0
        yy, xx = np.mgrid[0:H, 0:Wd]
        edge = np.minimum.reduce([xx - 70, Wd - 74 - xx, yy - 70, H - 90 - yy]).clip(0, 400) / 400.0
        worn = chips > (1.47 + 0.18 * edge)
        worn = np.array(Image.fromarray((worn * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(3))) > 0
        paint &= ~worn
    else:
        # printed Dark: Executor: Comm Station (41, 99, 142), Droid Junkheap (32, 99, 142), Sail Barge (32, 96, 140),
        # Executor: Docking Bay (35, 99, 140); ours was (19, 102, 172)
        col = np.array([33.2, 91.3, 131.2] if dc else [18, 95, 160], float)
    tint = np.clip(lum * col * 1.08, 0, 255)
    rgb[paint] = tint[paint]
    fa[:, :, :3] = rgb
    return Image.fromarray(fa.astype(np.uint8), "RGBA")


def loc_frame(card: dict, t: dict) -> Path:
    """Assemble a landscape location frame for this card from Bardez's layers: light-saber glows under the
    frame's force-icon holes, the icon boxes packed from the outside in (as Decipher printed them), scomp-link
    rings. Icons are given per side, outermost first: e.g. ["scomp", "planet", "interior", "underground"]."""
    fx, fy = t["frame_off"]
    frame = Image.open(ASSETS / "frames/loc-site.png").convert("RGBA")
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    glow = Image.open(LOC / "force-light.png").convert("RGBA")
    gx, gy = t["ls_force"]
    DL, DD = loc_grow(card)
    if card.get("light_force", True):
        nl = int(card.get("light_force_count") or 1)
        for k in range(nl):   # two Light Force icons = two sabers in the slot (Tatooine: Cantina), the Dark rule mirrored
            pos = (fx + gx + ((40 + k * 64) if nl > 1 else 0), fy + gy - DL)
            if k == 0:
                canvas.alpha_composite(glow, pos)
            else:
                from PIL import ImageChops
                reg = canvas.crop((pos[0], pos[1], pos[0] + glow.width, pos[1] + glow.height))
                canvas.paste(ImageChops.lighter(reg.convert("RGB"), glow.convert("RGB")).convert("RGBA"), pos)
    if card.get("dark_force", False):
        g = Image.open(LOC / "force-dark.png").convert("RGBA").rotate(180)   # the Dark Force icon is the red saber
        # mirror of the light glow box about the card centre (frame coords: x' = 2071-x-w, y' = 1479-y-h)
        n = int(card.get("dark_force_count") or 1)
        for k in range(n):   # two Dark Force icons print two sabers in the slot (VS13 #19, #21, #22)
            off = (-40 - k * 64) if n > 1 else 0
            pos = (fx + 2071 - gx - glow.width + off, fy + 1479 - gy - glow.height + DD)
            if k == 0:
                canvas.alpha_composite(g, pos)
            else:   # the glow bitmaps are opaque black around the saber: lighten, not cover
                from PIL import ImageChops
                reg = canvas.crop((pos[0], pos[1], pos[0] + g.width, pos[1] + g.height))
                canvas.paste(ImageChops.lighter(reg.convert("RGB"), g.convert("RGB")).convert("RGBA"), pos)
    if card.get("frame_tint"):   # starship-site frames the slips print in blue (Executor / Redemption, VS13)
        import numpy as np
        fa = np.array(frame).astype(float)
        lum = fa[:, :, :3].mean(axis=2, keepdims=True) / 172.0   # silver ≈ 172 → the slip's colour
        silver = (np.abs(fa[:, :, 0] - fa[:, :, 2]) < 25) & (fa[:, :, :3].mean(axis=2) > 90)
        tint = np.clip(lum * np.array(card["frame_tint"], dtype=float), 0, 255)
        fa[:, :, :3] = np.where(silver[:, :, None], tint, fa[:, :, :3])
        frame = Image.fromarray(fa.astype(np.uint8), "RGBA")
    # The slips run the title bar right up to the first icon box: slide the bar's end cap over the frame's two
    # default boxes and fill the rest with plain silver (light bar, then the dark bar in the 180°-turned frame).
    def extend_bar(img, n, y0, y1, cap1):
        E = (t["ls_slot0"] - (n - 1) * t["slot_pitch"] - 55 - 4) if n else 1790
        S = E - cap1
        if S <= 0:
            return img
        img = img.copy()
        img.alpha_composite(img.crop((1795, y0, 1795 + 1790 - E, y1)), (E, y0)) if E < 1790 else None
        img.alpha_composite(img.crop((1300, y0, cap1, y1)), (1300 + S, y0))
        return img
    frame = extend_bar(frame, len(card.get("light_icons", [])), 1134, 1252, 1574)
    frame = extend_bar(frame.rotate(180), len(card.get("dark_icons", [])), 1155, 1270, 1581).rotate(180)
    if card.get("lang") == "ja":   # rev 83: Takara moved the bars, not the art window's edges
        import numpy as np, lang_ja
        fa = np.array(frame); lang_ja.site_frame_rows(fa, fa.copy(), DL)
        frame = Image.fromarray(fa, "RGBA")
    elif DL or DD:   # taller text box: slide the title band toward the art, stretch the box interior
        import numpy as np
        fa = np.array(frame); old = fa.copy()
        if DL:
            fa[1096 - DL:1320 - DL] = old[1096:1320]; fa[1320 - DL:1320] = old[1272:1272 + DL]
        if DD:
            fa[160 + DD:381 + DD] = old[160:381]; fa[160:160 + DD] = old[122:122 + DD]
        frame = Image.fromarray(fa, "RGBA")
    if card.get("frame_style") in ("ls-starship", "ds-starship"):
        frame = starship_frame(frame, card, t, DL, DD)
    canvas.alpha_composite(frame, (fx, fy))
    if card.get("lang") == "ja":   # rev 83: the Force glows moved with the bars; keep their black surround out of the art window
        import numpy as np
        ca, fa_ = np.array(canvas), np.array(frame)
        hole = fa_[383:1096, 188:1884, 3] == 0
        ca[fy + 383:fy + 1096, fx + 188:fx + 1884, 3][hole] = 0
        canvas = Image.fromarray(ca, "RGBA")
    ly = t["slot_y"]
    dy = 1479 - ly - 111
    box = Image.open(LOC / "box.png").convert("RGBA")
    ring = Image.open(LOC / "scomp.png").convert("RGBA")

    def place(icons, light):
        # Boxes are cut from the printed Hoth card (brighter than Bardez's), 100×94, sitting inside the title bar.
        by = ly - 7 - DL
        dby = 1479 - (ly - 7) - 94 + DD
        for k, name in enumerate(icons):
            cx = (t["ls_slot0"] - k * t["slot_pitch"]) if light else (t["ds_slot0"] + k * t["slot_pitch"])
            if name == "scomp":
                r = Image.open(LOC / "scanring.png").convert("RGBA")
                y = by - 5 if light else dby - 5
                canvas.alpha_composite(r if light else r.rotate(180), (fx + cx - 52, fy + y))
                continue
            sb = LOC / f"scanbox-{name}.png"
            if sb.exists():
                b = Image.open(sb).convert("RGBA")
                if not light:
                    b = b.rotate(180)
                canvas.alpha_composite(b, (fx + cx - 50, fy + (by if light else dby)))
                continue
            y = (ly - DL) if light else (dy + DD)
            b = box if light else box.rotate(180)
            canvas.alpha_composite(b, (fx + cx - 55, fy + y))
            ic = Image.open(LOC / LOC_ICON_FILES[name]).convert("RGBA")
            if not light:
                ic = ic.rotate(180)
            canvas.alpha_composite(ic, (fx + cx - ic.width // 2, fy + y + 55 - ic.height // 2))

    place(card.get("light_icons", []) if not card.get("light_half_absent") else [], True)
    place(card.get("dark_icons", []) if not card.get("dark_half_absent") else [], False)
    if card.get("light_half_absent") or card.get("dark_half_absent"):   # full-art AI / ALT site: open that half to the art
        import numpy as np
        ca = np.array(canvas)
        if card.get("dark_half_absent"): ca[:fy + 380, :, 3] = 0
        if card.get("light_half_absent"): ca[fy + 1010:, :, 3] = 0
        canvas = Image.fromarray(ca)
    p = OUT / f"_frame_{card['id']}.png"
    canvas.save(p)
    return p


def sys_frame(card: dict, t: dict) -> Path:
    """Portrait system: force glows under the bar assembly's force holes, planet icon(s), parsec boxes."""
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if card.get("light_force", True):
        g = Image.open(LOC / "sysforce-light.png").convert("RGBA")
        n = int(card.get("light_force_count") or 1)
        canvas.alpha_composite(g, t["ls_force"])
        if n > 1:   # two Light Force icons = a second saber beside the first (Alderaan (Blown Away) (V))
            import numpy as np
            ga = np.array(g).astype(float); lum = ga[:, :, :3].max(axis=2)
            ga[:, :, 3] = np.clip(lum * 1.4, 0, 255) * (ga[:, :, 3] > 250); ga[:48] = 0
            sab = Image.fromarray(ga.astype(np.uint8), "RGBA")
            for k in range(1, n):
                canvas.alpha_composite(sab, (t["ls_force"][0] + 82 * k, t["ls_force"][1]))
    if card.get("dark_force", False):
        g = Image.open(LOC / "sysforce-dark.png").convert("RGBA")
        canvas.alpha_composite(g, t["ds_force"])
        n = int(card.get("dark_force_count") or 1)
        if n > 1:   # two Dark Force icons (Dagobah): the Light rule mirrored — second saber left of the first
            import numpy as np
            ga = np.array(g).astype(float); lum = ga[:, :, :3].max(axis=2)
            ga[:, :, 3] = np.clip(lum * 1.4, 0, 255) * (ga[:, :, 3] > 250); ga[-48:] = 0
            sab = Image.fromarray(ga.astype(np.uint8), "RGBA")
            for k in range(1, n):
                canvas.alpha_composite(sab, (t["ds_force"][0] - 82 * k, t["ds_force"][1]))
    fx, fy = t["frame_off"]
    sframe = Image.open(ASSETS / t["frame_png"]).convert("RGBA")
    if card.get("lang") == "ja":   # rev 83: Takara's taller system text boxes (bars moved toward the art)
        import numpy as np, lang_ja
        fa = np.array(sframe); lang_ja.system_frame_rows(fa, fa.copy())
        sframe = Image.fromarray(fa, "RGBA")
    canvas.alpha_composite(sframe, (fx, fy))
    for half, light in (("light", True), ("dark", False)):
        # a system that prints one half only (Death Star: no Light Side bar or text): open the other half to the art
        if card.get(f"{half}_half_absent"):
            import numpy as np
            ca = np.array(canvas); y0, y1 = (1590, 2110) if light else (110, 630)
            ca[y0:y1, 90:1545, 3] = 0; canvas = Image.fromarray(ca)
    if card.get("parsec") in (None, ""):   # sectors (Asteroid Field, Clouds) print no parsec box: open it to the art
        import numpy as np
        ca = np.array(canvas)
        for k in ("ls_parsec", "ds_parsec"):
            x, y, w, h = t[k]
            ca[y - 12:y + h + 12, x - 14:x + w + 16, 3] = 0
        canvas = Image.fromarray(ca)
    for key, light in (("light_icons", True), ("dark_icons", False)):
        if card.get("light_half_absent" if light else "dark_half_absent"):
            continue
        for name in card.get(key, [])[:1]:
            cx, cy = t["ls_icon"] if light else t["ds_icon"]
            sb = LOC / f"scanbox-{name}.png"
            if sb.exists():   # printed-card box + icon (brighter than Bardez's), scaled into the frame's black box
                ic = Image.open(sb).convert("RGBA").resize((89, 86), Image.LANCZOS)
            else:
                ic = Image.open(LOC / LOC_ICON_FILES[name]).convert("RGBA")
            if not light:
                ic = ic.rotate(180)
            canvas.alpha_composite(ic, (cx - ic.width // 2, cy - ic.height // 2))
    p = OUT / f"_frame_{card['id']}.png"
    canvas.save(p)
    return p


def loc_text_div(card: dict, light: bool, x, y, w, h, pre: str, ja: bool, system: bool = False) -> str:
    """A location half's text box (Light: game_text, Dark: dark_text, turned 180° by its CSS). rev 83: a Japanese half
    with printed line breaks is set at Takara's size for those lines, not fitted."""
    cls, key = ("ltext", "game_text") if light else ("dtext", "dark_text")
    if ja:
        import lang_ja
        ll = lang_ja.loc_lines(card, light, w, game_text_html, system)
        if ll:
            return f'<div class="{cls}" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px{ll[0]}">{ll[1]}</div>'
    return (f'<div class="{cls} fit{pre}"{fit_attrs(card, "game_text")} style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px">'
            f'<span>{game_text_html(card[key])}</span></div>')


def inline_set_mark(mark: str) -> str:
    """A set mark sized for a line of game text (wrapped so it sits on the baseline like the other inline icons)."""
    html = set_mark_html(mark, 0, 0, 40, slot=False).replace("position:absolute;", "position:relative;display:inline-block;vertical-align:-14px;")
    return re.sub(r"left:-?\d+px;top:-?\d+px;", "", html)


def set_mark_html(mark: str, cx: float, cy: float, ss: float, slot: bool = True) -> str:
    """Inline SVG (uses the page's fonts) centred on the template's set-icon slot. mark = "pc:<n>" or "vb:<n>".
    Sizes/placement measured on Holotable faces (Captain Lando Calrissian VS13, Admiral Raddus VS9, A Good Blaster
    At Your Side VS0, 2-1B (Too-Onebee) (V) Virtual Block 2)."""
    kind, _, num = str(mark).partition(":")
    if kind == "vb":   # Virtual Block diamond: black, white edge, number over a V chevron
        w = ss * 1.55; h = w * .86
        # rev 71, measured on the PC's Virtual Block gifs (Faithful Service (V), Leia Seeker (V), Master Luke (V), ISB Central
        # Commander, Death Star Sentry (V), Local Uprising (V)): a flat black diamond face (about 2:1) with a thin light
        # edge, over a white bevel along its two lower edges, the number standing up out of the face; 92 % of the rev 41
        # size, on the text box's lower-right corner, ~18 px higher and ~8 px further left (745 px face) than rev 41
        w = ss * 1.42; h = w * .86
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 86" width="{w:.0f}" height="{h:.0f}">'
               '<polyline points="4,45 50,76 96,45" fill="none" stroke="#fff" stroke-width="8" stroke-linejoin="miter"/>'
               '<polygon points="50,12 96,40 50,68 4,40" fill="#111" stroke="#cfcfcf" stroke-width="2.5" stroke-linejoin="round"/>'
               f'<text x="50" y="56" text-anchor="middle" font-family="AGMedExt" font-size="{50 if len(num) < 2 else 38}" fill="#fff" '
               f'stroke="#111" stroke-width="2" paint-order="stroke">{esc(num)}</text></svg>')
        return f'<div style="position:absolute;left:{cx - w / 2 + ss * .25 - (16 if slot else 0):.0f}px;top:{cy - h / 2 + ss * .85 - (36 if slot else 0):.0f}px;line-height:0">{svg}</div>'
    gold = num in ("0", "D", "P")   # Set 0 and the Virtual Defensive Shields: gold ring (PC Game Aid sheet)
    ring_a, ring_b = ("#8a6a1c", "#e6c766") if gold else ("#0b3a74", "#5a9bd2")
    edge = "#c97a12" if gold else "#1d4aa0"
    w, h = ss * 2.0, ss * 1.5
    fs_ = card_ctx.get("_set_digit_fs", 142)
    ecx_, ecy_, erot_ = card_ctx.get("_set_ring", (100, 80, -28))
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 150" width="{w:.0f}" height="{h:.0f}">'
           f'<defs><linearGradient id="rg{num}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{ring_b}"/>'
           f'<stop offset=".55" stop-color="{ring_a}"/><stop offset="1" stop-color="{ring_b}"/></linearGradient></defs>'
           # rev 84 (sites 2): the printed ring is a shorter, rounder band tilted 38 degrees, centred on the digit, with a dark
           # navy edge (Ghost, Bright Hope, Azure Angel, Finalizer: outer extent 46.5 x 42 px at 745 for a 35 px digit; ours
           # was 57 x 39, thin and pale): rx 62, ry 36 (centre line), the template's band width, a dark edge 4 units wider
           f'<ellipse cx="{ecx_}" cy="{ecy_}" rx="62" ry="36" transform="rotate(-38 {ecx_} {ecy_})" fill="none" stroke="{"#5a420c" if gold else "#0a2152"}" stroke-width="{card_ctx.get('_set_ring_w', 16) + 4}"/>'
           f'<ellipse cx="{ecx_}" cy="{ecy_}" rx="62" ry="36" transform="rotate(-38 {ecx_} {ecy_})" fill="none" stroke="url(#rg{num})" stroke-width="{card_ctx.get('_set_ring_w', 16)}"/>'
           f'<text x="100" y="{124 + (fs_ - 142) * .6:.0f}" text-anchor="middle" font-family="AGBoldCnA" font-size="{fs_}" letter-spacing="-3" '
           f'transform="translate(100 0) scale(1.18 1) translate(-100 0)" '
           f'fill="#fff" stroke="{edge}" stroke-width="9" paint-order="stroke" stroke-linejoin="round">{esc(num)}</text></svg>')
    return f'<div style="position:absolute;left:{cx - w / 2 - ss * .1:.0f}px;top:{cy - h / 2 + ss * .2:.0f}px;line-height:0">{svg}</div>'


_HOLE: dict = {}


_FRAME_BOTTOM: dict = {}


def frame_bottom(fr, fy: int, canvas_h: int = 2220) -> int | None:
    """Master row of the frame's bottom edge: the last row where the frame image is opaque across its middle third
    (the bottom bar). Frames that fill the whole card (Admiral's Orders, game aids) give None. Bill 2026-11-02: the
    margin strip starts under each card's own frame (character frames end up to 6 px lower than Effects)."""
    key = (str(fr), fy, canvas_h)
    if key not in _FRAME_BOTTOM:
        import numpy as np
        im = fr if isinstance(fr, Image.Image) else Image.open(fr)
        a = np.asarray(im.convert("RGBA"))[:, :, 3] > 128
        w = a.shape[1]
        rows = np.where(a[:, w // 3: 2 * w // 3].mean(axis=1) > 0.9)[0]
        y = int(rows.max()) + fy if len(rows) else None
        _FRAME_BOTTOM[key] = y if y is not None and canvas_h - 180 < y < canvas_h - 125 else None
    return _FRAME_BOTTOM[key]


def frame_hole(t: dict) -> tuple:
    """The transparent window of the template's frame around its art box (card px), measured once per frame."""
    fr, fx, fy = t["frame"]
    key = (fr, fx, fy, t["art"])
    if key not in _HOLE:
        import numpy as np
        a = np.array(Image.open(ASSETS / fr).convert("RGBA"))[:, :, 3] < 128
        ax, ay, aw, ah = t["art"]
        cx, cy = ax + aw // 2 - fx, ay + ah // 2 - fy
        def run(line, i, step):
            while 0 <= i + step < len(line) and line[i + step]:
                i += step
            return i
        rows = [run(a[cy + d], cx, -1) for d in (-ah // 3, 0, ah // 3)], [run(a[cy + d], cx, 1) for d in (-ah // 3, 0, ah // 3)]
        cols = [run(a[:, cx + d], cy, -1) for d in (-aw // 3, 0, aw // 3)], [run(a[:, cx + d], cy, 1) for d in (-aw // 3, 0, aw // 3)]
        _HOLE[key] = (min(rows[0]) + fx, min(cols[0]) + fy, max(rows[1]) + fx + 1, max(cols[1]) + fy + 1)
    return _HOLE[key]


# PC label presets, measured on the PC's 745 px Holotable faces (×2 + Holotable offset = master px): errata marks on
# Obi-Wan's Journal, Grappling Hook, Luke's Blaster Pistol (D-E1/D-E2), Fall Of A Jedi (E1), Ominous Rumors (E2),
# Surprise Assault (E3): right edge x≈1482, cap top ≈2090, baseline ≈2130 (cap 40–42 px), white heavy oblique.
# Titles bottom-left (V21–27): x≈148, same baseline. "Original concept by …" (General Poe Dameron, Baron Soontir Fel
# (V)): centred, baseline ≈2062, white condensed italic with a dark edge. Offsets are from the card's edges, so the
# presets also work on landscape cards.
LABEL_PRESETS = {
    "errata":      dict(anchor="right",  x=-150, y=-91, size=57, font="AGBoldCnA", italic=True,  stroke=2.8, color="#ffffff", sx=1.38,
                         skew=8.5, mark=True),
    "bottom-left": dict(anchor="left",   x=148,  y=-90, size=55, font="AGBoldCnA", italic=False, stroke=0.6, color="#ffffff", sx=1.30),
    "bottom-right": dict(anchor="right", x=-150, y=-90, size=55, font="AGBoldCnA", italic=False, stroke=0.6, color="#ffffff", sx=1.30),
    "concept":     dict(anchor="center", x=2,    y=-158, size=54, font="AGCn",     italic=True,  stroke=1.0, color="#ffffff", edge="#000000"),
    "top-right":   dict(anchor="right",  x=-150, y=128, size=50, font="AGBoldCnA", italic=False, stroke=1.0, color="#ffffff", sx=1.33),
    # (AI)/(ALT) stamp with the Players Committee logo to its left (swccg-guild/work#100), measured on 105 PC AI faces:
    # text right edge x 706 (667 when an errata mark follows), logo 52 x 30 px, 8 px gap, same face as the errata mark
    "ai":          dict(anchor="right",  x=-150, y=-91, size=50, font="AGMedExt", italic=True,  stroke=0.8, color="#ffffff", sx=1.0,
                         skew=12, logo=True),
}
LABEL_FONTS = {"bold": "AGBoldCnA", "text": "AGCn", "medium": "AGMedCn", "number": "AGMedExt", "title": "HoloTitle"}


def card_labels(card: dict) -> list:
    out = []
    if card.get("errata_mark"):
        out.append({"preset": "errata", "text": str(card["errata_mark"])})
    for lb in (card.get("labels") or [])[:12]:
        if isinstance(lb, dict) and str(lb.get("text") or "").strip():
            out.append(lb)
    return out


def _mark_html(text: str, size: float, col: str, stroke: float) -> str:
    """PC errata mark glyphs (Bill 2026-11-01). AGBoldCnA's figures are 665/1000 high against 706 for the capitals, so a
    plain "1" stands about 6% short of the "E" and reads as dropped below it; the PC's mark sets its figures at cap height.
    Figures are stretched to cap height (and a little wider, as the PC's "1" is), and the hyphen is the PC's short, heavy
    bar (8 x 4-5 px on a 745 px card) instead of the font's long thin one. Measured on Obi-Wan's Journal, Frustration,
    Luke's Blaster Pistol, Tentacle, Grappling Hook, Fallen Order and Ominous Rumors (V) (Holotable gifs)."""
    out = []
    for ch in text:
        if ch.isdigit():
            out.append(f'<span style="display:inline-block;transform:scale({1.10 if ch == "1" else 1.0},1.045);transform-origin:left bottom;'
                       f'margin:0 {0.06 * size:.1f}px 0 {0.05 * size:.1f}px">{esc(ch)}</span>')
        elif ch in "-\u2010\u2011\u2012\u2013":
            w, h = 0.155 * size, 0.12 * size
            out.append(f'<span style="display:inline-block;width:{w:.1f}px;height:{h:.1f}px;background:{col};'
                       f'vertical-align:{0.20 * size:.1f}px;margin:0 {0.035 * size:.1f}px 0 {0.07 * size:.1f}px;'
                       f'box-shadow:0 0 0 {stroke / 2:.1f}px {col}"></span>')
        else:
            out.append(esc(ch))
    return "".join(out)


def label_html(lb: dict, W: int, H: int) -> str:
    p = dict(LABEL_PRESETS.get(lb.get("preset") or "", LABEL_PRESETS["bottom-right"] if lb.get("preset") else
                               dict(anchor="left", x=300, y=300, size=48, font="AGBoldCnA", italic=False, stroke=0, color="#ffffff")))
    for k in ("anchor", "x", "y", "size", "italic", "stroke", "color", "edge", "sx", "skew", "e_x"):
        if lb.get(k) is not None:
            p[k] = lb[k]
    if lb.get("font"):
        p["font"] = LABEL_FONTS.get(str(lb["font"]), p["font"])
    num = lambda v, d, lo, hi: max(lo, min(hi, float(v))) if isinstance(v, (int, float)) else d
    size = num(p["size"], 52, 10, 200)
    x = num(p["x"], 0, -W, W); y = num(p["y"], 0, -H, H)
    x = (W / 2 + x) if p["anchor"] == "center" else (W + x if x < 0 else x)
    base = H + y if y < 0 else y                                  # the label's baseline
    col = p["color"] if re.fullmatch(r"#[0-9a-fA-F]{3,8}", str(p["color"])) else "#ffffff"
    edge = p.get("edge") if re.fullmatch(r"#[0-9a-fA-F]{3,8}", str(p.get("edge") or "")) else None
    stroke = num(p.get("stroke"), 0, 0, 6)
    tr = {"left": "0", "right": "-100%", "center": "-50%"}.get(p["anchor"], "0")
    skew = (f"skewX(-{num(p.get('skew'), 12, 0, 30):g}deg) " if p.get("italic") else "") + \
        (f"scaleX({num(p.get('sx'), 1, 0.5, 2):.3f})" if p.get("sx") else "")
    sh = f"text-shadow:2px 3px 3px {edge},0 0 2px {edge};" if edge else ""
    text = str(lb.get("text"))[:80]
    common = (f'font-family:{p["font"]};font-size:{size:.0f}px;line-height:1;color:{col};white-space:nowrap;'
              f'-webkit-text-stroke:{stroke}px {col};{sh}')
    # the box's top = baseline - 0.80 x size (the Akzidenz faces' ascent at line-height 1)
    top = base - 0.80 * size
    m = re.fullmatch(r"(.*?)(E\d{0,2})", text) if p.get("mark") else None
    if m:
        # The PC stamps the "E1"/"E2" part at a fixed spot and sets any prefix ("D-") to its left: the E's left edge is
        # at x 673 on every 745 px Holotable errata face measured (D-E1, D-E2, E1, E2).
        ex = num(p.get("e_x"), W - 220, -W, W); ex = W + ex if ex < 0 else ex
        org = "left bottom"
        html = (f'<div class="label" style="position:absolute;left:{ex:.0f}px;top:{top:.0f}px;transform:{skew};'
                f'transform-origin:{org};{common}">{_mark_html(m.group(2), size, col, stroke)}</div>')
        if m.group(1):
            html += (f'<div class="label" style="position:absolute;left:{ex:.0f}px;top:{top:.0f}px;transform:translateX(-100%) {skew};'
                     f'transform-origin:right bottom;{common}">{_mark_html(m.group(1), size, col, stroke)}</div>')
        return html
    if p.get("logo"):   # the PC logo (white box, black lettering) left of the stamp, upright; the stamp text oblique
        lw, lh = 110, 64   # 52 x 30 px on the 745 px face (x 2.19); bottom 6 px below the stamp's baseline
        return (f'<div class="label ai-stamp" style="position:absolute;left:{x:.0f}px;top:{top:.0f}px;transform:translateX(-100%);'
                f'{common};display:flex;align-items:flex-end;gap:4px">'
                f'<img src="{data_uri(ASSETS / "icons/pc-gameaid-named/pc-logo-stamp.png")}" style="width:{lw}px;height:{lh}px;'
                f'margin-bottom:{0.2 * size - 12:.0f}px">'
                f'<span style="display:inline-block;transform:{skew};transform-origin:right bottom">{esc(text)}</span></div>')
    body = _mark_html(text, size, col, stroke) if p.get("mark") else esc(text)
    ip = str(lb.get("italic_part") or "")
    if ip and ip in text and not p.get("mark"):   # only part italic: the PC italicises a starship's name (Boba Fett In Slave I)
        a, _, b = text.partition(ip)
        body = (esc(a) + f'<span style="display:inline-block;transform:skewX(-10deg);transform-origin:left bottom">{esc(ip)}</span>' + esc(b))
    return (f'<div class="label" style="position:absolute;left:{x:.0f}px;top:{top:.0f}px;transform:translateX({tr}) {skew};'
            f'transform-origin:{"right" if p["anchor"] == "right" else "left"} bottom;{common}">{body}</div>')


def fit_attrs(card: dict, box: str) -> str:
    """Optional text-fit limits (card maker / API "text_fit"): {"max", "min", "ls_min", "lh_min"} for every text box, or
    keyed by box ("game_text", "lore") — the largest size that fits is searched between them (see fit_js)."""
    adj = card.get("text_adjust" if box == "game_text" else "lore_adjust")
    try:
        adj = max(-20.0, min(20.0, float(adj or 0)))
    except (TypeError, ValueError):
        adj = 0.0
    adj_attr = f' data-fit-adj="{adj:g}"' if adj else ""
    tf = card.get("text_fit")
    if not isinstance(tf, dict):
        return adj_attr
    tf = dict({k: v for k, v in tf.items() if not isinstance(v, dict)}, **(tf.get(box) if isinstance(tf.get(box), dict) else {}))
    out = []
    for k, attr, lo, hi in (("max", "fit-max", 20, 120), ("min", "fit-min", 12, 120), ("ls_min", "ls-min", -4, 2), ("lh_min", "lh-min", 0.8, 1.2)):
        try:
            if tf.get(k) is not None:
                out.append(f' data-{attr}="{max(lo, min(hi, float(tf[k]))):g}"')
        except (TypeError, ValueError):
            pass
    return "".join(out) + adj_attr


# rev 74: Virtual Legacy typesetting (Bill 2026-11-10: the same words must land on the same lines as the PC's card).
# The PC set its 2009-2014 slips in Akzidenz-Grotesk BE Condensed; gempdata/legacy_typeset.json holds each card's frame
# (left edge, line width, first baseline), size, tracking and pitch read from the PC's Virtual Legacy master list PDFs.
# PT = master px per PDF point (745 px Holotable card = 178.8 pt, master = 2 x Holotable + 35/36 px border).
PT = 2 * 745 / 178.8
PC_ASC, PC_DESC = 0.908, 0.25
PC_ICON_W = 55.5   # room an inline icon takes on a PC line (6.6 pt), master px   # HolotableTextPC hhea ascent / descent per em (CSS line boxes place the baseline from them)


# rev 74: Virtual Legacy piece positions measured against the PC's own cards (template match of each piece of 337 renders
# into the Virtual Legacy master list's full cards, median per template, Holotable px; tools/legacy/typeset/README.md).
# (dx, dy[, scale]) applied to the piece when the card is a Virtual Legacy card (pc_type). The discs under the sphere
# (ring_icons) were measured on their own: on most frames they sit where they were. Only offsets of 3 px or more seen
# on 3 or more cards.
PC_PIECE_FIX = {
    "ls-character-alien": {"expansion": (11, 10), "ring_icons": (11, 14.5), "icons": (-4, 6, 1.07), "set_mark": (-1.5, 3)},
    "ls-character-rebel": {"expansion": (1, 12), "ring_icons": (2.5, 4), "icons": (-4.5, 7, 1.06), "set_mark": (-2, 3)},
    "ls-character-alien-rebel": {"expansion": (1, 12), "icons": (-4.5, 7, 1.06), "set_mark": (-2, 3)},
    "ls-character-droid-dc": {"expansion": (0, 14), "icons": (-5, 6, 1.06), "set_mark": (-1, 4)},
    "ls-effect": {"expansion": (2, 8), "ring_icons": (3, 2), "set_mark": (-1, -6)},
    "ls-interrupt": {"expansion": (4, 7), "ring_icons": (4.5, 5.5), "set_mark": (-1, -5)},
    "ls-weapon": {"expansion": (3.5, 8), "destiny": (1.5, -4.5), "set_mark": (2, 8)},
    "ls-device": {"set_mark": (1, 7), "destiny": (1.5, -4.5)},
    "ls-starship-starfighter": {"expansion": (2, 5), "ring_icons": (4.5, 5.5), "destiny": (-2, -8), "deploy": (-3, -8), "forfeit": (-2, -3)},
    "ls-vehicle": {"expansion": (2, 4), "destiny": (-2, -10), "deploy": (-2, -7), "forfeit": (-1.5, -2.5)},
    "ds-character-imperial": {"expansion": (3, 3), "icons": (4, 6, 1.08), "destiny": (2, -4), "set_mark": (3, -1)},
    "ds-character-alien": {"icons": (3, 0, 1.04), "destiny": (2, -5)},
    "ds-character-droid-dc": {"icons": (3.5, 1, 1.03), "destiny": (1, -5), "set_mark": (5, -2)},
    "ds-effect": {"set_mark": (-1, -7.5), "expansion": (3, 1)},
    "ds-effect-tall": {"set_mark": (-2, -9)},
    "ds-interrupt": {"set_mark": (-1, -7.5), "expansion": (7, 3)},
    "ds-weapon": {"destiny": (0, -7), "set_mark": (3, 1.5)},
    "ds-device": {"destiny": (0, -8), "set_mark": (3, 3)},
    "ds-shield-dc": {"destiny": (2.5, -5.5), "set_mark": (5, -1.5)},
    "ds-shield-vb": {"destiny": (2.5, -5.5), "set_mark": (5, -1.5)},
    "ds-shield-fade": {"destiny": (2.5, -7), "set_mark": (5, -1.5)},
    "ds-starship-starfighter": {"destiny": (4.5, -6.5), "deploy": (3, -1)},
    "ds-vehicle": {"destiny": (3, -5), "icons": (4, 3, 1.1), "expansion": (6.5, 3)},
    "creature-dc": {"expansion": (8, 5), "destiny": (0, -4)},
    "creature-dc-pc": {"expansion": (8, 5), "destiny": (0, -4)},
}

PC_GROW_TEMPLATES = {"ls-effect", "ds-effect", "ls-interrupt", "ds-interrupt", "ls-weapon", "ds-weapon", "ls-device", "ds-device",
                     "ls-shield-dc", "ds-shield-dc", "ds-shield-vb"}   # characters: the PC kept them to five lines (none raised)

# rev 77: Episode I Podracers (Tatooine 11_47, 11_95-98; make_podracer_frames.py). The Effect frame with the printed
# Podracer top: straight title bar (ridge 336..360), plain rectangular lore box 276..1350 x 402..603, lore set flush left
# with no first-line indent (scan: text x 320..1292). The pilot flag badge (podracer_flag_box: the flag picture's window,
# x, y, w, h; bevel round it) sits between the type disc and the title; the title then starts at x 618 (printed bullet).
for _sd in ("ls", "ds"):
    _e = TEMPLATES[f"{_sd}-effect"]
    TEMPLATES[f"{_sd}-podracer"] = dict(_e, frame=(f"frames/{_sd}-podracer.png",) + _e["frame"][1:],
                                        lore=(313, 406, 1022, 196), lore_x=(317, 1330, 0, 0, 0.0),
                                        podracer_flag_box=(357, 174, 189, 153) if _sd == "ls" else (366, 183, 186, 144),
                                        podracer_title_x=617,   # rev 84: printed bullet at x 621, cap top y 204
                                        title=(407, 200, 867, 100) if _sd == "ls" else (403, 200, 871, 100),
                                        title_ls=0.3 if _sd == "ls" else 0.15,   # printed titles ~1.5 % tighter than the Effect's
                                        # rev 84: the destiny circle moved on the frame (make_podracer_frames DESTINY_SHIFT)
                                        # (the printed digit sits ~4-6 px above the circle's centre)
                                        destiny=(1325, 206, 104, 104) if _sd == "ls" else (1312, 197, 104, 104),
                                        disc_at=(185, 182) if _sd == "ls" else (192, 187),   # the type disc moved with its socket
                                        # rev 84: the printed Podracers set lore and game text ~3 % larger than the
                                        # Effect (line pitch unchanged) in their own measured boxes (STANDARD rev 84)
                                        lore_css={"fs": 59.6}, gt_size=63.9, gt_lh_add=-0.15,
                                        game_text=(312, 1664, 1050, 330) if _sd == "ls" else (312, 1666, 1006, 335),
                                        # rev 84: sphere 58 px across (outline incl.), centre Dark (1408, 435.5) / Light
                                        # (1410, 445); the Episode I disc under it 58 px, centre (1408, 536), Decipher's
                                        # printed disc (the one measured Episode I disc: tools/make_ep1_disc.py, rev 84 text and icons)
                                        expansion_size=56, expansion_ring=(1382, 417) if _sd == "ls" else (1380, 407), expansion_inset=2,
                                        ring_disc_size=58, ring_disc_dx=-3 if _sd == "ls" else -1,
                                        ring_disc_dy=4 if _sd == "ls" else 14,
                                        ring_disc_icons={"episode1": "icons/ep1-disc.png"},
                                        # rev 84: "PODRACER" printed 4 % smaller, tighter, 5 px lower (x 675..961 x 1521..1562)
                                        ctype_size=59.5, ctype_spacing=10.8,
                                        card_type=(269, 1512, 1109, 61) if _sd == "ls" else (269, 1511, 1109, 61),
                                        # rev 84: art window 5 px lower (frame band moved); the copyright line 2 % longer,
                                        # printed x 1425..1450 x 735..1352 on both sides
                                        art=(244, 666, 1143, 755) if _sd == "ls" else (254, 668, 1118, 765), copy_ls=1.0,
                                        copyright=(1420, 666, 36, 755) if _sd == "ls" else (1420, 661, 36, 765),
                                        decipher_tone=(_e["decipher_tone"][0], None, None))
    if f"{_sd}-effect" in PC_PIECE_FIX:
        PC_PIECE_FIX[f"{_sd}-podracer"] = PC_PIECE_FIX[f"{_sd}-effect"]
    PC_GROW_TEMPLATES.add(f"{_sd}-podracer")
_PC_ADV: dict = {}


# rev 84: Decipher's own placement of the expansion sphere and the vertical copyright line (card key decipher_print,
# set by the card maker for cards of Decipher's sets; VS remasters and Players Committee cards keep the template).
# Measured on printed scans (Holotable 745 px and 350 px faces, Decipher archive scans), registered to our render
# by an affine fit of the whole card (scratch tool m2.py; STANDARD rev 84). Per template: dc_sphere = centre x, y and
# diameter (master px) of the sphere with its own dark rim; dc_copy = centre x, y (master px) of the copyright line.
# rev 84: second affiliation disc: the title moves right by this much (was 170 everywhere). Measured title (bullet) start on
# printed two-disc faces registered to our renders: Dark 235-238 px at 745 (8 cards), Light Rebel frame 229-230 (4),
# Light Alien frame 231 (4; Tarfful's "original" face 243 is the outlier)
DISC2_TITLE_SHIFT = {"ls-character-rebel": 114, "ls-character-alien": 127}
DISC2_TITLE_SHIFT_DEFAULT = 136
# rev 84: Tatooine (set 11) prints the line in a taller face (cap 11.2 px at 745 against 10.5) with wide oval © / ®
# the height of the capitals (12.8 x 11.2 px at 745), set against the year / ampersand (8 printed cards, 497 px scans)
DC_COPY_TAT = {"size": 30, "ls": 0.8, "ring_w": 29, "ring_h": 24, "ring_b": 2.4, "ring_letter": 20, "ring_va": -3}
DC_COPY = {"size": 28, "ls": 1, "ws": 5, "cond": 0.83, "ring": 25, "ring_w": 2.2, "ring_letter": 18, "ring_va": -2, "ring_m": 1}
DC_SPHERE_BEVEL = (6, "rgba(104, 108, 112, 0.5)")   # rev 84: width (master px) and fill of the frame's bevel round the hole: it pulls the frame towards mid grey (darker on Light frames, lighter on Dark ones, as printed)
DC_PRINT: dict = {
    "creature-dc": {"dc_sphere": (1414, 440, 56), "dc_copy": (1442, 1017), "dc_copy_ink": "#000"},   # printed in black (Bubo, Worrt)
    "ds-character-alien": {"dc_sphere": (1409, 439, 56), "dc_copy": (1439, 1051)},
    "ds-character-droid-dc": {"dc_sphere": (1410, 438, 56), "dc_copy": (1438, 1048)},
    "ds-character-imperial": {"dc_sphere": (1413, 438, 56), "dc_copy": (1438, 1047)},
    "ds-device": {"dc_sphere": (1411, 444, 56), "dc_copy": (1441, 1037)},
    "ds-effect": {"dc_sphere": (1412, 432, 56), "dc_copy": (1439, 1035)},
    "ds-interrupt": {"dc_sphere": (1412, 433, 56), "dc_copy": (1441, 1034)},
    "ds-podracer": {"dc_copy": (1436, 1038)},   # sphere: the Podracer template's own (rev 84 Podracer agent, all five cards)
    "ds-shield-dc": {"dc_sphere": (1408, 436, 56), "dc_copy": (1433, 1036)},
    "ds-starship-starfighter": {"dc_sphere": (1402, 440, 56), "dc_copy": (1432, 1025)},
    "ds-vehicle": {"dc_sphere": (1408, 445, 56), "dc_copy": (1437, 1019)},
    "ds-weapon": {"dc_sphere": (1413, 441, 56), "dc_copy": (1439, 1039)},
    "ls-character-alien": {"dc_sphere": (1420, 435, 56), "dc_copy": (1448, 1041)},
    "ls-character-alien-rebel": {"dc_sphere": (1413, 440, 56), "dc_copy": (1433, 1054)},
    "ls-character-droid-dc": {"dc_sphere": (1416, 439, 56), "dc_copy": (1442, 1042)},
    "ls-character-rebel": {"dc_sphere": (1412, 441, 56), "dc_copy": (1439, 1044)},
    "ls-device": {"dc_sphere": (1411, 446, 56), "dc_copy": (1438, 1037)},
    "ls-effect": {"dc_sphere": (1413, 441, 56), "dc_copy": (1440, 1034)},
    "ls-interrupt": {"dc_sphere": (1414, 441, 56), "dc_copy": (1441, 1040)},
    "ls-podracer": {"dc_copy": (1430, 1036)},
    "ls-shield-dc": {"dc_sphere": (1410, 446, 56), "dc_copy": (1436, 1035)},
    "ls-starship-starfighter": {"dc_sphere": (1416, 445, 56), "dc_copy": (1440, 1016)},
    "ls-vehicle": {"dc_sphere": (1412, 446, 56), "dc_copy": (1440, 1014)},
    "ls-weapon": {"dc_sphere": (1413, 446, 56), "dc_copy": (1439, 1037)},
    # printed Jedi Tests: white line in the olive margin, 204-508 px (745) on It Is The Future You See, Size Matters Not,
    # You Must Confront Vader; sphere centre (683.5, 173.5) at 745
    "ls-jeditest-olive": {"dc_sphere": (1437, 419, 56), "dc_copy": (1444, 784), "dc_copy_ink": "#fff"},
    # Admiral's Orders: white line over the picture right of the text box (Battle Deployment, I'll Try Spinning: 715-978 px
    # at 745); drawn only over an uploaded / library picture, the printed scan carries its own
    "ls-admirals-order": {"dc_sphere": (1415, 440, 56), "dc_copy": (1440, 1764), "dc_copy_ink": "#fff", "dc_copy_unless_scan": True},
    "ds-admirals-order": {"dc_sphere": (1415, 440, 56), "dc_copy": (1440, 1764), "dc_copy_ink": "#fff", "dc_copy_unless_scan": True},
    # wide cards (the picture is the printed scan, which carries its own line): sphere 8-10 px (745) lower than the template
    "ds-starship-wide": {"dc_sphere": (1980, 464, 56)},       # Executor, Flagship Executor
    "ds-weapon-wide": {"dc_sphere": (1958, 472, 56)},         # Maul's Double-Bladed Lightsaber
    # sites: sphere 3 px right and larger (56); the line in black (the frame is silver on both sides), ~4 % larger than
    # on the portrait cards and ~20 px (745) lower than the template had it, ending well below the sphere (Sandcrawler:
    # Loading Bay, Tatooine: Podrace Arena, Cloud City: Upper Walkway)
    "loc-site": {"dc_sphere": (2022, 480, 56), "dc_copy": (2017, 840), "dc_copy_size": 29, "dc_copy_ink": "#000",
                 # rev 84: Episode I-era sites (Tatooine .. Theed, Light and Dark: 13 printed sites) carry Decipher's Episode I
                 # disc 99 px under the sphere, 56 px across (ours: 44 px, 77 px under it, over the end of the line); the
                 # sphere 4 px higher; the line ~12 % smaller and centred 110 px further from the sphere, ending ~40 px
                 # (745) short of the disc
                 "ep1": {"dc_sphere": (2022, 476, 56), "dc_copy": (2017, 950), "dc_copy_size": 25.5,
                         "ring_disc_size": 56, "ring_disc_dx": -2, "ring_disc_dy": 16,
                         "ring_disc_icons": {"episode1": "icons/ep1-disc.png"}}},
    # systems (rev 84, registered on the two bar assemblies of 16 Light and 17 Dark printed systems, every era): the sphere
    # 8.7 / 6.1 px (745) right / down of rev 84's spot on Light systems, 9.8 / 7.8 on Dark ones (measured turned, the
    # Dark half's seat: dc_system_ring_dark, pre-turn coordinates); the halves of the line 9.5 px in (Lucasfilm) / 4 px in
    # (Decipher) and 9-11 px higher; the left half reads top to bottom (letters facing the card, as the right half does):
    # dc_split_left_down
    "loc-system": {"dc_system_ring": (166, 200, 56), "dc_system_ring_dark": (169, 204, 56),
                   "dc_split": ((216, 1884), (1427, 1880)), "dc_split_left_down": True,
                   # Coruscant-set systems: Decipher's Episode I disc 100 px under the sphere, 56 px in a 74 px grey ring
                   "dc_system_ep1": (2, 100, 56, 74, 6, "#5f6163"),
                   # Rev 84 (Episode I spheres): on those systems the sphere's bright edge (half level of a blurred-disc fit)
                   # sits at r 15.0-15.3 px (745) on the PC's 742 px faces of Coruscant, Naboo, Tatooine, Malastare (ours
                   # 13.5 at 56 px): drawn 62 px across, same centre; no grey ring round it (the disc's ring is there, the
                   # sphere's tail falls below the disc ring's at r 17-18 even with the gold's blur added)
                   "dc_system_ep1_sphere": 62},
}


# Rev 84 (Coruscant sphere): re-measured. Ring fit on Decipher's own 745 / 1039 px Coruscant faces (Allegations Of
# Corruption, A Tragedy Has Occurred, Naboo: Battle Plains Light and Dark): the gold ring peaks at r 11.0-11.5 px (745) of a
# 14 px disc (0.80 of the radius) and a black ring runs from r 12.5 to the edge (0.89-1.0). The zoom above clipped the gold
# away on both pictures. Decipher's picture already has that layout (gold peak 0.80, black ring 0.88-0.97): drawn 1:1. The
# PC redraw's gold peaks at 0.94 with no black ring: drawn at 0.87 (gold at 0.82) inside the disc, the black hole behind it
# showing as the printed black ring. Systems print the sphere larger on the bare starfield: on the Coruscant-set systems
# (Coruscant, Naboo, Tatooine, Malastare) the gold ring peaks at r 13 px (745) of the 14 px seat, at the edge, its black
# ring lost in the starfield: Decipher's picture 1.16x, the PC redraw 1:1 (second value). Only Coruscant's pictures are
# listed; every other sphere is drawn whole, unclipped.
DC_SPHERE_ZOOM = {"icons/set-coruscant-pc.png": (0.87, 1.0), "icons/set-coruscant-decipher.png": (1.0, 1.16)}


def dc_sphere_img(icon: str, cx: float, cy: float, d: float, system: bool = False) -> str:
    """The printed sphere picture, d px across centred on (cx, cy) (DC_SPHERE_ZOOM: scaled by that factor inside a round
    clip; `system`: the systems' factor)."""
    z = (DC_SPHERE_ZOOM.get(icon) or (None, None))[1 if system else 0]
    if not z:
        return f'<img src="{data_uri(ASSETS / icon)}" style="position:absolute;left:{cx - d / 2:g}px;top:{cy - d / 2:g}px;width:{d:g}px;height:{d:g}px">'
    D = d * z
    return (f'<div style="position:absolute;left:{cx - d / 2:g}px;top:{cy - d / 2:g}px;width:{d:g}px;height:{d:g}px;border-radius:50%;overflow:hidden">'
            f'<img src="{data_uri(ASSETS / icon)}" style="position:absolute;left:{(d - D) / 2:g}px;top:{(d - D) / 2:g}px;width:{D:g}px;height:{D:g}px"></div>')


def dc_template(t: dict, dc: dict) -> dict:
    """The template with Decipher's printed sphere / copyright geometry; Episode I discs under the sphere follow it."""
    t = dict(t, **dc)
    if "dc_sphere" in dc and "expansion_ring" in t:
        sz = t.get("expansion_size", 62); cx, cy, _ = dc["dc_sphere"]
        t["expansion_ring"] = (round(cx - sz / 2), round(cy - sz / 2))
    return t


def dc_copy_html(text: str) -> str:
    """The copyright line as Decipher set it: © and ® as full-size thin circles round a small letter."""
    h = "".join(f'<span class="cr">{"C" if ch == "©" else "R"}</span>' if ch in "©®" else esc(ch) for ch in text)
    if "®&" in text:   # rev 84: Tatooine's own tighter face ("©2001 … TM, ®& ©2001", adapter.copyright_for)
        h = f'<span class="dctat">{h}</span>'
    return h


def podracer_flag_file(card: dict):
    """rev 77: the pilot flag image for a Podracer: an uploaded file (podracer_flag_file, resolved by the web app) or one of
    the five printed flags (podracer_flag = slug -> assets/icons/podracer-flag-<slug>.png)."""
    f = card.get("podracer_flag_file")
    if f and Path(f).exists():
        return Path(f)
    slug = re.sub(r"[^a-z0-9-]", "", str(card.get("podracer_flag") or "").lower())
    p = ASSETS / "icons" / f"podracer-flag-{slug}.png"
    return p if slug and p.exists() else None


def pc_count_lines(text: str, p: dict) -> int:
    """Lines the PC frame p needs for this game text: greedy wrap with the PC font's advance widths (the browser wraps
    the same way: no kerning, fixed tracking), inline icons at PC_ICON_W."""
    if not _PC_ADV:   # Holotable Text PC's advances are the PC face's widths (source/pc_widths.json, 1/1000 em)
        pw = json.load(open(ASSETS / "fonts/HolotableText/source/pc_widths.json", encoding="utf-8"))
        for k, key in (("r", "regular"), ("b", "bold")):
            _PC_ADV[k] = ({ord(c): v / 1000 for c, v in pw[key].items()}, pw[key].get("n", 375) / 1000)
        _PC_ADV["kern"] = pw.get("kern_regular", {})
    fs = p["size"] * PT; tr = p.get("track", 0) * fs / 1000; avail = p["w"] * PT + 0.2
    kern = _PC_ADV["kern"]
    def wlen(word, bold):
        adv, dflt = _PC_ADV["b" if bold else "r"]
        k = 0 if bold else sum(kern.get(a + b, 0) for a, b in zip(word, word[1:])) / 1000 * fs
        return sum(adv.get(ord(c), dflt) * fs + tr for c in word) + k
    sp = _PC_ADV["r"][0].get(32, 0.229) * fs + tr
    lines = 0
    for para in re.split(r"[¶\n]", text):
        toks = re.findall(r"\{[^}]*\}|\S+", re.sub(r"\{pilot:([^}]*)\}", r"{pilot} \1", para))
        x = None; bold = False
        for tk in toks:
            if tk.startswith("{"):
                w = PC_ICON_W
            else:
                b0 = tk.startswith("*"); w = wlen(tk.replace("*", "").replace("_", ""), bold or b0)
                if tk.count("*") % 2: bold = not bold
            if x is None:
                x = w; lines += 1
            elif x + sp + w <= avail:
                x += sp + w
            else:
                x = w; lines += 1
        if x is None:
            lines += 1
    return lines



def _pc_words(s: str) -> list:
    s = re.sub(r"\{pilot:([^}]*)\}", r" \1", s)
    s = re.sub(r"\{[^}]*\}", " ", s).replace("ﬁ", "fi").replace("ﬂ", "fl")
    return [w for w in (re.sub(r"[^A-Za-z0-9]", "", x).lower() for x in s.split()) if w]


def pc_hint_breaks(text: str, lines: list) -> str:
    """The same words as the PC's own card: break where the PC broke (its composer sometimes broke a word early, kept
    "Yavin 4 site" together ...). Returns text with U+2029 at each PC line start, or the text unchanged."""
    if not lines or len(lines) < 2 or os.environ.get("CM_PC_HINTS") == "0":
        return text
    pcw = [_pc_words(l) for l in lines]
    if [w for l in pcw for w in l] != _pc_words(text):
        return text
    text = re.sub(r"\s*[¶\n]\s*", " ", text)   # the PC ran USED: / LOST: on in one paragraph where its lines say so
    starts, k = set(), 0
    for l in pcw[:-1]:
        k += len(l); starts.add(k)
    out, n = [], 0
    for tok in re.split(r"(\s+)", text):
        if tok and not tok.isspace():
            if n in starts and out and out[-1].isspace():
                out[-1] = "\u2029"
            n += len(_pc_words(tok))
        out.append(tok)
    return "".join(out)



def pc_box(p: dict, bottom: float, raise_px: float = 0) -> tuple:
    """(left, top, width, height, css) of a PC text frame in master px; bottom = the template box's foot."""
    fs, lh = p["size"] * PT, p["pitch"] * PT
    left = p["x"] * PT + 70
    base = p["y"] * PT + 136 - raise_px          # first baseline (a raised text box: text_grow)
    top = base - ((lh - (PC_ASC + PC_DESC) * fs) / 2 + PC_ASC * fs)
    width = p["w"] * PT + 0.2
    css = f"font-family:PCText;font-size:{fs:.3f}px;line-height:{lh:.3f}px;letter-spacing:{p.get('track', 0) * fs / 1000:.3f}px;white-space:normal;"
    n = max(1, int((bottom - top) / lh + 0.15))   # whole lines the frame holds: the PC never squeezed the leading
    return left, top, width, n * lh + 0.25 * lh, css


def pc_fit_attrs(p: dict) -> str:
    """The PC made long text fit by a slightly smaller size and tighter tracking (7.4 → 7.1 pt, +10 → -5): same here,
    in 0.05 pt steps."""
    fs = p["size"] * PT
    return (f' data-fit-max="{fs:.3f}" data-fit-min="{6.6 * PT:.3f}" data-fit-step="{0.05 * PT:.4f}"'
            f' data-ls-min="{-6 * fs / 1000:.3f}" data-lh-min="1"')



def bullet_colour(card: dict):
    """Rev 77: the spec's uniqueness-dot colour (Eriadu, Jedi Pack: first runs printed the dot white), or None (as printed)."""
    v = str(card.get("bullet_colour") or "").strip().lower()
    if v in BULLET_COLOURS:
        return BULLET_COLOURS[v]
    return v if re.fullmatch(r"#[0-9a-f]{3,8}", v) else None


def foil_html(fr, fx: int, fy: int, holes=()) -> str:
    """Rev 77: Reflections I-III foil sheen, laid over the frame only (the frame PNG's own alpha masks it, so the art
    window, starfield and outer black border stay matte). Matched to collector photos of Reflections II foils (Admiral
    Ackbar, Chewie With Blaster Rifle, Jodo Kast, Lord Vader): the silver splatter and bevels turn pastel rainbow
    (magenta, violet, cyan, green, gold) in broad diagonal bands; the dark frames keep their tone with a faint
    violet / blue cast and a soft metallic highlight. The text boxes (holes: card-space rects) stay plain silver / black,
    as on the photographed cards, so the text reads as on a non-foil card."""
    try:
        fw, fh = Image.open(fr).size
    except Exception:
        return ""
    m = data_uri(Path(fr))
    mask = f"-webkit-mask-image:url('{m}');-webkit-mask-size:{fw}px {fh}px;-webkit-mask-repeat:no-repeat;"
    clip = ""
    if holes:   # even-odd path: the frame rectangle minus each text box
        d_ = f"M0 0H{fw}V{fh}H0Z" + "".join(f"M{x - fx} {y - fy}h{w}v{h}h{-w}Z" for x, y, w, h in holes)
        clip = f"clip-path:path(evenodd,'{d_}');"
    box = f"position:absolute;left:{fx}px;top:{fy}px;width:{fw}px;height:{fh}px;pointer-events:none;{mask}{clip}"
    bands = ("repeating-linear-gradient(118deg,#ff8fd0 0px,#c7a2ff 180px,#86dcff 360px,#9cf5b8 540px,"
             "#fff09a 720px,#ffb8a8 900px,#ff8fd0 1080px)")
    gloss = ("linear-gradient(118deg,rgba(255,255,255,0) 18%,rgba(255,255,255,.55) 30%,rgba(255,255,255,0) 42%,"
             "rgba(255,255,255,0) 60%,rgba(255,255,255,.4) 70%,rgba(255,255,255,0) 80%)")
    return (f'<div class="foil" style="{box}background:{bands};mix-blend-mode:multiply;opacity:.5"></div>'
            f'<div class="foil" style="{box}background:{bands};mix-blend-mode:screen;opacity:.16"></div>'
            f'<div class="foil" style="{box}background:{gloss};mix-blend-mode:soft-light;opacity:.7"></div>')


# Rev 84: Decipher printings of the Effect / Interrupt frames. Our frames carry the PC's colours (within 5 levels of the
# PC's Virtual cards); Decipher's printed faces are a deeper crimson (Dark margin 181,1,46 against 186,32,55), silver
# chips on the Light red margins (not cyan) and redder / yellower type discs. make_decipher_tone.py fits, from 100 printed
# Effects and Interrupts against our renders, a 3D colour offset table per side (17^3 nodes, frame pixels only) and
# per-channel quantile curves for the two type discs; the frame is recoloured once and cached.
DECIPHER_TONE = ASSETS / "frames/decipher-tone.npz"
_TONED: dict = {}


def decipher_toned(fr: Path, side: str, disc, circle) -> Path:
    import hashlib
    import numpy as np
    key = (str(fr), side, disc)
    if key in _TONED and _TONED[key].exists():
        return _TONED[key]
    h = hashlib.sha1(fr.read_bytes() + DECIPHER_TONE.read_bytes() + repr(key[1:] + (circle,)).encode()).hexdigest()[:12]
    out = OUT / f"_frame-{fr.stem}-decipher-{h}.png"
    if not out.exists():
        L = np.load(DECIPHER_TONE)
        a = np.array(Image.open(fr).convert("RGBA")).astype(np.float32)
        rgb = a[..., :3]; off = L[side]; n = off.shape[0]
        f = np.clip(rgb / 16.0, 0, n - 1 - 1e-6); i0 = np.floor(f).astype(np.int32); tt = f - i0
        res = np.zeros_like(rgb)
        for dx in (0, 1):
            for dy in (0, 1):
                for dz in (0, 1):
                    w = (tt[..., 0] if dx else 1 - tt[..., 0]) * (tt[..., 1] if dy else 1 - tt[..., 1]) * (tt[..., 2] if dz else 1 - tt[..., 2])
                    res += w[..., None] * off[i0[..., 0] + dx, i0[..., 1] + dy, i0[..., 2] + dz]
        toned = np.clip(rgb + res, 0, 255)
        if disc:   # the type disc: its own curves (feathered circle; the ring keeps the frame's)
            q = L[f"disc_{disc}"]; cx, cy, r = circle
            dq = np.stack([np.interp(rgb[..., c], np.arange(256), q[c]) for c in range(3)], -1)
            yy, xx = np.mgrid[:a.shape[0], :a.shape[1]]
            m = np.clip(r + 0.5 - np.hypot(xx - cx, yy - cy), 0, 1)[..., None]
            toned = toned * (1 - m) + dq * m
        a[..., :3] = toned
        OUT.mkdir(parents=True, exist_ok=True)
        Image.fromarray((a + 0.5).astype(np.uint8), "RGBA").save(out)
    _TONED[key] = out
    return out


def build_html(card: dict) -> str:
    t = TEMPLATES[card["template"]]
    if card.get("decipher_print") and DC_PRINT.get(card["template"]):
        t = dc_template(t, {k: v for k, v in DC_PRINT[card["template"]].items() if k != "ep1"})   # rev 84: sphere and copyright line where Decipher printed them
        if DC_PRINT[card["template"]].get("ep1") and "episode1" in (card.get("ring_icons") or []):
            t = dc_template(t, DC_PRINT[card["template"]]["ep1"])   # rev 84: Episode I-era sites
    if card.get("decipher_print") and card["template"] in ("ls-podracer", "ds-podracer"):
        # rev 84 (2): the five printed Podracers set game text at a 63.0 pitch (ours 63.75) and lore at 60.5 (ours 60);
        # size and width were right (rev 84: printed / ours line width 0.99-1.00)
        t = dict(t, gt_lh_add=63.0 - t.get("gt_size", 62), lore_css=dict(t.get("lore_css") or {}, lh=60.5))
    card_ctx.clear(); card_ctx.update(card); card_ctx["_dark_text"] = bool(t.get("dark_text"))
    card_ctx["_pc_icons"] = bool(card.get("pc_type"))
    card_ctx["_dc_text"] = dc_text(card, t)   # rev 84 (inline icons): Decipher's inline icon size on its own printings
    pcg0 = (card.get("pc_type") or {}).get("gt")
    if pcg0 and not card.get("text_grow") and not card.get("no_lore_box") and card["template"] in PC_GROW_TEMPLATES and not t.get("landscape"):
        # rev 74: a sixth line of game text: the PC raised banner and text box one line (Protocol Failure (V), Palace
        # Raider (V): first baseline 181.4 pt instead of 189.5 pt) rather than shrink the type
        n_ = pc_count_lines(card.get("game_text") or "", pcg0)
        if n_ == 6 or pcg0.get("raised"):   # or the PC's own card has its text box raised (Return Of The Jedi (V))
            card = dict(card, text_grow=int(round((pcg0["y"] - 181.4) * PT)), _pc_raised=True)
    fonts = {
        "HoloTitle": "fonts/HolotableTitle/HolotableTitle-Regular.otf",   # titles, deploy / forfeit, caption bullet: our OFL face drawn from the PC titles (#118)
        "AGLightCn": "fonts/HolotableText/HolotableText-Light.ttf",   # lore; text faces: our OFL Holotable Text, from Barlow Condensed (swccg-guild/work#123)
        "AGMedCn": "fonts/HolotableText/HolotableText-Regular.ttf",   # was Bardez's BE Medium Condensed (label "medium"): Holotable Text Regular is cut from Barlow Medium
        "AGBoldCnA": "fonts/HolotableText/HolotableText-Bold.ttf",
        "AGCn": "fonts/HolotableText/HolotableText-Regular.ttf",
        "AGMedExt": "fonts/HolotableNumbers/HolotableNumbers-Extended.otf",   # destiny, stat values, slip numbers: Holotable Numbers, from TeX Gyre Heros (GUST Font License, #124)
        "PCCap": "fonts/LiberationSansNarrow-Bold.ttf",            # Arial Narrow Bold metrics (the PC slips' caption face)
        "PCNum": "fonts/HolotableNumbers/HolotableNumbers-BoldItalic.otf",
        "PCText": "fonts/HolotableText/HolotableTextPC-Regular.ttf",   # rev 74: Virtual Legacy text with the PC slips' advance widths (Akzidenz-Grotesk BE Condensed)
        "PCTextBold": "fonts/HolotableText/HolotableTextPC-Bold.ttf",   # bottom-strip number (the PC's DefensiveShields.pdf sets it in Akzidenz-Grotesk BE Bold Italic)
    }
    font_css = "\n".join(f'@font-face{{font-family:"{k}";src:url("{data_uri(ASSETS / v)}");}}' for k, v in fonts.items())
    global W, H
    W, H = (2220, 1632) if is_wide(t) else (1632, 2220)
    if t.get("landscape"):
        fr, fx, fy = loc_frame(card, t), 0, 0
        ax_, ay_, aw_, ah_ = t["art"]
        if card.get("dark_half_absent"): t = dict(t, art=(134, 138, 1952, ay_ + ah_ - 138))
        if card.get("light_half_absent"): t = dict(t, art=(134, t["art"][1], 1952, 1494 - t["art"][1]))
        card["_art_box"] = t["art"]
    elif t.get("system"):
        if card.get("lang") == "ja":   # rev 83: bars, icons, parsec and Force moved with Takara's taller boxes
            import lang_ja
            t = lang_ja.system_template(t)
        fr, fx, fy = sys_frame(card, t), 0, 0
    else:
        fr, fx, fy = t["frame"]
        fr = ASSETS / fr
        if card.get("decipher_print") and t.get("decipher_tone"):
            fr = decipher_toned(fr, *t["decipher_tone"])   # Rev 84: Decipher's ink on the Effect / Interrupt frames
        if t.get("nolore_grow") and card.get("no_lore_box") and not card.get("text_grow"):
            card = dict(card, text_grow=t["nolore_grow"], grow_keep_frame=True)   # as the PC cards (adapter): the Effect frame's own window
        if card.get("captive_noart") and "stats_y" in t:
            fr, t, fx, fy = captive_frame(card, t, fr, fx, fy)
        elif card.get("text_grow") and card.get("no_lore_box") and not card.get("grow_keep_frame"):
            fr, t, fx, fy = nolore_frame(card, t, fr, fx, fy)
        elif card.get("text_grow"):
            fr, t, fx, fy = grown_frame(card, t, fr, fx, fy)
    ja = card.get("lang") == "ja"   # rev 77: Takara's Japanese printings (lang_ja.py)
    if ja:
        import lang_ja
        t = lang_ja.template(card, t)
        if not t.get("landscape") and not t.get("system") and ("stats" in t or "lore" in t):   # rev 80: also the lore box sides
            fr = lang_ja.frame(fr, fx, fy, card, t, (stat_boxes(t, len(t["stats"])) or t["stats"]) if "stats" in t else None)
    ax, ay, aw, ah = t["art"]
    art = art_crop(card) if card.get("art") and not t.get("_noart") else ""
    if t.get("chart") and not art:   # starfield with a spiral galaxy glow (Hyperoute Navigation Chart)
        import numpy as np
        rng = np.random.default_rng(9); ax_, ay_, aw_, ah_ = t["art"]
        sf = np.zeros((ah_, aw_, 3), float)
        yy, xx = np.mgrid[0:ah_, 0:aw_]
        cx_, cy_ = aw_ * 0.62, ah_ * 0.5
        r = np.hypot((xx - cx_) / 1.6, yy - cy_)
        sf += (np.exp(-r / 120) * 200)[..., None] * np.array([1.0, 0.85, 0.7]) + (np.exp(-r / 420) * 60)[..., None] * np.array([0.5, 0.6, 1.0])
        for _ in range(5200):
            x_, y_ = rng.integers(0, aw_), rng.integers(0, ah_); b = rng.random() ** 3 * 255
            sf[max(y_ - 1, 0):y_ + 2, max(x_ - 1, 0):x_ + 2] += b * (0.35 if rng.random() < 0.8 else 1)
        p_ = OUT / f"_art_{card['id']}-stars.png"; Image.fromarray(np.clip(sf, 0, 255).astype(np.uint8)).save(p_); art = data_uri(p_)

    def box(key, style=""):
        x, y, w, h = t[key]
        return f"left:{x}px;top:{y}px;width:{w}px;height:{h}px;{style}"

    wb = card.get("border") == "white"   # Unlimited / Revised / Anthology printings: white outer border (rev 76)
    cls = " ".join(c for c in ("inv" if card.get("invert_text") else "", "wb" if wb else "") if c)
    parts = [f'<div id="card"{f' class="{cls}"' if cls else ''} style="position:relative;width:{W}px;height:{H}px;background:{"#fff" if wb else "#000"};overflow:hidden">']
    if wb:   # the card body stays black under the frame (locations' starfield, frame gaps); only the bleed turns white
        bw_, bh_ = (1931, 1343) if W > H else (1343, 1931)
        parts.append(f'<div style="position:absolute;left:144px;top:144px;width:{bw_}px;height:{bh_}px;background:#000;border-radius:{WHITE_BORDER_RADIUS}px"></div>')
    marks = []   # (piece, index into parts): card maker layers — each piece is wrapped so it can be moved / resized / hidden

    def sec(name):
        marks.append((name, len(parts)))
    sec('art')
    split = card.get("art2") and not t.get("_noart") and not t.get("landscape") and not t.get("system")   # rev 77: two pictures
    if split and not (card.get("no_lore_box") and t.get("lore") and not t.get("_artwin")):
        if t.get("_artwin"):
            win = t["_artwin"]
        elif card.get("art_cover_hole") and not t.get("wide"):
            hx0, hy0, hx1, hy1 = frame_hole(t)
            win = (min(ax, hx0), min(ay, hy0), max(ax + aw, hx1) - min(ax, hx0), max(ay + ah, hy1) - min(ay, hy0))
        else:
            win = (ax, ay, aw, ah)
        parts.append(f'<img src="{split_art(card, win)}" style="position:absolute;left:{win[0]}px;top:{win[1]}px;width:{win[2]}px;height:{win[3]}px">')
    elif split:
        pass   # drawn over the frame's lore window below
    elif art and t.get("_artwin"):   # reshaped window (tall slips): the art fills it, under the frame
        wx, wy, ww, wh = t["_artwin"]
        if card.get("no_lore_box") and card["art"].get("rect"):
            parts.append(f'<img src="{art_crop(card, t["_artwin"], "-rect")}" style="position:absolute;left:{wx}px;top:{wy}px;width:{ww}px;height:{wh}px">')
        elif card.get("no_lore_box") and card.get("text_grow_scan"):
            # the card's own (no-lore) scan: its art already sits in this raised window — map the window itself
            card_ = card
            if t.get("combo_corners") and not card["art"].get("bbox"):
                # rev 84: the combo scans (res.starwarsccg.org, wiki) are Holotable faces — 745 x 1039 or scaled down
                # (354 x 492) — with the card body at (37, 36)..(708.5, 1001.5) of 745: map by that, not by the silver
                # frame's bbox (found 3-4 % small on the 354 px GIFs: the printed frame and copyright showed in the window)
                try:
                    wi_, hi_ = Image.open(card["art"]["src"]).size
                except Exception:
                    wi_ = hi_ = 0
                if wi_ and abs((hi_ / wi_) / (1039 / 745) - 1) < 0.012:
                    k_ = wi_ / 745
                    card_ = dict(card, art=dict(card["art"], bbox=(37 * k_, 36 * k_ * (hi_ / wi_) / (1039 / 745), 708.5 * k_, 1001.5 * k_ * (hi_ / wi_) / (1039 / 745))))
            parts.append(f'<img src="{art_crop(card_, t["_artwin"], "-nolore")}" style="position:absolute;left:{wx}px;top:{wy}px;width:{ww}px;height:{wh}px">')
        else:
            parts.append(f'<div style="position:absolute;left:{wx}px;top:{wy}px;width:{ww}px;height:{wh}px;overflow:hidden">'
                         f'<img src="{art}" style="position:absolute;left:0;top:{0 if card.get("pc_type") else (wh - ah) // 2}px;width:{aw}px;height:{ah}px"></div>')
            # rev 74: a Virtual Legacy slip with a raised text box was pasted over the printed card: the art keeps its top
            # and loses its foot (and a scan of the PC card never shows its own banner inside the window: Protocol Failure (V))
    elif art and card.get("art") and card.get("art_cover_hole") and not t.get("landscape") and not t.get("system") and not t.get("wide"):
        # card maker: the picture fills the frame's whole window (some frames' holes run a few px past the template's
        # art box — a black sliver showed on Ahsoka Tano With Lightsabers, Bill 2026-10-15)
        hx0, hy0, hx1, hy1 = frame_hole(t)
        win = (min(ax, hx0), min(ay, hy0), max(ax + aw, hx1) - min(ax, hx0), max(ay + ah, hy1) - min(ay, hy0))
        parts.append(f'<img src="{art_crop(card, win, "-rect" if card["art"].get("rect") else "-hole")}" style="position:absolute;left:{win[0]}px;top:{win[1]}px;width:{win[2]}px;height:{win[3]}px">')
    elif art:
        parts.append(f'<img src="{art}" style="position:absolute;left:{ax}px;top:{ay}px;width:{aw}px;height:{ah}px">')
    sec(None)
    parts.append(f'<img src="{data_uri(fr)}" style="position:absolute;left:{fx}px;top:{fy}px">')
    if card.get("foil"):   # rev 77: Reflections foil printing
        parts.append(foil_html(fr, fx, fy, [t[k] for k in ("lore", "game_text", "ls_text", "ds_text")
                                           if isinstance(t.get(k), tuple) and len(t[k]) == 4 and not (k == "lore" and card.get("no_lore_box"))]))
    try:
        _fb = frame_bottom(fr, fy, H)
    except Exception:
        _fb = None
    card_ctx["_strip_top"] = (_fb + 1) if _fb else t.get("strip_top", (t["caption_y"] - 6) if "caption_y" in t else 2076)
    sec('art')
    if card.get("no_lore_box") and (card.get("art") or split) and t.get("lore") and not t.get("_artwin"):
        # the printed card has no lore box (Jedi Tests, Reflections II combo cards): its art runs from the title bar to the
        # banner — lay the mapped scan over the frame's lore window too
        lx, ly, lw, lh = t["lore"]
        win = (ax, ly - 34, aw, ay + ah - (ly - 34) - int(card.get("text_grow") or 0))
        src_ = split_art(card, win) if split else art_crop(card, win, "-rect" if card["art"].get("rect") else "-full")
        parts.append(f'<img src="{src_}" style="position:absolute;left:{win[0]}px;top:{win[1]}px;width:{win[2]}px;height:{win[3]}px">')
    sec('affiliation')
    if card.get("disc"):   # affiliation disc swapped over the frame's own (Yoda: the Light Jedi Master blade on the Rebel frame)
        dx_, dy__ = t.get("disc_at", (193, 176))
        parts.append(f'<img src="{data_uri(ASSETS / f"icons/disc-{card["disc"]}.png")}" style="position:absolute;left:{dx_}px;top:{dy__}px">')
    _pf = podracer_flag_file(card) if t.get("podracer_flag_box") else None
    if _pf:   # rev 77: the pilot's flag in its recessed window between the type disc and the title (Sebulba's Podracer)
        bx, by, bw, bh = t["podracer_flag_box"]; bv = 14
        parts.append(f'<div style="position:absolute;left:{bx - bv}px;top:{by - bv}px;width:{bw + 2 * bv}px;height:{bh + 2 * bv}px;box-sizing:border-box;'
                     f'border:{bv}px solid;border-color:rgba(0,0,0,.26) rgba(0,0,0,.06) rgba(255,255,255,.20) rgba(0,0,0,.16)"></div>')
        parts.append(f'<img src="{data_uri(_pf)}" style="position:absolute;left:{bx}px;top:{by}px;width:{bw}px;height:{bh}px;object-fit:cover;'
                     f'outline:2px solid rgba(0,0,0,.30)">')
        tx_ = t["podracer_title_x"]; ttl = t["title"]
        t = dict(t, title=(tx_, ttl[1], ttl[0] + ttl[2] - tx_, ttl[3])); t.pop("title_long_left", None); t.pop("decipher_title", None)
    if card.get("disc2"):   # second affiliation disc right of the first, title bar shortened (The Emperor: Dark Jedi Master + Imperial)
        # rev 84: on the Dark frames the printed second disc sits 4 px (745) left of where we had it (6 printed faces,
        # Decipher and PC: ring's left edge at x 149-152 against our 154)
        d2x = 350 if card["template"].startswith("ds-") else 359
        parts.append(f'<img src="{data_uri(ASSETS / f"icons/disc-{card["disc2"]}.png")}" style="position:absolute;left:{d2x}px;top:{174}px">')
        # rev 84: the title shift measured on the printed two-disc cards (DISC2_TITLE_SHIFT; was 170 everywhere)
        d2 = DISC2_TITLE_SHIFT.get(card["template"], DISC2_TITLE_SHIFT_DEFAULT) + int(card.get("disc2_title_dx") or 0)
        t = dict(t, title=(t["title"][0] + d2, t["title"][1], t["title"][2] - d2 + int(card.get("disc2_title_dw") or 0), t["title"][3]))
        if card.get("disc2_title_ls") is not None:   # rev 84 (geometry 2): Decipher's 1999-2000 two-disc titles set tighter
            t = dict(t, title_ls=card["disc2_title_ls"])
    sec('title')
    # title + destiny
    pre = " pre" if card.get("text_lines") else ""
    if t.get("landscape"):
        # Light title centred in the grey bar between the force slot and the first icon box; Dark mirrored, rotated.
        DL, DD = loc_grow(card)
        LA, DA = card.get("light_half_absent"), card.get("dark_half_absent")   # full-art AI / ALT sites
        nbox = len(card.get("light_icons", []))
        x0, y, h = t["ls_bar"]; y -= DL
        x1 = fx + 1790 - 15 + t["frame_off"][0] - fx if nbox == 0 else fx + t["ls_slot0"] - (nbox - 1) * t["slot_pitch"] - 55 + t["frame_off"][0]
        mk = re.search(r"\s*\((\d+)(st|nd|rd|th) Marker\)\s*$", card.get("card_type") or card["title"], re.I)
        if mk:   # Hoth marker sites print "1st MARKER" in its own black box between the title and the icons
            card = dict(card, card_type=(card.get("card_type") or card["title"])[:mk.start()])
            mtxt = f'{mk.group(1)}<span style="font-size:0.62em;vertical-align:0.45em">{mk.group(2).upper()}</span> MARKER'
            mw = 250
            x1 -= mw + 14
            parts.append(f'<div class="mkbox" style="position:absolute;left:{x1 + 6}px;top:{y + 4}px;width:{mw}px;height:{h - 8}px;background:#000;color:#fff;font-family:AGBoldCnA;font-size:54px;letter-spacing:2px;white-space:pre;display:flex;align-items:center;justify-content:center">{mtxt}</div>')
        if not LA:
            parts.append(f'<div class="title ltitle" style="position:absolute;left:{x0}px;top:{y}px;width:{x1 - x0}px;height:{h}px">{loc_title(card, "Light")}</div>')
        nbox = len(card.get("dark_icons", []))
        dx, dy_, dw, dh = t["ds_bar"]; dy_ += DD
        dx0 = dx if nbox == 0 else t["frame_off"][0] + t["ds_slot0"] + (nbox - 1) * t["slot_pitch"] + 55
        if mk:
            parts.append(f'<div class="mkbox" style="position:absolute;left:{dx0 + 8}px;top:{dy_ + 4}px;width:{mw}px;height:{dh - 8}px;background:#000;color:#fff;font-family:AGBoldCnA;font-size:54px;letter-spacing:2px;white-space:pre;display:flex;align-items:center;justify-content:center;transform:rotate(180deg)">{mtxt}</div>')
            dx0 += mw + 14
        if not DA:
            parts.append(f'<div class="title dtitle" style="position:absolute;left:{dx0}px;top:{dy_}px;width:{dx + dw - dx0}px;height:{dh}px">{loc_title(card, "Dark")}</div>')
        sec('location_text')
        JO = __import__("lang_ja").SITE_OUT if card.get("lang") == "ja" else 0   # rev 83: Takara's boxes also reach further out
        lx, ly_, lw, lh = t["ls_text"]; ly_ -= DL; lh += DL + JO
        if not LA:
            parts.append(loc_text_div(card, True, lx, ly_, lw, lh, pre, ja))
        tx, ty, tw, th = t["ds_text"]; th += DD + JO; ty -= JO
        if not DA:
            parts.append(loc_text_div(card, False, tx, ty, tw, th, pre, ja))
    elif t.get("system"):
        LA, DA = card.get("light_half_absent"), card.get("dark_half_absent")   # one-sided systems (Death Star)
        if not LA:
            x, y, w, h = t["ls_bar"]
            parts.append(f'<div class="title ltitle" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px">{loc_title(card, "Light")}</div>')
        if not DA:
            x, y, w, h = t["ds_bar"]
            parts.append(f'<div class="title dtitle" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px">{loc_title(card, "Dark")}</div>')
        sec('location_text')
        if not LA:
            x, y, w, h = t["ls_text"]
            parts.append(loc_text_div(card, True, x, y, w, h, pre, ja, system=True))
        if not DA:
            x, y, w, h = t["ds_text"]
            parts.append(loc_text_div(card, False, x, y, w, h, pre, ja, system=True))
        sec('parsec')
        if card.get("parsec") is not None:
            if not LA:
                x, y, w, h = t["ls_parsec"]
                parts.append(f'<div class="parsec" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px">{esc(str(card["parsec"]))}</div>')
            if not DA:
                x, y, w, h = t["ds_parsec"]
                parts.append(f'<div class="parsec" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;transform:rotate(180deg)">{esc(str(card["parsec"]))}</div>')
    elif t.get("chart"):   # Hyperoute Navigation Chart: title in a white-ruled black box over the starfield
        x, y, w, h = t["title"]
        parts.append(f'<div style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;background:#000;border:7px solid #e8e8e8;box-sizing:border-box;'
                     f'display:flex;align-items:center;justify-content:center;font-family:HoloTitle;font-size:124px;color:#fff;white-space:nowrap">{title_dots(title_html(card["title"]), card)}</div>')
    else:
        tll = f' data-ll="{t["title_long_left"]}"' if t.get("title_long_left") else ""   # #62: a title too long for the bar starts further left
        if ja:   # rev 80: Takara condensed a long title further to stay clear of the destiny (Luke Skywalker)
            tll += lang_ja.title_attrs(card)
        if card.get("decipher_print") and t.get("decipher_title"):
            # Rev 84: Decipher's own typesetting (printed 1995-2001; 70 printed Effects / Interrupts measured): Light
            # titles 8 px left of the PC's; the bar runs to x 1274 on all four; a title too long for it is set smaller
            # (font size, baseline kept), ending by x 1248 and starting further left the more it shrinks (fit_lead)
            ddx, dend, dright, dlead = t["decipher_title"]
            tx0, ty0, _, th0 = t["title"]
            t = dict(t, title=(tx0 + ddx, ty0, dend - tx0 - ddx, th0))
            tll = f' data-dfit="{dright} {dlead}"'
        parts.append(f'<div class="title{" jatitle" if ja else ""}"{tll} style="position:absolute;{box("title")}">{title_dots(title_html(card["title"]), card)}</div>')
    sec('destiny')
    if card.get("destiny") and "destiny" in t:
        dv = esc(card["destiny"])
        plain = re.sub(r"<[^>]+>", "", dv)
        if " or " in dv or len(plain) > 2:   # multi-value destiny (R2-D2 "2 or 5"), or a long value: the pill widens left (card maker: capped, then condensed)
            x, y, w, h = t["destiny"]
            ext = 150 if " or " in dv else min(190, 52 * (len(plain) - 2))
            parts.append(f'<div style="position:absolute;left:{x - ext - 6}px;top:{y - 6}px;width:{w + ext + 12}px;height:{h + 12}px;background:#000;border:6px solid #d0d0d2;border-radius:{h // 2 + 6}px;box-sizing:border-box"></div>')
            parts.append(f'<div class="destiny" style="position:absolute;left:{x - ext}px;top:{y}px;width:{w + ext}px;height:{h}px;font-size:80px;white-space:nowrap;padding-top:4px"><span class="fitnum" data-avail="{w + ext - 20}">{dv.replace(" or ", "<span style=\"font-size:46px\">&nbsp;or&nbsp;</span>")}</span></div>')
        else:
            parts.append(f'<div class="destiny" style="position:absolute;{box("destiny")}"><span class="fitnum" data-avail="{t["destiny"][2] - 8}">{dv}</span></div>')
    sec(None)
    for fx, fy, fw, fh, col in t.get("fill_boxes", []):
        parts.append(f'<div style="position:absolute;left:{fx}px;top:{fy}px;width:{fw}px;height:{fh}px;background:{col}"></div>')
    sec('lore')
    # lore
    pcl = (card.get("pc_type") or {}).get("lore")
    if ja and card.get("lore") and "lore" in t and not t.get("landscape"):   # rev 77: Takara's taller lore box
        parts.append(lang_ja.lore_html(card, t, game_text_html, fit_attrs(card, "lore")))
    elif card.get("lore") and "lore" in t and pcl:   # rev 74: Virtual Legacy lore as the PC set it (frame, size, first-line indent)
        lx_, ly_, lw_, lh_ = t["lore"]
        l_, tp_, w_, h_, st_ = pc_box(pcl, ly_ + lh_ + 8)
        lrx_ = pc_hint_breaks(card["lore"], pcl.get("lines") or card.get("lore_lines"))
        if "\u2029" in lrx_:
            w_ += 2 * PT
        parts.append(f'<div class="lore fit pctext"{pc_fit_attrs(pcl)} style="position:absolute;left:{l_:.1f}px;top:{tp_:.1f}px;width:{w_:.1f}px;height:{h_:.1f}px;padding:0;'
                     f'text-indent:{pcl.get("indent", 0) * PT:.1f}px;{st_}">{game_text_html(lrx_)}</div>')
    elif card.get("lore") and "lore" in t:   # wide full-art Effects print no lore (I Must Be Allowed To Speak (ALT))
        lx_, ly_, lw_, lh_ = t["lore"]
        tx0, rgt, ind, cut, lsp = t.get("lore_x") or LORE_X["Light" if t.get("dark_text") else "Dark"]
        lore_ = pc_hint_breaks(card["lore"], card.get("lore_lines"))   # rev 74: the printed card's own lore line breaks
        if "\u2029" in lore_:
            rgt += 40; cut = 0
        if dc_text(card, t) and not card.get("no_lore_box"):
            # rev 84: Decipher's lore setting (wider face, pitch 60.5, three lines keep their pitch)
            p = DC_TEXT["lore"]; k = p["k"]
            lore_, nw_ = dc_hint(card["lore"], card, "lore", card.get("lore_lines"))
            cut = 0 if nw_ else cut
            side = "Light" if t.get("dark_text") else "Dark"
            w_ = (rgt - p["x"] + p["dw"][side]) / k
            parts.append(f'<div class="lore fit dct" data-fit-step="1"{fit_attrs(card, "lore")} style="position:absolute;left:{p["x"]}px;top:{ly_}px;width:{w_:.2f}px;height:{max(lh_, p["min_h"])}px;'
                         f'transform:scaleX({k});transform-origin:left top;line-height:{p["lh"]}px;'
                         f'text-indent:{card.get("lore_indent", p["indent"]) / k:.2f}px;letter-spacing:0px;{dc_stroke(card, t, "lore")}{nw_}">'
                         f'<span style="float:right;width:{cut / k:.2f}px;height:58px"></span>{dc_nobreak(game_text_html(lore_))}</div>')
        else:
            parts.append(f'<div class="lore fit"{fit_attrs(card, "lore")} style="position:absolute;left:{tx0}px;top:{ly_}px;width:{rgt - tx0}px;height:{lh_}px;'
                         f'text-indent:{card.get("lore_indent", ind)}px;letter-spacing:{lsp}px">'
                         f'<span style="float:right;width:{cut}px;height:58px"></span>{game_text_html(lore_)}</div>')
    sec('stats')
    # stats (character)
    if ja and "stats" in t and card.get("stats"):   # rev 77: one long strip ("戦闘力６　能力値６　ダーク・ジェダイ")
        parts.append(lang_ja.stats_html(card, t, stat_boxes(t, len(t["stats"])) or t["stats"], esc))
    elif "stats" in t and card.get("stats"):
        y = t["stats_y"]
        stats = list(card["stats"])
        if len(stats) == 3 and "stats_row3" in t:
            # a droid printing three separate boxes (LE-BO2D9 (V): POWER / ARMOR / MAINTENANCE DROID): the droid frame
            # has one wide box, so the Rebel frame's three-box stat row (same white silver) is laid over it
            png, sx, sy = t["stats_row3"]
            parts.append(f'<img src="{data_uri(ASSETS / png)}" style="position:absolute;left:{sx}px;top:{sy}px">')
            boxes = t["stats_row3_boxes"]
        elif len(stats) == 2 and stats[1][0] not in ("ABILITY", "ARMOR", "MANEUVER") and "stats_wide" in t:
            # droids: one wide box (e.g. ASTROMECH DROID) spans the ability + third slots
            wx, ww = t["stats_wide"]
            parts.append(f'<div style="position:absolute;left:{wx}px;top:{y}px;width:{ww}px;height:69px;background:{t.get("stats_wide_fill", "#000")};border-radius:6px"></div>')
            boxes = [t["stats"][0], (wx, ww)]
        else:
            boxes = t["stats"]
        if boxes is t["stats"]:
            boxes = stat_boxes(t, len(boxes)) or boxes   # the wells as painted in the frame
        is_char = "character" in card["template"]
        # #52: the tightest label-value gap and right margin the box squeeze may reach (PC Dark characters: 26 / 16 master px)
        stat_min = f' data-gmin="{t["stat_min"][0]}" data-mmin="{t["stat_min"][1]}"' if t.get("stat_min") else ""
        gap_style = f' style="margin-left:{t["stat_val_gap"]}px"' if "stat_val_gap" in t else ""   # rev 84: printed creatures (FLIGHT 2)
        for i, ((x, w), (label, value)) in enumerate(zip(boxes, stats)):
            # Decipher sets the value at the right end of its box (ARMOR      5, LANDSPEED    2 on starships and
            # vehicles; POWER 5 / ABILITY 6 fill theirs) — except a character's wide third box (ARMOR 5 follows the
            # label, Boba Fett). Bill 2026-10-13 (Jabba's Space Cruiser (V)).
            vcls = "val" if ((is_char and i >= 2) or ("creature" in card["template"] and i >= 1)) else "val r"   # creatures: FLIGHT 2 (Bog-wing)
            # a label-only box (FORCE-SENSITIVE, MAINTENANCE DROID) stays on one line: shrink it to the box as the
            # slips do (LE-BO2D9 (V), 2026-10-13); AGBoldCnA caps ≈ 0.50 em + 1.8 px tracking per character
            lab_style = ""
            if not value:
                # full height, squeezed horizontally to the well (as the slips print MAINTENANCE DROID) — fitlab JS
                lab_style = f' class="lab fitlab" data-avail="{w - 2 * t.get("stat_pl", 16)}" style="white-space:nowrap;display:inline-block;transform-origin:left center"'
            parts.append(f'<div class="stat"{stat_min} style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:68px">'
                         f'<span{lab_style if lab_style else " class=lab"}>{esc(label)}</span>{f'<span class="{vcls}"{gap_style if vcls == "val" else ""}>' + esc(value) + "</span>" if value and not (value == "✶" and card["template"] == "creature-dc") else ""}'
                         f'{f'<span class="{vcls}" style="transform:none;margin-right:{t.get("stat_pl", 16) + 10}px;padding-bottom:2px">' + dc_star_img(47) + "</span>" if value == "✶" and card["template"] == "creature-dc" else ""}</div>')
    if card.get("stat_icon") and t.get("stats_y"):   # a round icon left of the stat row (Mon Mothma (V): the Republic crest)
        sx0 = (stat_boxes(t, 3) or t["stats"])[0][0]
        parts.append(f'<img src="{data_uri(ASSETS / ICON_FILES[card["stat_icon"]])}" style="position:absolute;left:{sx0 - 100}px;top:{t["stats_y"] - 14}px;width:96px;height:96px">')
    sec('banner')
    if "card_type" in t and card.get("card_type"):
        parts.append(f'<div class="ctype" style="position:absolute;{box("card_type")}"><span class="ct">{esc_i(card["card_type"])}</span></div>')
    if card.get("banner_icon") and "banner_icon" in t:
        bx, by = t["banner_icon"]
        if ICON_FILES[card["banner_icon"]].startswith("icons/col-"):   # framed icon (Setup): drawn at box size
            bw_ = t.get("banner_icon_size", 89)
            parts.append(f'<img src="{data_uri(ASSETS / ICON_FILES[card["banner_icon"]])}" style="position:absolute;left:{bx}px;top:{by}px;width:{bw_}px;height:{bw_ + 1 if bw_ == 89 else bw_}px">')
        else:
            parts.append(f'<img src="{data_uri(ASSETS / "icons/icon-box-effect.png")}" style="position:absolute;left:{bx}px;top:{by}px">')
            parts.append(f'<img src="{data_uri(ASSETS / ICON_FILES[card["banner_icon"]])}" style="position:absolute;left:{bx + 8}px;top:{by + 8}px;width:73px;height:73px">')
    sec('game_text')
    # game text
    if card.get("squadron_row") and "game_text" in t:   # the icon row sits above a shorter text box
        gx_, gy_, gw_, gh_ = t["game_text"]; t = dict(t, game_text=(gx_, gy_ + 72, gw_, gh_ - 72))
    if t.get("chart"):   # rows "[N] Planet, Planet" -> a number box and the systems at that parsec; "* note" footnotes
        gx, gy, gw, gh = t["game_text"]
        txt = card.get("game_text") or ""
        rows = re.findall(r"\[(\d+)\]\s*([^\[]*)", txt)
        notes = []
        if rows:
            last_n, last = rows[-1]
            m_ = re.search(r"\s((?:[*†✶]\s*[A-Z][^*†✶]*)+)$", last)
            if m_:
                notes = [x.strip() for x in re.findall(r"[*†✶]\s*[^*†✶]+", m_.group(1))]
                rows[-1] = (last_n, last[:m_.start()])
        rh = min(150, gh / max(len(rows), 1))
        fs = int(rh * 0.42) if any(len(r[1]) > 34 for r in rows) else int(rh * 0.5)
        for k, (n, names) in enumerate(rows):
            yy = gy + k * rh
            parts.append(f'<div style="position:absolute;left:{gx}px;top:{yy + rh * 0.08:.0f}px;width:{rh * 0.84:.0f}px;height:{rh * 0.84:.0f}px;background:#000;border:6px solid #e8e8e8;'
                         f'box-sizing:border-box;display:flex;align-items:center;justify-content:center;font-family:AGMedExt;font-size:{rh * 0.5:.0f}px;color:#fff">{esc(n)}</div>')
            parts.append(f'<div style="position:absolute;left:{gx + rh * 0.84 + 30:.0f}px;top:{yy:.0f}px;width:{gw - rh * 0.84 - 30:.0f}px;height:{rh:.0f}px;display:flex;align-items:center;'
                         f'font-family:AGBoldCnA;font-size:{fs}px;line-height:1.05;letter-spacing:2px;color:#fff;text-transform:uppercase">{esc(names.strip().rstrip(",").replace("✶", "*").replace(" *", "*"))}</div>')
        for k, nt in enumerate(notes):
            parts.append(f'<div style="position:absolute;right:{1632 - 1320}px;top:{gy + gh + 10 + k * 56}px;font-family:AGCn;font-size:52px;color:#fff;white-space:nowrap">{esc(nt.replace("✶", "*"))}</div>')
    elif "game_text" in t:
        pcg = (card.get("pc_type") or {}).get("gt")
        if pcg:   # rev 74: Virtual Legacy — the PC's own frame, size, tracking and pitch (gempdata/legacy_typeset.json)
            gx_, gy_, gw_, gh_ = t["game_text"]
            l_, tp_, w_, h_, st_ = pc_box(pcg, gy_ + gh_, float(card.get("text_grow") or 0))
            gtx_ = pc_hint_breaks(card["game_text"], pcg.get("lines"))
            if "\u2029" in gtx_:
                w_ += 2 * PT   # the PC's own breaks: a line must never wrap early on our 0.1-0.2 pt wider words
            parts.append(f'<div class="gt fit pctext"{pc_fit_attrs(pcg)} style="position:absolute;left:{l_:.1f}px;top:{tp_:.1f}px;width:{w_:.1f}px;height:{h_:.1f}px;padding:0;{st_}">{game_text_html(gtx_)}</div>')
        elif ja:   # rev 77: Takara's text (printed line breaks when given: text_breaks)
            parts.append(lang_ja.gt_html(card, t, game_text_html, fit_attrs(card, "game_text")))
        elif dc_text(card, t):   # rev 84: Decipher's own setting (wider face, pitch 63.5, measured measure)
            gtx_, nw_ = dc_hint(card["game_text"], card, "game_text")
            obj_ = " objhead" if card["template"].startswith("objective") else ""
            parts.append(f'<div class="gt fit dct{obj_}" data-fit-step="1"{fit_attrs(card, "game_text")} style="position:absolute;{dc_gt_box(card, t)}{nw_}">{dc_nobreak(game_text_html(gtx_))}</div>')
        else:
            parts.append(f'<div class="gt fit{" grow" if t.get("gt_grow") else ""}"{fit_attrs(card, "game_text")} style="position:absolute;{box("game_text")}">{game_text_html(card["game_text"])}</div>')
    # deploy / forfeit
    if card.get("deploy") not in (None, "") and "deploy" not in t and "game_text" in t and not t.get("wide"):
        # a card type whose frame has no deploy/forfeit boxes but the printing has them (artillery: Ewok Catapult):
        # the printed white / black boxes at the text box's left, as on the starship frames
        gx_, gy_, gw_, gh_ = t["game_text"]
        t = dict(t, deploy=(199, gy_ + gh_ - 196, 45, 82), forfeit=(199, gy_ + gh_ - 92, 46, 84))
        for k_, bg, fg in (("deploy", "#f2f2f2", "#000"), ("forfeit", "#000", "#fff")):
            x_, y_, w_, h_ = t[k_]
            parts.append(f'<div style="position:absolute;left:{x_ - 8}px;top:{y_ - 6}px;width:{w_ + 16}px;height:{h_ + 12}px;background:{bg};border:4px solid #888;box-sizing:border-box"></div>')
        card = dict(card, _df_ink=True)
    if card.get("deploy") is not None and "deploy" in t:
        for k_ in ("deploy", "forfeit"):   # long values (544) condense into the printed box, then shrink — never overflow it
            sec(k_)
            ink_ = (";color:#000" if k_ == "deploy" else ";color:#fff") if card.get("_df_ink") else ""
            fb_ = float(card.get("forfeit_box_border") or 0) if k_ == "forfeit" else 0
            if fb_ > 0:   # rev 77: the thicker black border round the forfeit value (Lando In Millennium Falcon, 1 in 20)
                x_, y_, w_, h_ = t[k_]; fb_ = min(fb_, 40)
                parts.append(f'<div style="position:absolute;left:{x_ - fb_:g}px;top:{y_ - fb_:g}px;width:{w_ + 2 * fb_:g}px;height:{h_ + 2 * fb_:g}px;background:#000"></div>')
            parts.append(f'<div class="{k_}" style="position:absolute;{box(k_)}{ink_}"><span class="fitnum" data-avail="{t[k_][2] + 6}" data-h="{t[k_][3]}">{esc(str(card[k_]))}</span></div>')
    sec(None)
    sec('scomp')
    light = card.get("side") == "Light"
    icons = list(card.get("icons", []))
    if card.get("squadron_row") and "stats_y" in t:
        # squadrons print their icons in one row under the stat boxes, a group per kind (X-wing Assault Squadron:
        # 3 scomp rings, 3 pilots, 3 nav computers)
        row = ["scomp"] * int(card.get("squadron_scomp") or 0) + icons; icons = []
        x_, y_, sz_ = 262, t["stats_y"] + 108, 66
        prev = None
        for nm in row:
            if prev is not None and nm != prev: x_ += 22
            if nm == "scomp":
                parts.append(f'<img src="{data_uri(ASSETS / "icons/scomp-ship.png")}" style="position:absolute;left:{x_}px;top:{y_}px;width:{sz_}px;height:{sz_}px">')
            else:
                key = f"{nm}-light" if light and f"{nm}-light" in ICON_FILES else nm
                parts.append(f'<img src="{data_uri(ASSETS / ICON_FILES[key])}" style="position:absolute;left:{x_}px;top:{y_}px;width:{sz_}px;height:{sz_}px">')
            x_ += sz_ + 8; prev = nm
    elif card.get("scomp") and "scomp" in t:
        sx, sy = t["scomp"]
        parts.append(f'<img src="{data_uri(ASSETS / "icons/scomp-ship.png")}" style="position:absolute;left:{sx}px;top:{sy}px">')
    sec('icons')
    # icon slots
    # two Warrior icons share one tall box on the printed cards (IG-88): "warrior","warrior" → "warrior2" (89×158);
    # Premiere (no expansion symbol) printed them as two separate boxes (Tonnika Sisters)
    packed = []
    for nm in icons:
        if nm == "warrior" and packed and packed[-1] == "warrior" and card.get("expansion_icon"):
            packed[-1] = "warrior2"
        else:
            packed.append(nm)
    slots = list(t.get("icon_slots", []))
    _pcs = t.get("pc_stack") if str(card.get("set_mark") or "").startswith("pc:") else None
    if packed and slots and _pcs and len(packed) > len(slots) and "warrior2" not in packed:
        # rev 84 (sites 2): the PC's starships stack 3-4 boxes up from a fixed foot (last box bottom 952 px at 745), boxes
        # 43 px on a 48 px pitch, shrinking only past the room four need, the set mark below them over the last box
        # (Azure Angel, Booster In Pulsar Skate, Bravo Fighter (V), Acclamator-Class Assault Ship, Blockade Support Ship)
        n = len(packed); k = min(_pcs["k"], _pcs["span"] / (n * 90 + (n - 1) * 10)); pitch = 100 * k
        x0 = slots[0][0]
        slots = [(x0 + int((89 - 89 * k) / 2), int(_pcs["bottom"] - 90 * k - (n - 1 - i) * pitch)) for i in range(n)]
        sizes = [k] * n
        card["_pc_mark_stacked"] = True
    elif packed and slots and ("warrior2" in packed or len(packed) > len(slots)) and "set_icon_abs" in t:
        # more than the frame's slots: stack from the first slot down to the set sphere, shrinking uniformly to fit
        x0, y0 = slots[0]
        sy = t["set_icon_abs"][1]; ss = t.get("set_icon_size", 76)
        heights = [158 if nm == "warrior2" else 90 for nm in packed]
        gap = 8
        total = sum(heights) + gap * len(heights) + ss
        avail = sy + ss - y0
        k = min(1.0, avail / total)
        y = y0; slots = []; sizes = []
        for h in heights:
            slots.append((x0 + int((89 - 89 * k) / 2), int(y))); sizes.append(k); y += (h + gap) * k
        card["_set_icon_override"] = (t["set_icon_abs"][0] + int((ss - ss * k) / 2), int(y), int(ss * k))
    else:
        sizes = [1.0] * len(packed)
    for (x, y), name, k in zip(slots, packed, sizes):
        if name == "warrior2":
            parts.append(f'<img src="{data_uri(ASSETS / "icons/col-warrior2.png")}" style="position:absolute;left:{x}px;top:{y}px;width:{int(89 * k)}px;height:{int(158 * k)}px">')
            continue
        key = f"{name}-light" if light and f"{name}-light" in ICON_FILES else name   # Light and Dark pilot icons differ
        _bf = BOX_ICON_FILES.get(key, ICON_FILES[key])
        if _bf.startswith("icons/col-"):   # Game Aid icon with its own silver frame, box size
            parts.append(f'<img src="{data_uri(ASSETS / _bf)}" style="position:absolute;left:{x}px;top:{y}px;width:{int(89 * k)}px;height:{int(90 * k)}px">')
        else:
            parts.append(f'<img src="{data_uri(ASSETS / "icons/icon-box.png")}" style="position:absolute;left:{x}px;top:{y}px;width:{int(89 * k)}px;height:{int(90 * k)}px">')
            parts.append(f'<img src="{data_uri(ASSETS / ICON_FILES[key])}" style="position:absolute;left:{x + int(6 * k)}px;top:{y + int(7 * k)}px;width:{int(75 * k)}px;height:{int(75 * k)}px">')
    sec('set_mark')
    # original-era virtual marker: the slips print the gold virtual-set symbol in the lower icon slot
    if card.get("set_mark") and "set_icon_abs" in t and not card.get("set_icon_file"):
        # Players Committee set marks, drawn as vector: modern Virtual Sets = the number on a tilted ring (blue; gold
        # for Set 0), 2009 Virtual Blocks = the black diamond with its chevron (Bill 2026-10-15, from Holotable scans)
        x, y = t["set_icon_abs"]; ss = t.get("set_icon_size", 76)
        if t.get("pc_set_icon_abs"):   # rev 84 (sites 2): where the PC prints it (below a 3-4 box stack: pc_stack["mark"])
            x, y = t["pc_stack"]["mark"] if card.get("_pc_mark_stacked") else t["pc_set_icon_abs"]
        card_ctx["_set_digit_fs"] = t.get("pc_set_digit_size") or t.get("set_digit_size", 142); card_ctx["_set_ring"] = t.get("set_ring", (100, 80, -28)); card_ctx["_set_ring_w"] = t.get("set_ring_w", 16)
        _sm = set_mark_html(card["set_mark"], x + ss / 2, y + ss / 2, ss)
        if card.get("side") == "Dark" and card["template"] in ("loc-site", "loc-system"):
            # the whole card (or its frame layers) is turned for the Dark seat: keep the set number upright
            _sm = f'<div style="position:absolute;left:0;top:0;width:{W}px;height:{H}px;transform-origin:{x + ss / 2:.0f}px {y + ss / 2:.0f}px;rotate:180deg">{_sm}</div>'
        parts.append(_sm)
    elif (card.get("virtual_set") is not None or card.get("set_icon_file")) and "set_icon_abs" in t:
        x, y = t["set_icon_abs"]
        sym = Path(card["set_icon_file"]) if card.get("set_icon_file") else ASSETS / f"icons/ovs-set-{card['virtual_set']}.png"   # each original set has its own symbol (from its Remaster PDF); card maker: the user's own
        ss = t.get("set_icon_size", 76)
        if card.get("_set_icon_override"):
            x, y, ss = card["_set_icon_override"]
        parts.append(f'<img src="{data_uri(sym)}" style="position:absolute;left:{x}px;top:{y}px;width:{ss}px;height:{ss}px">')
    sec('expansion')
    # expansion-set icon of the base Decipher card, in the ring right of the lore box (a slip never changes the top half)
    if card.get("expansion_icon") and "expansion_ring" in t:
        x, y = t["expansion_ring"]
        sz = t.get("expansion_size", 62)
        if t.get("expansion_halo"):   # rev 84: the frame's ring round the combo sphere (Light: red paint; Dark: lighter rim)
            hc_, hp_ = t["expansion_halo"]
            parts.append(f'<div style="position:absolute;left:{x - hp_}px;top:{y - hp_}px;width:{sz + 2 * hp_}px;height:{sz + 2 * hp_}px;border-radius:50%;background:{hc_}"></div>')
        if t.get("dc_sphere") and card.get("decipher_print"):
            # rev 84: Decipher's printed sphere: the disc (its own dark rim included) in a hole only 1 px wider, the
            # frame's light bevel showing round it (measured on 120 printed scans, see DC_PRINT)
            cx_, cy_, d_ = t["dc_sphere"]
            bw_ = DC_SPHERE_BEVEL[0]   # the frame's grey bevel round the hole (r 15-17.5 px at 745 on every scan)
            parts.append(f'<div style="position:absolute;left:{cx_ - d_ / 2 - bw_:g}px;top:{cy_ - d_ / 2 - bw_:g}px;width:{d_ + 2 * bw_:g}px;height:{d_ + 2 * bw_:g}px;border-radius:50%;background:{DC_SPHERE_BEVEL[1]}"></div>')
            parts.append(f'<div style="position:absolute;left:{cx_ - d_ / 2 - 1:g}px;top:{cy_ - d_ / 2 - 1:g}px;width:{d_ + 2:g}px;height:{d_ + 2:g}px;border-radius:50%;background:#000"></div>')
            parts.append(dc_sphere_img(card["expansion_icon"], cx_, cy_, d_))
        elif card.get("expansion_icon_in_hole", True) and not t.get("expansion_bare"):
            # printed cards: the set icon is a sphere sitting in a black hole of the frame
            hc_, hp_ = t.get("expansion_hole", ("#000", 1))
            parts.append(f'<div style="position:absolute;left:{x - hp_}px;top:{y - hp_}px;width:{sz + 2 * hp_}px;height:{sz + 2 * hp_}px;border-radius:50%;background:{hc_};box-shadow:0 0 0 2px #000"></div>' if hp_ > 1 else
                         f'<div style="position:absolute;left:{x - 1}px;top:{y - 1}px;width:{sz + 2}px;height:{sz + 2}px;border-radius:50%;background:#000"></div>')
            isz = sz - t.get("expansion_inset", 4)   # rev 84: Podracers print a thinner black outline (2)
            parts.append(f'<img src="{data_uri(ASSETS / card["expansion_icon"])}" style="position:absolute;left:{x + (sz - isz) // 2}px;top:{y + (sz - isz) // 2}px;width:{isz}px;height:{isz}px">')
        else:
            parts.append(f'<img src="{data_uri(ASSETS / card["expansion_icon"])}" style="position:absolute;left:{x}px;top:{y}px;width:{sz}px;height:{sz}px">')
    sec('coins')
    if t.get("coins") and card.get("credits"):   # Reflections Gold credit value: gold coins stacked up from the box foot
        cx_, cy_, step_ = t["coins"]
        for k in range(min(int(card["credits"]), 4)):
            parts.append(f'<img src="{data_uri(ASSETS / "icons/rg-coin.png")}" style="position:absolute;left:{cx_}px;top:{cy_ - k * step_}px">')
    sec('expansion')
    if card.get("expansion_icon") and t.get("system_ring") and card.get("draw_system_ring"):
        # systems keep the scan whole (its own sphere included): drawn only when asked (card maker: no scan, or a new set)
        x, y, sz = t["system_ring"]
        if card.get("decipher_print") and t.get("dc_system_ring"):
            x, y, sz = t["dc_system_ring"]   # rev 84: where the printed systems carry it (Light systems, sets 1-9)
            if card.get("side") == "Dark" and t.get("dc_system_ring_dark"):
                x, y, sz = t["dc_system_ring_dark"]   # rev 84: Dark systems (the layer is turned 180° afterwards)
            ep1_ = "episode1" in (card.get("ring_icons") or []) and t.get("dc_system_ep1")
            if ep1_:
                # rev 84: Episode I-era systems (Coruscant set): the sphere bare on the starfield (no grey ring), Decipher's
                # Episode I disc under it in a thin grey ring (Coruscant, Naboo; dc_system_ep1 = offset of the disc's
                # centre from the sphere's, disc size, ring size, ring width, ring colour)
                ex_, ey_, ed_, er_, ew_, ec_ = t["dc_system_ep1"]
                dcx_, dcy_ = x + sz / 2 + ex_, y + sz / 2 + ey_
                if t.get("dc_system_ep1_sphere"):
                    # Rev 84 (Episode I spheres): the bare sphere prints larger than the ringed one, same centre
                    d2_ = t["dc_system_ep1_sphere"]; x, y, sz = x + (sz - d2_) / 2, y + (sz - d2_) / 2, d2_
                parts.append(f'<div style="position:absolute;left:{x - 1}px;top:{y - 1}px;width:{sz + 2}px;height:{sz + 2}px;border-radius:50%;background:#000"></div>')
                parts.append(f'<div style="position:absolute;left:{dcx_ - er_ / 2:g}px;top:{dcy_ - er_ / 2:g}px;width:{er_}px;height:{er_}px;border-radius:50%;box-sizing:border-box;background:#000;border:{ew_}px solid {ec_}"></div>')
                parts.append(f'<img src="{data_uri(ASSETS / "icons/ep1-disc.png")}" style="position:absolute;left:{dcx_ - ed_ / 2:g}px;top:{dcy_ - ed_ / 2:g}px;width:{ed_}px;height:{ed_}px;border-radius:50%">')
            else:
                # in a dark grey ring ~5 px (745) wide, as printed on the starfield (Corellia, Bespin)
                parts.append(f'<div style="position:absolute;left:{x - 10}px;top:{y - 10}px;width:{sz + 20}px;height:{sz + 20}px;border-radius:50%;box-sizing:border-box;background:#000;border:9px solid #3c3e41"></div>')
        ic_ = card["expansion_icon"]
        if "episode1" in (card.get("ring_icons") or []) and card.get("set_mark"):
            ic_ = "icons/inline-episode1.png"   # PC Episode I systems print the circled Episode I icon there (Naboo (V))
        if card.get("decipher_print") and t.get("dc_system_ring") and ic_ in DC_SPHERE_ZOOM:
            parts.append(dc_sphere_img(ic_, x + sz / 2, y + sz / 2, sz, system=True))   # rev 84: Coruscant's gold rim at the edge
        else:
            parts.append(f'<img src="{data_uri(ASSETS / ic_)}" style="position:absolute;left:{x}px;top:{y}px;width:{sz}px;height:{sz}px">')
    sec('ring_icons')
    # Episode I icon below the ring, as the Episode I-era printed cards carry it (Radiant VII, Wesa Ready To Do Our-sa Part)
    if card.get("ring_icons") and "expansion_ring" in t:
        x, y = t["expansion_ring"]
        sz = t.get("expansion_size", 62)
        k = 0 if (card.get("ring_fill") and not card.get("expansion_icon")) else 1   # card maker: no sphere -> the first disc takes its place (Aayla Secura)
        mk = 0; nd_used = False
        for nm in card["ring_icons"]:
            if nm in MARGIN_DISCS and "game_text" in t:   # printed in the right margin at the text box top (Unlimited Power!; Skywalker: My Sister Has It, #63; Personal Force: Commando Training, #62)
                ds_ = t.get("margin_disc_size", sz - 6)
                mx_, my_ = x + 3 + t.get("margin_disc_dx", 0), t["game_text"][1] - 70 + t.get("margin_disc_dy", 0) + mk * t.get("margin_disc_pitch", 84)
                if t.get("margin_disc_hole"):   # the PC sets it in a dark hole of the frame, like the expansion sphere (#63)
                    hp_ = t.get("margin_disc_hole_pad", 5); hc_ = t["margin_disc_hole"] if isinstance(t["margin_disc_hole"], str) else "#2a0c0c"
                    parts.append(f'<div style="position:absolute;left:{mx_ - hp_}px;top:{my_ - hp_}px;width:{ds_ + 2 * hp_}px;height:{ds_ + 2 * hp_}px;border-radius:50%;background:{hc_}"></div>')
                parts.append(f'<img src="{data_uri(ASSETS / RING_DISCS[nm])}" style="position:absolute;left:{mx_}px;top:{my_}px;width:{ds_}px;height:{ds_}px;border-radius:50%">')
                mk += 1
                continue
            # rev 71: Virtual Block Objectives, Missions and Epic Events print it in the left margin too (A Stunning Move, Deep Hatred (V))
            _nd = t.get("_nolore_disc") or ((200, 412) if card.get("disc_left") else None)
            if nm in ("episode1", "episode7") and not _nd and t.get("ring_disc_left") and not nd_used:
                # rev 84: printed Objectives / Epic Events: the Episode disc in the left margin under the type disc (We Have A Plan)
                ncx, ncy, nsz = t["ring_disc_left"]
                _df = t.get("ring_disc_left_files", {}).get(nm, RING_DISCS[nm])   # rev 84: the PC Finalizers' blue-ringed disc
                parts.append(f'<img src="{data_uri(ASSETS / _df)}" style="position:absolute;left:{ncx - nsz / 2}px;top:{ncy - nsz / 2}px;width:{nsz}px;height:{nsz}px;border-radius:50%">')
                nd_used = True
                continue
            if nm in RING_DISCS and _nd and not nd_used:
                ncx, ncy = _nd
                parts.append(f'<img src="{data_uri(ASSETS / RING_DISCS[nm])}" style="position:absolute;left:{ncx - 29}px;top:{ncy - 29}px;width:58px;height:58px;border-radius:50%">')
                nd_used = True
                continue
            if nm in RING_DISCS:
                dy_ = y + k * (sz + 30) + t.get("ring_disc_dy", 0)
                if t.get("expansion_hole"):   # same red ring as the sphere (RG-GEMP renders)
                    hc_, hp_ = t["expansion_hole"]
                    parts.append(f'<div style="position:absolute;left:{x + 3 - hp_}px;top:{dy_ - hp_}px;width:{sz - 6 + 2 * hp_}px;height:{sz - 6 + 2 * hp_}px;border-radius:50%;background:{hc_};box-shadow:0 0 0 2px #000"></div>')
                # rev 84: a template may set the disc's own size / left offset / picture (Podracers: Decipher's printed disc)
                dsz_ = t.get("ring_disc_size", sz - 6); ddx_ = t.get("ring_disc_dx", 3)
                src_ = (t.get("ring_disc_icons") or {}).get(nm, RING_DISCS[nm])
                parts.append(f'<img src="{data_uri(ASSETS / src_)}" style="position:absolute;left:{x + ddx_}px;top:{dy_}px;width:{dsz_}px;height:{dsz_}px;border-radius:50%">')
                k += 1
    sec('margin_icon')
    if card.get("margin_icon") and "game_text" in t:   # Scoundrel: a portrait disc in the left margin at the text box top
        gx, gy, gw, gh = t["game_text"]
        parts.append(f'<img src="{data_uri(ASSETS / "icons/pc-gameaid-named" / (card["margin_icon"] + ".png"))}" style="position:absolute;left:{t.get("margin_icon_x", 190)}px;top:{gy + 8}px;width:84px;height:84px;border-radius:50%">')
    if card.get("mission_disc") and t.get("mission_disc"):   # rev 73: Rebel / Imperial Aces print the Objective disc left of the text box
        mcx, mcy = t["mission_disc"]
        parts.append(f'<img src="{data_uri(ASSETS / "icons/pc-gameaid-x4" / (card["mission_disc"] + ".png"))}" style="position:absolute;left:{mcx - 28}px;top:{mcy - 28}px;width:56px;height:56px;border-radius:50%">')
    if card.get("margin_disc") and "game_text" in t:   # rev 73: the round [Vader] disc left of the text box top (Vader's Mask)
        gx_, gy_ = t["game_text"][:2]
        mx_, my_ = t.get("margin_disc_c", (190, gy_ + 34))
        parts.append(f'<img src="{data_uri(ASSETS / "icons" / (card["margin_disc"] + ".png"))}" style="position:absolute;left:{mx_ - 41}px;top:{my_ - 41}px;width:82px;height:82px;border-radius:50%">')
    sec('copyright')
    # vertical Lucasfilm / Decipher line on the right margin of the art, as on the printed card
    if card.get("copyright") and t.get("copyright_split") and card.get("copyright_split"):   # systems (card maker): split over the two bottom margins
        txt = card["copyright"]
        cut = txt.find("TM, ®")
        halves = (txt[:cut].strip(), txt[cut:].strip()) if cut > 0 else (txt, "")
        dc_ = card.get("decipher_print")
        boxes_ = t["copyright_split"]
        if dc_ and t.get("dc_split"):   # rev 84: the two halves where Decipher printed them (centre x, y)
            boxes_ = [(x_ - 18, y_ - 210, 36, 420) for x_, y_ in t["dc_split"]]
        for k_, ((cx, cy, cw, ch), part) in enumerate(zip(boxes_, halves)):
            if part:
                # rev 84: Decipher set the left half reading top to bottom (both halves face the card)
                down_ = ";transform:rotate(90deg) scaleX(%g)" % DC_COPY["cond"] if dc_ and k_ == 0 and t.get("dc_split_left_down") else ""
                parts.append(f'<div class="copy" style="position:absolute;left:{cx}px;top:{cy}px;width:{cw}px;height:{ch}px">'
                             f'<div class="copyin{" dccopy" if dc_ else ""}" style="color:#fff{down_}">{dc_copy_html(part) if dc_ else esc(part)}</div></div>')
    elif card.get("copyright") and t.get("rg_copy"):
        # rev 84 (geometry 2): Reflections Gold's 2001 playtest prints (wide Effects / Interrupts) split the line over the
        # black border, white, Decipher's typesetting: "© 2001 LUCASFILM LTD. & TM." down the left edge reading top to
        # bottom, "TM, ®, & © 2001 DECIPHER INC." up the right edge (Local Trouble, Strangle, Weapon Malfunction photos)
        txt = card["copyright"]
        cut = txt.find("TM, ®")
        halves = (txt[:cut].strip(), txt[cut:].strip()) if cut > 0 else ("", txt)
        for k_, ((cx, cy), part) in enumerate(zip(t["rg_copy"], halves)):
            if part:
                rot_ = "90deg" if k_ == 0 else "-90deg"
                parts.append(f'<div class="copy" style="position:absolute;left:{cx - 30:g}px;top:{cy - 400:g}px;width:60px;height:800px">'
                             f'<div class="copyin dccopy" style="color:#fff;font-size:{t.get("rg_copy_size", DC_COPY["size"])}px;transform:rotate({rot_}) scaleX({DC_COPY["cond"]})">{dc_copy_html(part)}</div></div>')
    elif card.get("copyright") and t.get("dc_copy") and card.get("decipher_print") and not (t.get("dc_copy_unless_scan") and card.get("art_scan")):
        # rev 84: Decipher's typesetting of the line (taller, condensed, full-size circled © and ®), centred on dc_copy;
        # full-art Admiral's Orders print it over the picture (a scan already carries it: dc_copy_unless_scan)
        dcx, dcy = t["dc_copy"]
        ink_ = (f'color:{t["dc_copy_ink"]};' if t.get("dc_copy_ink") else "") + (f'font-size:{t["dc_copy_size"]}px;' if t.get("dc_copy_size") else "")
        ink_ = f' style="{ink_}"' if ink_ else ""
        parts.append(f'<div class="copy" style="position:absolute;left:{dcx - 30:g}px;top:{dcy - 600:g}px;width:60px;height:1200px">'
                     f'<div class="copyin dccopy"{ink_}>{dc_copy_html(card["copyright"])}</div></div>')
    elif card.get("copyright") and not t.get("no_copyright"):   # full-art Admiral's Orders keep the scan's own line
        cx, cy, cw, ch = t.get("copyright", (t.get("copyright_x", 1404), ay, 36, ah))
        if card.get("copyright_dxy"):   # rev 84: a printing's own offset of the line (Tatooine's Light Epic Events)
            cx, cy = cx + card["copyright_dxy"][0], cy + card["copyright_dxy"][1]
        # rev 84: a Decipher card keeps the template's place but takes Decipher's typesetting (full-size ®)
        dc_ = card.get("decipher_print")
        ink_ = f' style="color:{card["copyright_ink"]}"' if card.get("copyright_ink") else ""   # rev 84: Tatooine's Light Epic Events print white
        parts.append(f'<div class="copy" style="position:absolute;left:{cx}px;top:{cy}px;width:{cw}px;height:{ch}px">'
                     f'<div class="copyin{" dccopy" if dc_ else ""}"{ink_}>{dc_copy_html(card["copyright"]) if dc_ else esc(card["copyright"])}</div></div>')
    sec('art_credit')
    # PC art credit up the left side of the art ("Image courtesy of Jesus Conde", Endless Legions VS26; swccg-guild/work#100):
    # the copyright line's mirror image about the art window, same face and size
    if card.get("art_credit") and not t.get("no_copyright"):
        cx, cy, cw, ch = t.get("copyright", (t.get("copyright_x", 1404), ay, 36, ah))
        # measured on Endless Legions (PC hires, ×2 = master px): text centre x ≈ 2 × 61.5, run 235 px at 745 → 51 px face
        lx = t.get("art_credit_x", ax - (cx - (ax + aw)) - cw + 10)
        parts.append(f'<div class="copy" style="position:absolute;left:{lx}px;top:{cy}px;width:{cw}px;height:{ch}px">'
                     f'<div class="copyin artcredit" style="font-family:{t.get("art_credit_font", "AGCn")};font-size:{t.get("art_credit_size", 51)}px;letter-spacing:0;'
                     f'color:#fff;-webkit-text-stroke:1.6px #fff;text-shadow:0 0 2px #000,0 0 2px #000,0 0 4px #000,2px 2px 4px #000">{esc(card["art_credit"])}</div></div>')
    sec('credits')
    # slip credit lines in the side margins (Wokling (V): "Original concept by …" left, "GenCon 2002 Winner" right),
    # italic, reading bottom-to-top, spanning the banner + text box
    # centred in the coloured margin between frame edge and text box, as the slips print them (Bill 2026-10-13);
    # margins measured on the frames: Light ≈169–246 / 1389–1433, Dark ≈145–264 / 1361–1483 (div is 40 px wide)
    mx = t.get("credit_mx") or ((187, 1391) if t.get("dark_text") else (185, 1402))
    for key, x in (("margin_left", mx[0]), ("margin_right", mx[1]), ("margin_right_top", mx[1])):
        if card.get(key) and "game_text" in t:
            gx, gy, gw, gh = t["game_text"]
            cx_, cy_, cw_, ch_ = t.get("card_type", (gx, gy - 160, gw, 61))
            top, bot = cy_, gy + gh
            ink = t.get("credit_ink") or margin_ink(fr, x - fx, top - fy, bot - fy)
            if (key == "margin_right_top" or key == "margin_right" and card.get("margin_right_at") == "top") and t.get("icon_slots"):
                # the slip prints the credit above the column icons, level with the stat row (Padmé Naberrie (V))
                top, bot = t.get("stats_y", top) - 60, t["icon_slots"][0][1] - 8
            elif key == "margin_right" and card.get("icons") and t.get("icon_slots"):
                # the column icons sit in the right margin: the credit runs below them (Mace Windu (V))
                top = max(top, t["icon_slots"][min(len(card["icons"]), len(t["icon_slots"])) - 1][1] + 100)
                if t.get("set_icon_abs"):
                    bot = min(bot, t["set_icon_abs"][1] - 8)   # and above the set sphere
            if key == "margin_left" and card.get("scomp") and t.get("scomp"):
                bot = min(bot, t["scomp"][1] - 12)   # above the scomp ring (Stinger (V))
                if "deploy" in t and card.get("deploy") is not None:
                    top = t.get("stats_y", top) - 60
            elif key == "margin_left" and "deploy" in t and card.get("deploy") is not None:
                # characters: the deploy/forfeit boxes sit in the left margin — the credit runs above them (as The
                # Emperor (V) prints it), white on the dark frames
                top, bot = t.get("stats_y", top) - (60 if "\n" in card[key] else 10), t["deploy"][1] - 10
            # the rotated line is as long as the text; shrink the font so it fits the span (AGCn italic ≈ 0.40 em/char)
            # the slips run the credit nearly the whole span at ~46 px; the fitcredit JS shrinks it only if it would overflow
            parts.append(f'<div class="copy" style="position:absolute;left:{x}px;top:{top}px;width:40px;height:{bot - top}px">'
                         f'<div class="credit fitcredit" data-avail="{bot - top - 10}"{(' data-lines="2" data-fs="' + ('48' if ink == '#fff' and not t.get('dark_text') else '42') + '"') if chr(10) in card[key] else ''} style="color:{ink};font-size:46px">{esc(card[key]).replace(chr(10), "<br>")}</div></div>')
    sec('credits')
    if card.get("credit_bottom") and "game_text" in t:   # a credit set under the text box (Lord Vader (V))
        gx, gy, gw, gh = t["game_text"]
        cink = "#000" if t.get("dark_text") else "#ddd"
        cb = card["credit_bottom"]
        if isinstance(cb, list):   # left + right under the text box (Yoda, Dominator, Thrawn (V), VS14)
            inner = "".join(f"<span>{esc(x)}</span>" for x in cb)
            parts.append(f'<div style="position:absolute;left:{gx - 20}px;top:{t.get("credit_bottom_y", 2024)}px;width:{gw + 40}px;height:44px;display:flex;justify-content:space-between;'
                         f'font-family:AGCn;font-style:italic;font-size:38px;line-height:44px;color:{cink};white-space:nowrap">{inner}</div>')
        else:
            parts.append(f'<div style="position:absolute;left:{gx - 60}px;top:{t.get("credit_bottom_y", 2024)}px;width:{gw + 120}px;height:44px;text-align:center;'
                         f'font-family:AGCn;font-style:italic;font-size:36px;line-height:44px;color:{cink};white-space:nowrap">{esc(cb)}</div>')
    sec('icons')
    if (t.get("landscape") or t.get("system")) and card.get("icons") and t.get("set_icon_abs"):
        sx_, sy_ = t["set_icon_abs"]; sz_ = t.get("set_icon_size", 60)
        for k, ic in enumerate(card["icons"]):   # margin discs the slip prints beside the set sphere (Episode I)
            f_ = ICON_FILES.get(ic) or ((f"icons/set-{ic[4:]}-decipher.png" if (ASSETS / f"icons/set-{ic[4:]}-decipher.png").exists() else f"icons/set-{ic[4:]}-grainy.png") if ic.startswith("set:") else None)
            if f_:
                parts.append(f'<img src="{data_uri(ASSETS / f_)}" style="position:absolute;left:{sx_}px;top:{sy_ - (k + 1) * (sz_ + 14)}px;width:{sz_}px;height:{sz_}px">')
    sec('caption')
    # bottom strip in the black border: title (as the slip prints it) left, card number right
    cap = card["caption"] if card.get("caption") is not None else card["title"]   # "" = no strip text (Decipher cards)
    cy = t.get("caption_y", 2082)
    # Bill 2026-11-01 (Aim High (V)): the slips print the margin caption and number about 1.6x our old 48 px and nearer the
    # card edges. Portrait cards (the default strip) now start at the slip's size and the fitter grows / shrinks each one
    # to fill the strip: the caption up to the number, the number in its own box (data-capmax, `.capgrow` in fit_js).
    capgrow = not card.get("caption_fixed")   # every template since rev 55 (Bill 2026-11-02: locations and wide cards too)
    # The strip is the black band between the frame's bottom edge and the visible card edge. The Holotable / GEMP image
    # keeps master rows up to 2150 only (holotable_size), so text placed by the box alone ran off the bottom (Bill
    # 2026-11-01, Aim High (V)). fit_js sizes by the font's real cap height + descender and sets the baseline itself.
    # PC slip geometry (DefensiveShields.pdf, measured 2026-11-02): caption Arial Narrow Bold drawn 7.54 pt tall and
    # condensed to 90.6 % (glyph advances give a 6.83 pt em, the capitals stand 5.4 pt), bullet Fiorello Condensed 7.56 pt,
    # number Akzidenz-Grotesk BE Bold Italic 7.08 pt, one baseline 6.4 pt under the frame. Scaled by the frame width
    # (163.2 pt = 1336 master px, 8.19 px/pt): 61.7 px ×0.906 / 61.9 px / 58.0 px, baseline 52 px under the frame.
    # Rev 57 (#73): measured on all 18 DS slips, the number's baseline is 51.5–52.2 px under the frame's bottom edge
    # (the first black row, _st), but the PC set each caption by hand, 49.5–56.3 px. Both default to 52 from _st (rev 53
    # put them at _st − 1 + 52, 1 px high); "caption_drop" / "number_drop" carry a card's own slip values (vsDS specs),
    # and such a card keeps the slip's type size: its gap above the ink drops from 6 px to 2 px (the PC's own, ~2.3 px).
    _st = card_ctx.get("_strip_top") or t.get("strip_top", 2076)   # first black row under this card's own frame
    _sb = t.get("strip_bottom", 1560 if is_wide(t) else 2150)      # last master row the Holotable / GEMP image keeps
    strip = (f'data-top="{_st}" data-bottom="{_sb}" '
             f'data-base="{_st + card.get("caption_drop", 52)}" data-nbase="{_st + card.get("number_drop", 52)}" data-gap="{2 if "caption_drop" in card else 6}" '
             f'data-capfs="{card.get("caption_size", 61.7)}" data-capsx="{card.get("caption_scale_x", 0.906)}" data-numfs="{card.get("number_size", 58.0)}"')
    if cap and capgrow:
        cap = cap.replace("◇", "◊")   # the slips print Decipher's non-unique diamonds as Arial's lozenge (VS13 #1)
        parts.append(f'<div class="cap capgrow" {strip} style="position:absolute;left:{card.get("caption_x", 153)}px;top:0;width:1080px;height:0"><span class="capt" style="position:absolute;left:0{";font-style:italic" if card.get("caption_italic") else ""}">{game_text_html(cap)}</span></div>')
    elif cap: parts.append(f'<div class="cap" style="position:absolute;left:160px;top:{cy}px;width:900px;height:52px">{game_text_html(cap)}</div>')
    sec('credits')
    if "game_text" not in t and (card.get("margin_left") or card.get("margin_right")) and t.get("landscape"):
        # locations: the slips print the credits up the left margin between the two bars (Carida (V)), reading top-down
        a_, b_ = (card.get("margin_left") or "").replace("\n", " "), (card.get("margin_right") or "").replace("\n", " ")
        parts.append(f'<div style="position:absolute;left:{t.get("credit_x", 186)}px;top:430px;width:44px;height:760px;display:flex;align-items:center;justify-content:center">'
                     f'<div style="flex-shrink:0;width:760px;transform:rotate(90deg);display:flex;justify-content:space-between;font-family:AGCn;font-style:italic;font-size:36px;color:#000;white-space:nowrap">'
                     f'<span>{esc(a_)}</span><span>{esc(b_)}</span></div></div>')
    sec('caption')
    if card.get("credit_strip"):   # a credit printed in the black caption strip, right, before the number (Watto (V), VS16)
        parts.append(f'<div style="position:absolute;right:{1632 - 1240}px;top:{cy + 4}px;height:48px;line-height:48px;font-family:AGCn;font-style:italic;'
                     f'font-size:38px;color:#fff;white-space:nowrap">{esc(card["credit_strip"])}</div>')
    sec('number')
    if card.get("number"):
        _num = esc(str(card["number"]).zfill(2) if str(card["number"]).isdigit() else str(card["number"]))
        if not card.get("caption_fixed"):
            parts.append(f'<div class="num capgrow" {strip} style="position:absolute;right:{card.get("number_right", 185)}px;top:0;width:330px;height:0;transform:none"><span class="capt" style="position:absolute;right:0">{_num}</span></div>')
        else:
            parts.append(f'<div class="num" style="position:absolute;right:230px;top:{cy}px;width:300px;height:52px">{_num}</div>')
    # PC labels (Bill 2026-11-01): small printed marks the Players Committee adds — the errata mark in the bottom-right
    # border (D-E1, E2 …), the original card's title bottom-left, "Original concept by …" in the frame's bottom bar.
    # card "errata_mark": "D-E1" is a shortcut for {"preset": "errata", "text": "D-E1"}; "labels": [{preset|x/y, text, …}]
    for i_, lb in enumerate(card_labels(card)):
        sec(f"label{i_}")
        if t.get("labels_rotated") and (lb.get("preset") in ("bottom-left", "bottom-right", "ai", "errata") or lb.get("kind") == "art_credit"):
            # rev 84: the PC's landscape cards (Finalizer, Finalizer (AI), the (ALT) Effects) set the labels as on a portrait
            # card turned a quarter left: the caption, the (AI) stamp, the errata mark and the art credit read upward in the
            # right margin; "Original concept by ..." stays in the bottom bar (Bow To The First Order (ALT))
            parts.append(f'<div style="position:absolute;left:0;top:0;width:{H}px;height:{W}px;transform-origin:0 0;'
                         f'transform:translate(0px,{H}px) rotate(-90deg)">'
                         f'{label_html(dict(t.get("label_presets", {}).get(lb.get("kind") or lb.get("preset"), {}), **lb), H, W)}</div>')
        elif t.get("label_presets"):   # rev 84 (sites 2): the template's measured placement of a label kind / preset
            parts.append(label_html(dict(t["label_presets"].get(lb.get("kind") or lb.get("preset"), {}), **lb), W, H))
        else:
            parts.append(label_html(lb, W, H))
    # user layers (card maker): free text boxes and pictures, each its own piece "x:<id>" (move / resize / hide / reset)
    for ex in (card.get("extras") or [])[:30]:
        if not isinstance(ex, dict):
            continue
        xid = re.sub(r"[^\w-]", "", str(ex.get("id") or ""))[:20] or "x"
        num = lambda k, d, lo, hi: max(lo, min(hi, float(ex.get(k) if isinstance(ex.get(k), (int, float)) else d)))
        x_, y_ = num("x", 300, -500, W + 500), num("y", 300, -500, H + 500)
        w_, h_ = num("w", 600, 20, W * 2), num("h", 200, 20, H * 2)
        sec(f"x:{xid}")
        flip_ = ""
        if card.get("side") == "Dark" and card["template"] == "loc-site":   # the whole card is turned afterwards: pre-turn
            x_, y_ = W - x_ - w_, H - y_ - h_; flip_ = "rotate:180deg;"
        if ex.get("kind") == "image":
            d_ = str(ex.get("data") or "")
            if re.match(r"^data:image/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$", d_) and len(d_) < 12_000_000:
                fit_ = "cover" if ex.get("fit") == "cover" else "contain"
                parts.append(f'<img src="{d_}" style="position:absolute;left:{x_:.0f}px;top:{y_:.0f}px;width:{w_:.0f}px;height:{h_:.0f}px;object-fit:{fit_};{flip_}">')
        else:
            font_ = {"text": "AGCn", "bold": "AGBoldCnA", "title": "HoloTitle", "number": "AGMedExt", "lore": "AGLightCn"}.get(str(ex.get("font")), "AGCn")
            col_ = str(ex.get("color") or "#ffffff"); col_ = col_ if re.fullmatch(r"#[0-9a-fA-F]{3,8}", col_) else "#ffffff"
            bg_ = str(ex.get("bg") or ""); bg_ = bg_ if re.fullmatch(r"#[0-9a-fA-F]{3,8}", bg_) else "transparent"
            al_ = ex.get("align") if ex.get("align") in ("left", "center", "right") else "left"
            fs_ = num("size", 56, 12, 400)
            txt_ = game_text_html(str(ex.get("text") or "")[:2000]).replace("\n", "<br>")
            parts.append(f'<div style="position:absolute;left:{x_:.0f}px;top:{y_:.0f}px;width:{w_:.0f}px;height:{h_:.0f}px;background:{bg_};color:{col_};'
                         f'font-family:{font_};font-size:{fs_:.0f}px;line-height:1.12;text-align:{al_};overflow:hidden;box-sizing:border-box;padding:8px 12px;'
                         f'{"font-style:italic;" if ex.get("italic") else ""}{flip_}">{txt_}</div>')
    # wrap each piece's elements in a full-card layer (children keep their coordinates)
    ends = [i for _, i in marks[1:]] + [len(parts)]
    # Dark systems are printed from the Dark Side's seat (Alderaan, Premiere): every layer but the picture and the
    # bottom caption strip turned 180° about the card centre
    dsys = card.get("side") == "Dark" and card["template"] == "loc-system"
    fixes = PC_PIECE_FIX.get(card["template"], {}) if card.get("pc_type") else {}
    for (name, i), j in reversed(list(zip(marks, ends))):
        turn = ";rotate:180deg" if dsys and name not in ("art", "caption", "number") and not str(name).startswith("x:") else ""
        fx_ = fixes.get(name)
        if fx_ and name and j > i:   # rev 74: the piece where the PC's card has it (see PC_PIECE_FIX)
            turn += f";translate:{fx_[0] * 2:g}px {fx_[1] * 2:g}px"
            if len(fx_) > 2 and name == "icons" and t.get("icon_slots"):
                ox_, oy_ = t["icon_slots"][0]
                turn += f";scale:{fx_[2]:g};transform-origin:{ox_ + 44.5:.0f}px {oy_ + 90:.0f}px"
        if name and j > i:
            parts[i:j] = [f'<div class="piece" data-piece="{name}" style="position:absolute;left:0;top:0;width:{W}px;height:{H}px{turn}">'] + parts[i:j] + ["</div>"]
        elif j > i and turn:
            parts[i:j] = [f'<div style="position:absolute;left:0;top:0;width:{W}px;height:{H}px{turn}">'] + parts[i:j] + ["</div>"]
    if card.get("early_slip") and not is_wide(t) and not t.get("landscape"):
        # rev 75: the 2002 Virtual Set #1 paper slip laid over the printed card's lower quarter (early_slip.py)
        import early_slip
        parts.append(f'<div class="piece" data-piece="slip" style="position:absolute;left:0;top:0;width:{W}px;height:{H}px">'
                     + early_slip.html(card["early_slip"], 144, 144 + 1931, 1343 / early_slip.SLIP_W, 1931 / 252, esc,
                                       {"text": "'PCText'", "stat": "'AGBoldCnA'", "mark": "'PCNum'"}) + "</div>")
    parts.append("</div>")
    ink = "#000" if t.get("dark_text") else "#fff"
    LP = dict(LORE_CSS, **t.get("lore_css", {}), **card.get("_lore_css", {}))   # rev 84: a template's own lore size (Podracers)
    title_stroke_css = f"-webkit-text-stroke:{t['title_stroke']}px currentColor;" if t.get("title_stroke") else ""   # the PC's white Dark titles print 0.3 px heavier than Holotable Title (#118 stem check)
    css = f"""
    {font_css}
    body{{margin:0;background:#000}}
    .inv .title, .inv .lore, .inv .ctype, .inv .gt, .inv .destiny {{rotate:180deg}}   /* Dagobah's upside-down cards (Through The Force Things You Will See) */
    .title{{font-family:HoloTitle;font-size:{t.get("title_size", 81.4)}px;color:{t.get("title_ink", ink)};letter-spacing:{t.get("title_ls", 1)}px;{title_stroke_css}line-height:90px;white-space:nowrap}}
    .destiny{{font-family:AGMedExt;font-size:80px;color:#fff;display:flex;align-items:center;justify-content:center;padding-top:2px;box-sizing:border-box}}
    .lore{{font-family:{LP["ff"]};font-size:{LP["fs"]}px;color:{ink};letter-spacing:{LP["ls"]}px;line-height:{LP["lh"]}px;padding:{LP["pt"]}px 0 0 0;box-sizing:border-box;text-align:{card.get("lore_align", "left")};overflow-wrap:anywhere;text-indent:{card.get("lore_indent", LP["ind"])}px}}
    .lore b{{font-family:AGCn;font-weight:bold}}
    .gt{{font-family:AGCn;font-size:{t.get("gt_size", 62)}px;color:{t.get("gt_ink", ink)};letter-spacing:0.5px;line-height:{t.get("gt_size", 62) + t.get("gt_lh_add", 2)}px;box-sizing:border-box;padding:6px 0 0 0;letter-spacing:{t.get("gt_ls", -0.4)}px;white-space:{"pre" if "\n" in card.get("game_text", "") else "normal"}}}
    .glyph{{font-family:"DejaVu Sans",sans-serif;font-size:1.0em;line-height:0;vertical-align:0.02em}}
    .tri{{font-family:"DejaVu Sans",sans-serif;font-size:0.88em;vertical-align:0.14em;line-height:0}}
    .dia{{font-family:"DejaVu Sans",sans-serif;font-size:0.9em;vertical-align:0.06em;line-height:0}}
    .gt b{{font-family:AGBoldCnA}}
    .pctext b{{font-family:PCTextBold;font-weight:normal}}
    .pcic{{display:inline-flex;justify-content:center;width:{PC_ICON_W - 6}px;margin:0 3px;overflow:visible;white-space:nowrap}}
    .pcic > *{{flex:none;margin-left:0!important;margin-right:0!important}}
    .gt-icon{{vertical-align:-9px;margin:0 3px}}
    .dct .gt-icon{{transform:scaleX({1 / DC_TEXT["gt"]["k"]:.4f})}}
    .noicon{{display:inline-block;position:relative;width:62px;height:62px;border:6px solid #e3000f;border-radius:50%;box-sizing:border-box;vertical-align:-16px;margin:0 0 0 4px;overflow:hidden}}
    .noicon::after{{content:"";position:absolute;left:-8px;top:22px;width:70px;height:6px;background:#e3000f;transform:rotate(-45deg)}}
    .nol{{position:absolute;left:0;top:0;width:50px;height:50px;line-height:52px;text-align:center;font-family:AGBoldCnA;font-size:46px;color:{ink}}}
    .stat{{display:flex;align-items:center;padding-left:{t.get("stat_pl", 16)}px;padding-bottom:6px;box-sizing:border-box}}
    .stat .lab{{font-family:AGBoldCnA;font-size:55px;color:{t.get("stats_ink", ink)};letter-spacing:1.4px;-webkit-text-stroke:1.1px {t.get("stats_ink", ink)}}}
    .stat .val{{white-space:nowrap;font-family:AGMedExt;font-size:63px;color:{t.get("stats_ink", ink)};margin-left:30px;-webkit-text-stroke:1.1px {t.get("stats_ink", ink)};display:inline-block;transform:scaleX(1.15);transform-origin:left center}}
    .stat .val.r{{margin-left:auto;padding-left:30px;margin-right:{t.get("stat_pl", 16) + 26}px;transform-origin:right center}}
    .ctype{{font-family:AGBoldCnA;font-size:{t.get("ctype_size", 60)}px;color:{t.get("ctype_ink", ink)};letter-spacing:{t.get("ctype_spacing", 11)}px;text-align:center;line-height:{t.get("ctype_size", 60) + 1}px;white-space:nowrap{(";-webkit-text-stroke:" + str(t["ctype_stroke"]) + "px " + t.get("ctype_ink", ink)) if t.get("ctype_stroke") else ""}}}
    .deploy{{font-family:HoloTitle;font-size:70px;color:#000;display:flex;align-items:center;justify-content:center;padding-top:14px;box-sizing:border-box}}
    .forfeit{{font-family:HoloTitle;font-size:70px;color:#fff;display:flex;align-items:center;justify-content:center;padding-top:14px;box-sizing:border-box}}
    .cap{{font-family:AGBoldCnA;font-size:48px;color:#fff;line-height:52px;white-space:nowrap}}
    .wb .cap, .wb .num, .wb .label{{color:#000}}   /* white border: text printed in the border turns black */
    .cap .dot{{font-size:40px}}
    .cap.capgrow{{font-family:PCCap}}
    .cap.capgrow .dot{{font-family:HoloTitle;font-size:1.003em}}
    .num.capgrow{{font-family:PCNum;font-weight:normal}}
    .dot{{font-family:HoloTitle}}
    .num{{font-family:AGMedExt;font-weight:bold;font-size:44px;color:#fff;line-height:52px;text-align:right;transform:skewX(-14deg)}}
    .ltitle, .dtitle{{font-family:AGBoldCnA;font-size:57px;letter-spacing:2px;text-transform:uppercase}}
    .ltext.pre span, .dtext.pre span{{white-space:pre}}
    .ltitle .dot, .dtitle .dot{{font-family:"DejaVu Sans",sans-serif;color:#d4141c;font-size:0.8em;margin-right:6px;vertical-align:0.05em}}
    .ltitle .dot.plain, .dtitle .dot.plain{{color:inherit}}
    {f".ltitle .dot:not(.plain), .dtitle .dot:not(.plain){{color:{bullet_colour(card)}}}" if bullet_colour(card) else ""}
    {".ltitle .dot, .dtitle .dot{font-size:0.88em;margin-right:-7px}" if card.get("decipher_print") else ""}
    .ltitle span.lt, .dtitle span.lt{{display:inline-block;white-space:nowrap;transform-origin:center center}}
    {".ltitle, .dtitle{letter-spacing:1.4px} .ltitle span.lt{-webkit-text-stroke:1px #000}" if card.get("decipher_print") and (t.get("landscape") or t.get("system")) else ""}
    .ltitle{{color:#000;display:flex;align-items:center;justify-content:center;padding-top:6px;box-sizing:border-box}}
    .dtitle{{color:#fff;display:flex;align-items:center;justify-content:center;padding-top:6px;box-sizing:border-box;transform:rotate(180deg)}}
    .ltext{{font-family:AGCn;font-size:56px;color:#000;letter-spacing:1.5px;line-height:58px;display:flex;align-items:center;justify-content:center;text-align:center;box-sizing:border-box;padding:0 20px}}
    .dtext{{font-family:AGCn;font-size:56px;color:#fff;letter-spacing:1.5px;line-height:58px;display:flex;align-items:center;justify-content:center;text-align:center;box-sizing:border-box;padding:0 20px;transform:rotate(180deg)}}
    .parsec{{font-family:AGMedExt;font-size:72px;color:#fff;display:flex;align-items:center;justify-content:center;padding-top:4px;box-sizing:border-box}}
    .copy{{display:flex;align-items:center;justify-content:center}}
    .credit{{font-family:AGCn;font-style:italic;font-size:40px;color:#000;white-space:nowrap;transform:rotate(-90deg)}}
    .copyin{{font-family:AGBoldCnA;font-size:{t.get("copy_size", 24)}px;color:{ink};letter-spacing:{t.get("copy_ls", 1)}px;white-space:nowrap;transform:rotate(-90deg)}}
    .copyin.dccopy{{white-space:pre;font-size:{DC_COPY["size"]}px;letter-spacing:{DC_COPY["ls"]}px;word-spacing:{DC_COPY["ws"]}px;transform:rotate(-90deg) scaleX({DC_COPY["cond"]})}}
    .dccopy .cr{{display:inline-block;box-sizing:border-box;width:{DC_COPY["ring"]}px;height:{DC_COPY["ring"]}px;border:{DC_COPY["ring_w"]}px solid currentColor;border-radius:50%;font-size:{DC_COPY["ring_letter"]}px;line-height:{DC_COPY["ring"] - 2 * DC_COPY["ring_w"]}px;text-align:center;vertical-align:{DC_COPY["ring_va"]}px;overflow:hidden;letter-spacing:0;margin:0 {DC_COPY["ring_m"]}px}}
    .dccopy .dctat{{font-size:{DC_COPY_TAT["size"]}px;letter-spacing:{DC_COPY_TAT["ls"]}px}}
    .dccopy .dctat .cr{{width:{DC_COPY_TAT["ring_w"]}px;height:{DC_COPY_TAT["ring_h"]}px;border-width:{DC_COPY_TAT["ring_b"]}px;font-size:{DC_COPY_TAT["ring_letter"]}px;line-height:{DC_COPY_TAT["ring_h"] - 2 * DC_COPY_TAT["ring_b"]}px;vertical-align:{DC_COPY_TAT["ring_va"]}px}}
    """
    if card.get("lang") == "ja":
        import lang_ja
        css += lang_ja.css(card, t)
    fit_js = """
    document.fonts.ready.then(()=>{
      for (const el of document.querySelectorAll('.ctype')) {   // a long banner (HEAVILY-MODIFIED LIGHT FREIGHTER): tighten, then condense as the slip does
        const sp = el.querySelector('.ct'); if (!sp) continue;
        sp.style.display = 'inline-block';
        let ls = parseFloat(getComputedStyle(el).letterSpacing) || 0;
        while (sp.offsetWidth > el.clientWidth - 24 && ls > 0) { ls -= 0.5; el.style.letterSpacing = ls + 'px'; }
        if (sp.offsetWidth > el.clientWidth - 24) { sp.style.transform = 'scaleX(' + ((el.clientWidth - 24) / sp.offsetWidth) + ')'; }
      }
      // Text fit (Bill 2026-11-01): the largest size that fits, the way Decipher and the PC squeeze long text in.
      // Start at the box's standard size (the printed one: Obi-Wan's Journal's 62 px / 64 px lines); at each size
      // first tighten the tracking (to ls_min), then the leading (to lh_min x size), and only then try a smaller size.
      // Once a size fits, give back as much tracking as it can spare. Limits per box: data-fit-* (card "text_fit").
      const overflows = (el) => el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1;
      for (const h of document.querySelectorAll('.dct.objhead > i:first-child')) {
        // rev 84 (5): Decipher's Objective heading is set in a narrower italic: printed width 0.87 of our oblique Holotable
        // Text (15 heading lines on 13 Objective fronts; body lines 0.99), so the heading is a block laid out at width / 0.87
        // and drawn at 0.87. A heading still a little too long for one line (12_89: 1.01 of the measure at that width) is
        // condensed onto it; longer ones wrap (14_113 from 1.21), as printed (24 fronts)
        const K = 0.87, W = h.parentElement.clientWidth;
        const nx = h.nextSibling; if (nx && nx.nodeName === 'BR') nx.remove();
        h.style.display = 'block'; h.style.transformOrigin = 'left top';
        h.style.width = 'max-content'; const w = h.offsetWidth * K;
        if (w > W && w <= 1.1 * W) { h.style.width = (W / (W / w * K)) + 'px'; h.style.transform = 'scaleX(' + (W / w * K) + ')'; h.style.whiteSpace = 'nowrap'; }
        else { h.style.width = (W / K) + 'px'; h.style.transform = 'scaleX(' + K + ')'; }
        const wr = document.createElement('div'); wr.style.overflow = 'hidden'; wr.style.width = W + 'px';   // the wider layout box never counts as overflow
        h.parentNode.insertBefore(wr, h); wr.appendChild(h);
      }
      for (const el of document.querySelectorAll('.fit')) {
        const cs = getComputedStyle(el);
        let size = parseFloat(cs.fontSize), lh = parseFloat(cs.lineHeight);
        if (el.classList.contains('grow')) {   // Objectives: the slip's lines fill the box width — grow until a line would overflow
          while (el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1 && size < 63) {   // the slips set Objectives in 62 px
            size += 1; lh += 1; el.style.fontSize = size + 'px'; el.style.lineHeight = lh + 'px';
          }
        }
        const d = el.dataset, lhRatio = lh / size;
        const ls0 = parseFloat(cs.letterSpacing) || 0;
        const adj = parseFloat(d.fitAdj || 0);   // manual size adjust (+/- px, card maker "text_adjust" / "lore_adjust")
        const maxS = Math.max(size, parseFloat(d.fitMax || size)) + adj, minS = Math.min(parseFloat(d.fitMin || 20), maxS);
        const lsMin = parseFloat(d.lsMin ?? -1.2), lhMin = parseFloat(d.lhMin ?? 0.91), step = 0.1;
        const set = (s, l, t) => { el.style.fontSize = s + 'px'; el.style.lineHeight = l + 'px'; el.style.letterSpacing = t.toFixed(2) + 'px'; };
        let done = false;
        const stepS = parseFloat(d.fitStep || 1);
        for (let s = maxS; s >= minS - 1e-6 && !done; s -= stepS) {
          let l = d.fitStep ? s * lhRatio : Math.round(s * lhRatio), t = ls0;
          set(s, l, t);
          if (!overflows(el)) { done = true; break; }
          while (overflows(el) && t > lsMin + 1e-6) { t = Math.max(lsMin, t - step); set(s, l, t); }
          while (overflows(el) && l - 1 >= s * lhRatio * lhMin) { l -= 1; set(s, l, t); }   // lh_min: share of the box's own line pitch
          if (!overflows(el)) {
            const l0 = d.fitStep ? s * lhRatio : Math.round(s * lhRatio);   // give back leading first (the printed cards keep their line pitch), then tracking
            while (l < l0) { set(s, l + 1, t); if (overflows(el)) { set(s, l, t); break; } l += 1; }
            while (t < ls0 - 1e-6) { set(s, l, t + step); if (overflows(el)) { set(s, l, t); break; } t += step; }
            done = true;
          }
        }
        if (!done) set(minS, Math.round(minS * lhRatio * lhMin), lsMin);
        const fc = getComputedStyle(el); el.dataset.fit = [fc.fontSize, fc.lineHeight, fc.letterSpacing].join(' ');
      }
      let creditFs = 46;   // rotated credits: unrotated width = run length; both share one size, as the slips print them
      for (const el of document.querySelectorAll('.fitcredit')) {
        let fs = 46; const avail = parseFloat(el.dataset.avail);
        if (el.dataset.lines == '2') {   // the slip prints both credit lines side by side in one margin (Mon Mothma (V))
          fs = parseFloat(el.dataset.fs || 42); el.style.fontSize = fs + 'px'; el.style.lineHeight = '0.92'; el.style.flexShrink = '0'; el.style.textAlign = 'center';
          while (el.offsetWidth > avail && fs > 20) { fs -= 1; el.style.fontSize = fs + 'px'; }
          el.dataset.solo = '1'; continue;
        }
        while (el.offsetWidth > avail && fs > 20) { fs -= 1; el.style.fontSize = fs + 'px'; }
        if (fs < 34) {   // too small on one line: two lines, as The Emperor (V) slip prints "Original concept / by Mike Gemme"
          el.style.whiteSpace = 'normal'; el.style.flexShrink = '0'; el.style.textWrap = 'balance'; el.style.width = avail + 'px'; el.style.textAlign = 'center';
          fs = 34; el.style.fontSize = fs + 'px'; el.style.lineHeight = '1.0';
          while (el.offsetHeight > 2.05 * fs && fs > 20) { fs -= 1; el.style.fontSize = fs + 'px'; }
        }
        creditFs = Math.min(creditFs, fs);
      }
      const cr = [...document.querySelectorAll('.fitcredit')].filter(e => !e.dataset.solo);
      if (cr.length == 2 && cr[0].dataset.avail == cr[1].dataset.avail) for (const el of cr) el.style.fontSize = creditFs + 'px';
      for (const el of document.querySelectorAll('.ltitle .lt, .dtitle .lt')) {   // location bar titles: condense to the bar
        const avail = el.parentElement.clientWidth - 30, w = el.offsetWidth;
        if (w > avail) el.style.transform = 'scaleX(' + (avail / w).toFixed(3) + ')';
      }
      {   // margin caption + number (Bill 2026-11-02): the PC slip's faces, sizes and baseline (data-capfs / data-numfs /
          // data-base, see the caption section). A caption that would run into the number shrinks on the same baseline,
          // and a size that would leave the strip (data-top..data-bottom) is reduced so the text never touches its edges.
        const num = document.querySelector('.num.capgrow'), cap = document.querySelector('.cap.capgrow');
        const ref = cap || num;
        if (ref) {
          const ctx = document.createElement('canvas').getContext('2d');
          const met = (sp, txt) => { const cs = getComputedStyle(sp); ctx.font = `${cs.fontStyle} ${cs.fontWeight} 100px ${cs.fontFamily}`; return ctx.measureText(txt); };
          const top = +ref.dataset.top, bottom = +ref.dataset.bottom;
          let base = +ref.dataset.base;
          if (cap) {   // a frame that ends low: lift the baseline (not shrink the type) to keep 3 px above the card edge
            const csp = cap.querySelector('.capt'); csp.style.fontSize = cap.dataset.capfs + 'px';
            const dd = met(csp, 'gjpqy(),').actualBoundingBoxDescent / 100 * +cap.dataset.capfs;
            base = Math.min(base, bottom - 6 - dd);
          }
          const place = (el, fs) => {
            const sp = el.querySelector('.capt'); sp.style.whiteSpace = 'nowrap'; sp.style.lineHeight = 'normal'; sp.style.fontSize = fs + 'px';
            sp.style.top = (base - met(sp, 'H').fontBoundingBoxAscent / 100 * fs) + 'px'; el.dataset.fit = fs.toFixed(1) + 'px';
          };
          const fitV = (sp, fs, up, down) => {   // keep 3 px (master 6) of black above the ink and below the descenders
            const a = met(sp, up).actualBoundingBoxAscent / 100, d = met(sp, down).actualBoundingBoxDescent / 100;
            // a card placed from its own PC slip (caption_drop) keeps the slip's size: the PC leaves only ~2 px there
            return Math.min(fs, (base - top - (+sp.parentElement.dataset.gap || 6)) / a, d > 0 ? (bottom - 6 - base) / d : fs);
          };
          if (num) { const b0 = base; base = Math.min(+num.dataset.nbase, +num.dataset.bottom - 6 - met(num.querySelector('.capt'), '0123456789').actualBoundingBoxDescent / 100 * +num.dataset.numfs);
                     place(num, fitV(num.querySelector('.capt'), +num.dataset.numfs, '0123456789', '0123456789')); base = b0; }
          if (cap) {
            const sp = cap.querySelector('.capt'), sx = +cap.dataset.capsx || 1;
            sp.style.transformOrigin = 'left top'; sp.style.transform = `scaleX(${sx})`;
            for (const d of sp.querySelectorAll('.dot')) { d.style.display = 'inline-block'; d.style.transform = `scaleX(${(1 / sx).toFixed(4)})`; }
            let fs = fitV(sp, +cap.dataset.capfs, 'HIdlk()[]', 'gjpqy(),');
            place(cap, fs);
            const lim = num ? num.querySelector('.capt').getBoundingClientRect().left - 40 : cap.getBoundingClientRect().right;
            while (fs > 30 && sp.getBoundingClientRect().right > lim) { fs -= 0.5; place(cap, fs); }
          }
        }
      }
      for (const el of document.querySelectorAll('.title')) {   // a title longer than its bar is condensed, as Decipher did
        const w = el.scrollWidth; let avail = el.clientWidth;
        if (el.dataset.dfit && w > avail + 1) {   // Rev 84: Decipher printings set a long title smaller instead (baseline kept)
          const [R, A] = el.dataset.dfit.split(' ').map(Number), x0 = el.offsetLeft;
          const k = Math.min(1, (R - x0 + A) / (w + A)), cs = getComputedStyle(el);
          const mk = document.createElement('span'); mk.style.cssText = 'display:inline-block;width:0;height:0'; el.appendChild(mk);
          const b0 = mk.offsetTop;
          el.style.fontSize = (parseFloat(cs.fontSize) * k) + 'px'; el.style.letterSpacing = (parseFloat(cs.letterSpacing || 0) * k) + 'px';
          const b1 = mk.offsetTop; mk.remove();
          el.style.width = 'max-content'; const nw = el.offsetWidth;
          el.style.top = (el.offsetTop + b0 - b1) + 'px'; el.style.left = (R - nw) + 'px';
          continue;
        }
        if (w > avail + 1 && el.dataset.ll) {   // the PC first moves a long title left, to the bar's start (#62)
          const right = el.offsetLeft + avail; el.style.left = el.dataset.ll + 'px'; avail = right - (+el.dataset.ll); el.style.width = avail + 'px';
        }
        if (w > avail + 1) { el.style.transformOrigin = 'left center'; el.style.transform = 'scaleX(' + (avail / w).toFixed(3) + ')'; el.style.width = w + 'px'; }
      }
      for (const st of document.querySelectorAll('.stat')) {   // label + gap + value too wide for the box: condense the label (Bill: Green Squadron 1 (V))
        const lab = st.querySelector('.lab'), val = st.querySelector('.val');
        if (!lab || !val || lab.classList.contains('fitlab')) continue;
        const cs = getComputedStyle(st), inner = st.clientWidth - parseFloat(cs.paddingLeft);
        const vp = parseFloat(getComputedStyle(val).paddingLeft) || 0; let need = lab.offsetWidth + (val.offsetWidth - vp) * 1.15 + vp + (parseFloat(getComputedStyle(val).marginRight) || 0);
        if (val.classList.contains('r')) {   // narrow (character) boxes: the value closes up to the label and the box end first
          const mr = parseFloat(getComputedStyle(val).marginRight) || 0, w0 = lab.offsetWidth * 1.1 + (val.offsetWidth - vp) * 1.15;
          const slack = inner - w0 - vp - mr;
          const gmin = +(st.dataset.gmin || 28), mmin = +(st.dataset.mmin || 18);
          if (slack < 0) { const cut = Math.min(-slack, (vp - gmin) + (mr - mmin)); const a = Math.min(vp - gmin, cut / 2 + Math.max(0, cut / 2 - (mr - mmin)));
            val.style.paddingLeft = (vp - a) + 'px'; val.style.marginRight = (mr - (cut - a)) + 'px'; }
        }
        { const vp2 = parseFloat(getComputedStyle(val).paddingLeft) || 0;
          need = lab.offsetWidth + (val.offsetWidth - vp2) * 1.15 + vp2 + (parseFloat(getComputedStyle(val).marginRight) || 0); }
        // Decipher's stat caps are wider than AG Bold Condensed: widen the label ×1.1 (Bill: Lord Vader (V)), less if the box is tight
        const k = Math.max(0.8, Math.min(1.1, (inner - (need - lab.offsetWidth)) / lab.offsetWidth));
        { lab.style.display = 'inline-block'; lab.style.transformOrigin = 'left center'; lab.style.transform = 'scaleX(' + k.toFixed(3) + ')'; lab.style.marginRight = (-(1 - k) * lab.offsetWidth) + 'px'; }
      }
      for (const st of document.querySelectorAll('.stat')) {   // a value still too wide for its box (3333): condense it, then shrink it
        const val = st.querySelector('.val'); if (!val) continue;
        const sr = st.getBoundingClientRect(), vr = val.getBoundingClientRect();
        const over = vr.right - (sr.right - 8);
        if (over > 0) {
          const k = Math.max(0.5, (vr.width - over) / vr.width) * 1.15;
          val.style.transform = 'scaleX(' + k.toFixed(3) + ')';
          const vr2 = val.getBoundingClientRect(); const over2 = vr2.right - (sr.right - 8);
          if (over2 > 0) val.style.fontSize = Math.max(28, 63 * (vr2.width - over2) / vr2.width).toFixed(1) + 'px';
        }
      }
      for (const el of document.querySelectorAll('.fitnum')) {   // destiny / deploy / forfeit: condense to the box (≥55 %), then shrink
        el.style.display = 'inline-block'; el.style.whiteSpace = 'nowrap'; el.style.transformOrigin = 'center center';
        const avail = parseFloat(el.dataset.avail), w = el.getBoundingClientRect().width;
        if (w > avail) {
          const k = Math.max(0.55, avail / w); el.style.transform = 'scaleX(' + k.toFixed(3) + ')';
          if (w * k > avail) { const fs = parseFloat(getComputedStyle(el).fontSize); el.style.fontSize = (fs * avail / (w * k)).toFixed(1) + 'px'; }
        }
      }
      for (const el of document.querySelectorAll('.fitlab')) {   // label-only stat: squeeze to the well, keep the height
        const avail = parseFloat(el.dataset.avail), w = el.getBoundingClientRect().width;
        if (w > avail) el.style.transform = 'scaleX(' + (avail / w).toFixed(3) + ')';
      }
      for (const el of document.querySelectorAll('.jatitle[data-avail]')) {   // rev 80 Japanese title: Takara's 長体, condensed more to stay within the bar
        const w = el.scrollWidth, k = Math.min(parseFloat(el.dataset.sx), parseFloat(el.dataset.avail) / w);
        el.style.transformOrigin = 'left center'; el.style.transform = 'scaleX(' + k.toFixed(4) + ')'; el.style.width = w + 'px';
      }
      { // card maker layers: per-piece offset / scale / hide (applied after all fitting), then report each piece's box
        const LAYOUT = __LAYOUT__, boxes = {};
        const union = (el) => { let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
          for (const c of el.querySelectorAll('*')) { const r = c.getBoundingClientRect(); if (r.width < 1 || r.height < 1) continue;
            x0 = Math.min(x0, r.left); y0 = Math.min(y0, r.top); x1 = Math.max(x1, r.right); y1 = Math.max(y1, r.bottom); }
          return x1 > x0 ? [x0, y0, x1 - x0, y1 - y0] : null; };
        const card = document.getElementById('card').getBoundingClientRect();
        for (const el of document.querySelectorAll('.piece')) {
          const L = LAYOUT[el.dataset.piece]; if (!L) continue;
          const u = union(el); if (u) el.style.transformOrigin = (u[0] - card.left + u[2] / 2) + 'px ' + (u[1] - card.top + u[3] / 2) + 'px';
          el.style.translate = (L.dx || 0) + 'px ' + (L.dy || 0) + 'px';
          el.style.scale = (L.sx || 1) + ' ' + (L.sy || 1);
          if (L.hidden) el.style.visibility = 'hidden';
        }
        for (const el of document.querySelectorAll('.piece')) {
          const u = union(el); if (!u) continue; const n = el.dataset.piece, b = [u[0] - card.left, u[1] - card.top, u[2], u[3]];
          if (boxes[n]) { const a = boxes[n]; const x0 = Math.min(a[0], b[0]), y0 = Math.min(a[1], b[1]);
            boxes[n] = [x0, y0, Math.max(a[0] + a[2], b[0] + b[2]) - x0, Math.max(a[1] + a[3], b[1] + b[3]) - y0]; } else boxes[n] = b;
        }
        document.body.dataset.boxes = JSON.stringify(boxes);
      }
      document.body.dataset.ready = '1';
    });
    """
    lay = {re.sub(r"[^a-z_]", "", str(k)): {kk: (bool(v.get(kk)) if kk == "hidden" else max(-2000.0, min(2000.0, float(v.get(kk))))
                                               if kk in ("dx", "dy") else max(0.2, min(4.0, float(v.get(kk)))))
                                          for kk in ("dx", "dy", "sx", "sy", "hidden") if v.get(kk) is not None}
           for k, v in (card.get("layout") or {}).items() if isinstance(v, dict)}
    fit_js = fit_js.replace("__LAYOUT__", json.dumps(lay))
    if t.get("landscape") and card.get("decipher_print") and t.get("dc_title_cx"):
        # rev 84 (sites 2): Decipher centres a site's title on the card's centre line (x 1110) in both bars, whatever the
        # icon boxes leave free, and only moves it off centre to clear the boxes / the Force slot (printed centres at 745:
        # 518-521 on Home One: War Room / Docking Bay, Executor: Comm Station, Cloud City: Lower Corridor, Death Star:
        # Central Core, Hoth: Echo Docking Bay, Sandcrawler: Loading Bay / Droid Junkheap; ours were centred in the bar
        # between the slot and the boxes, 4-20 px left with three boxes)
        fit_js = fit_js.replace("      document.body.dataset.ready = '1';", """      document.querySelectorAll('.ltitle, .dtitle').forEach(function (d) {
        const sp = d.querySelector('span.lt'); if (!sp) return;
        const dr = d.getBoundingClientRect(), r = sp.getBoundingClientRect(), pad = 8;
        const rot = d.classList.contains('dtitle') ? -1 : 1;   // the Dark bar is turned: a visual move right is left inside it
        let sh = %d - (r.left + r.right) / 2;
        sh = Math.max(dr.left + pad - r.left, Math.min(dr.right - pad - r.right, sh));
        sp.style.position = 'relative'; sp.style.left = (rot * sh) + 'px';
      });
      document.body.dataset.ready = '1';""" % t["dc_title_cx"], 1)
    if t.get("ctype_after_title"):   # rev 84: the PC's wide starships set the banner a fixed gap after the title's end
        fit_js = fit_js.replace("      document.body.dataset.ready = '1';", """      { const ti = document.querySelector('.title'), ct = document.querySelector('.ctype');
        if (ti && ct) { const r = document.createRange(); r.selectNodeContents(ti); const tr = r.getBoundingClientRect().right;
          const sp = ct.querySelector('.ct'); const sl = (sp || ct).getBoundingClientRect().left;
          ct.style.left = (ct.offsetLeft + tr + %d - sl) + 'px'; } }
      document.body.dataset.ready = '1';""" % t["ctype_after_title"], 1)
    if t.get("ctype_centre_to"):   # rev 84: the wide capital's banner is centred between the title's end and the destiny
        fit_js = fit_js.replace("      document.body.dataset.ready = '1';", """      { const ti = document.querySelector('.title'), ct = document.querySelector('.ctype');
        if (ti && ct) { const r = document.createRange(); r.selectNodeContents(ti); const tr = r.getBoundingClientRect().right;
          const sp = ct.querySelector('.ct'); const w = sp ? sp.getBoundingClientRect().width : ct.clientWidth;
          const c = (tr + %d) / 2; ct.style.left = Math.max(tr + 12, c - ct.clientWidth / 2) + 'px'; } }
      document.body.dataset.ready = '1';""" % t["ctype_centre_to"], 1)
    return f"<!doctype html><html><head><meta charset='utf-8'><style>{css}</style></head><body>{''.join(parts)}<script>{fit_js}</script></body></html>"


def rounded(img: Image.Image, radius: int) -> Image.Image:
    """Rounded corners (real cards and GEMP's images): transparent outside a rounded rectangle."""
    from PIL import ImageDraw
    m = Image.new("L", img.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, img.width - 1, img.height - 1), radius=radius, fill=255)
    out = img.convert("RGBA")
    out.putalpha(m)
    return out


def screenshot_card(card: dict, page) -> Image.Image:
    """Render one card with an open Playwright page: the 600 DPI master (1632x2220 / 2220x1632), Dark locations turned
    to the Dark Side's seat, rounded corners. Shared by render() and the card maker web service."""
    import io
    html = build_html(card)
    page.set_content(html, wait_until="load")
    page.wait_for_function("document.body.dataset.ready==='1'")
    im = Image.open(io.BytesIO(page.locator("#card").screenshot())).convert("RGBA")
    try:
        card["_boxes"] = json.loads(page.evaluate("document.body.dataset.boxes || '{}'"))
    except Exception:   # noqa: BLE001
        card["_boxes"] = {}
    if card.get("side") == "Dark" and card["template"] == "loc-site":   # portrait systems are already built Dark-half-down
        # Dark locations are shown from the Dark Side's seat, as Decipher prints them (Executor: Comm Station): the
        # whole card turned 180° (Dark half, its icons and credits at the bottom); the caption strip stays upright
        # in the bottom margin (Bill 2026-10-14).
        card["_boxes"] = {k: [im.width - b[0] - b[2], im.height - b[1] - b[3], b[2], b[3]] for k, b in card.get("_boxes", {}).items()}
        rot = im.rotate(180)
        rot.paste(im.crop((0, 0, im.width, 144)), (0, 0))
        rot.paste(im.crop((0, im.height - 145, im.width, im.height)), (0, im.height - 145))
        ax, ay, aw, ah = card.get("_art_box") or TEMPLATES[card["template"]]["art"]   # the picture itself stays upright
        DL, DD = loc_grow(card) if card["template"] == "loc-site" and card.get("lang") != "ja" else (0, 0)
        y0, y1 = ay + DD, ay + ah - DL
        box = (im.width - 1 - (ax + aw - 1), im.height - 1 - (y1 - 1), im.width - (ax), im.height - y0)
        rot.paste(rot.crop(box).rotate(180), box[:2])
        im = rot
    return rounded(im, 80)


def holotable_size(master: Image.Image, land: bool) -> Image.Image:
    """Holotable size: the whole master at half scale (816×1110), cropped to 745×1039 so the card area lands at
    (37,36) like the PC's images, keeping the bottom caption strip in the border."""
    if land:
        im = master.convert("RGB").resize((1110, 816), Image.LANCZOS)
        return rounded(im.crop((36, 35, 1075, 780)), 34)
    im = master.convert("RGB").resize((816, 1110), Image.LANCZOS)
    return rounded(im.crop((35, 36, 780, 1075)), 34)


def render(card: dict) -> tuple[Path, Path]:
    from playwright.sync_api import sync_playwright
    OUT.mkdir(exist_ok=True)
    land = is_wide(TEMPLATES[card["template"]])
    (OUT / f"{card['id']}.html").write_text(build_html(card), encoding="utf-8")
    master = OUT / f"{card['id']}_{'2220' if land else '1632'}.png"
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": W, "height": H}, device_scale_factor=1)
        im = screenshot_card(card, pg)
        b.close()
    im.save(master)
    htp = OUT / f"{card['id']}_{'1039' if land else '745'}.png"
    holotable_size(im, land).save(htp, optimize=True)
    return master, htp


if __name__ == "__main__":
    for f in sys.argv[1:]:
        card = json.loads(Path(f).read_text(encoding="utf-8"))
        m, h = render(card)
        print(card["id"], m.stat().st_size // 1024, "KB", h.stat().st_size // 1024, "KB")
