(function () {
    'use strict';
    const data = window.SharedSearchPilotData;
    const engine = window.SharedSearchQuery;
    const labels = {any: 'Any uniqueness', unique: 'Unique (•)', unrestricted: 'Unrestricted', 'restricted-2': 'Restricted (••)', 'restricted-3': 'Restricted (•••)', 'restricted-6': 'Restricted (6 dots)', 'diamond-1': 'Diamond (◇)', 'diamond-2': 'Diamond (◇◇)', 'diamond-3': 'Diamond (◇◇◇)', unknown: 'Unknown'};
    function element(tag, text, attrs) {
        const node = document.createElement(tag);
        if (text !== null && text !== undefined) node.textContent = text;
        Object.entries(attrs || {}).forEach(([key, value]) => node.setAttribute(key, value));
        return node;
    }
    function link(text, href) { return element('a', text, {href: href}); }
    function select(id, options) {
        const node = element('select', null, {id: id});
        options.forEach(([value, text]) => node.append(element('option', text, {value: value})));
        return node;
    }
    function start() {
        document.querySelectorAll('[data-swccg-search-pilot]').forEach(mount);
    }
    function mount(root) {
        if (root.dataset.loaded) return;
        root.dataset.loaded = '1';
        const context = root.dataset.swccgSearchPilot;
        if (!['wiki', 'gemp', 'scomp'].includes(context)) return;
        root.replaceChildren();
        root.classList.add('ssp'); root.dataset.context = context;
        const prefix = 'ssp-' + context + '-';
        const heading = {wiki: 'Explore cards and published decklists', gemp: 'Card and public-deck search pilot', scomp: 'SCOMPLINK search pilot'}[context];
        root.append(element('h1', heading));
        root.append(element('p', data.coverage, {class: 'ssp-note', id: prefix + 'coverage'}));
        const navigation = element('nav', null, {class: 'ssp-links', 'aria-label': 'Search interfaces'});
        root.append(navigation);
        const form = element('form', null, {'aria-describedby': prefix + 'coverage'});
        const grid = element('div', null, {class: 'ssp-grid'});
        const controls = {};
        function field(key, title, node) {
            const label = element('label', title, {for: prefix + key}); node.id = prefix + key; controls[key] = node; label.append(node); grid.append(label);
        }
        field('mode', 'Find', select('', [['cards', 'Cards'], ['decks', 'Published decklists']]));
        field('text', 'Title or text', element('input', null, {type: 'search', maxlength: '200', placeholder: 'Try JP, Ghhhk, or a name'}));
        const symbol = element('input', null, {type: 'text', list: prefix + 'symbols', placeholder: 'Any, JP, Hoth…'});
        const suggestions = element('datalist', null, {id: prefix + 'symbols'});
        data.symbols.forEach(s => suggestions.append(element('option', s.aliases.join(', '), {value: s.label})));
        field('symbol', 'Set symbol', symbol); grid.append(suggestions);
        field('role', 'Symbol meaning', select('', [['printed', 'Printed on this card'], ['referenced', 'Referenced in game text']]));
        field('uniqueness', 'Printed uniqueness', select('', Object.entries(labels)));
        field('contains', 'Decklists containing', select('', [['', 'Any card in the four lists']].concat(data.cards.slice().sort((a,b) => a.title.localeCompare(b.title)).map(c => [c.id, c.title]))));
        field('identity', 'Match the selected card by', select('', [['family', 'Any text version of this card'], ['recorded', 'Exact catalog text version in the import']]));
        field('zone', 'Count in', select('', [['main', 'Main deck only'], ['all', 'Main + recorded outside cards']]));
        field('display', 'Read card text as', select('', [['symbols', 'Symbols with accessible names'], ['readable', 'Written symbol names']]));
        form.append(grid);
        const buttons = element('div', null, {class: 'ssp-controls'});
        buttons.append(element('button', 'Search', {type: 'submit'}));
        const reset = element('button', 'Reset', {type: 'button'}); buttons.append(reset);
        const share = element('button', 'Copy search link', {type: 'button'}); buttons.append(share);
        form.append(buttons); root.append(form);
        const exampleRow = element('div', null, {class: 'ssp-controls ssp-example', 'aria-label': 'Example queries'});
        [
            ['Mentions JP', {mode:'cards',symbol:'jp',role:'referenced'}],
            ['Bears JP', {mode:'cards',symbol:'jp',role:'printed'}],
            ['Two dots', {mode:'cards',uniqueness:'restricted-2'}],
            ['Decks with Officer Evax', {mode:'decks',contains:data.cards.find(c=>c.title==='Officer Evax').id}]
        ].forEach(([text, query]) => {
            const button = element('button', text, {type:'button'});
            button.addEventListener('click', () => {setQuery(query); render(true);}); exampleRow.append(button);
        });
        root.append(exampleRow);
        root.append(element('p', context === 'gemp' ? 'This public snapshot does not alter your deck, collection or format. “Search title in builder” keeps the builder’s existing format and other filters.' : 'A card’s release product, printed set symbol and symbol references are separate fields.', {class:'ssp-readonly'}));
        root.append(element('p', 'Uniqueness marks are not deck copy limits. Unknown values never count as unrestricted. Exact import IDs do not identify physical foil/language copies.', {class:'ssp-readonly'}));
        const summary = element('p', '', {class:'ssp-summary',role:'status','aria-live':'polite'});
        const error = element('p', '', {class:'ssp-error',role:'alert',hidden:''});
        const results = element('div', null, {class:'ssp-results','aria-label':'Search results'});
        const copyArea = element('pre', '', {class:'ssp-copy',hidden:'',tabindex:'0','aria-label':'Copyable text'});
        root.append(summary,error,results,copyArea);
        const state = {last:null};
        function readQuery() {
            return Object.fromEntries(Object.entries(controls).filter(([key])=>key!=='display').map(([key,node])=>[key,node.value]));
        }
        function setQuery(query) {
            Object.entries(controls).forEach(([key,node]) => {node.value = query[key] || ({mode:'cards',role:'printed',uniqueness:'any',identity:'family',zone:'main',display:'symbols'}[key] || '');});
        }
        function queryUrl(base, query) {
            const url = new URL(base, location.href);
            ['mode','text','symbol','role','uniqueness','contains','identity','zone','display'].forEach(key=>url.searchParams.delete('sp_'+key));
            Object.entries(query).forEach(([key,value])=>{if(value)url.searchParams.set('sp_'+key,value);});
            return url.href;
        }
        function updateNavigation(query) {
            navigation.replaceChildren();
            Object.entries(data.interfaces).forEach(([kind,href])=>{if(kind==='gemp'&&context==='gemp')href=location.origin+location.pathname;navigation.append(link(kind==='wiki'?'Wiki sample':kind==='gemp'?'GEMP pilot':'SCOMPLINK pilot',queryUrl(href,query)));});
            if(context==='wiki') navigation.append(link('Search the whole Wiki','https://wiki.swccg.com/wiki/Special:Search?search='+encodeURIComponent(query.text||'')));
            if(context==='gemp') navigation.append(link('Deck builder','deckBuild.html'));
        }
        function syncControls() {
            const decks=controls.mode.value==='decks';
            ['symbol','role','uniqueness','display'].forEach(k=>{controls[k].disabled=decks;controls[k].closest('label').hidden=decks;});
            ['contains','identity','zone'].forEach(k=>{controls[k].disabled=!decks;controls[k].closest('label').hidden=!decks;});
            controls.text.placeholder=decks?'Player, event or deck title':'Try JP, Ghhhk, or a title';
        }
        function symbolNode(id) {
            const s=data.symbols.find(s=>s.id===id);
            if(!s)return element('span','[Unknown symbol]');
            if(controls.display.value==='readable'||!s.image)return element('span','['+s.label+(id==='none'?'':' icon')+']');
            const span=element('span',null,{class:'ssp-symbol',title:s.label+' icon'});
            span.append(element('img',null,{src:s.image,alt:s.label+' icon'})); return span;
        }
        function textWithSymbols(text) {
            const holder=element('p',null,{class:'ssp-text'});let at=0;
            for(const match of text.matchAll(/\[([^\]]+)\]/g)) {
                holder.append(document.createTextNode(text.slice(at,match.index)));
                let id;try{id=engine.symbolId(data,match[1]);}catch(_){id=null;}
                holder.append(id?symbolNode(id):document.createTextNode(match[0]));at=match.index+match[0].length;
            }
            holder.append(document.createTextNode(text.slice(at)));return holder;
        }
        function plainText(text) {
            return text.replace(/\[([^\]]+)\]/g,(whole,value)=>{try{const id=engine.symbolId(data,value);return '['+data.symbols.find(s=>s.id===id).label+' icon]';}catch(_){return whole;}});
        }
        async function copy(text) {
            copyArea.textContent=text;copyArea.hidden=false;
            try{await navigator.clipboard.writeText(text);copyArea.dataset.copied='true';}catch(_){copyArea.dataset.copied='false';}
        }
        function cardResult(card) {
            const article=element('article',null,{class:'ssp-result','data-result-id':card.id});
            const h=element('h2');h.append(link(card.title,card.wiki));article.append(h);
            const meta=element('div',null,{class:'ssp-meta'});
            [card.product,labels[card.uniqueness||'unknown']].forEach(text=>meta.append(element('span',text,{class:'ssp-chip'})));
            const mark=element('span');mark.append(document.createTextNode('Printed symbol: '),symbolNode(card.printedSymbol),document.createTextNode(' '+data.symbols.find(s=>s.id===card.printedSymbol).label));meta.append(mark);article.append(meta,textWithSymbols(card.text));
            const actions=element('div',null,{class:'ssp-actions'});
            const decks=element('button','Find published decks',{type:'button'});decks.addEventListener('click',()=>{setQuery({mode:'decks',contains:card.id});render(true);});actions.append(decks);
            const copyButton=element('button','Copy readable card text',{type:'button'});copyButton.addEventListener('click',()=>copy(card.title+'\n'+plainText(card.text)));actions.append(copyButton);
            actions.append(link('Check original face',card.sourceFace));
            if(context==='gemp'&&window.opener) {
                const send=element('button','Search title in builder',{type:'button'});
                send.addEventListener('click',()=>{window.opener.postMessage({type:'swccg-search-pilot-title',title:card.gameTitle},location.origin);window.opener.focus();});actions.append(send);
            }
            const details=element('details',null,{class:'ssp-details'});details.append(element('summary','Source and identity'),element('p','Card family '+card.familyId+' · Wiki revision '+card.sourceRevision));
            article.append(actions,details);return article;
        }
        function deckResult(deck) {
            const article=element('article',null,{class:'ssp-result','data-result-id':deck.id});const h=element('h2');h.append(link(deck.title,deck.wiki));article.append(h);
            article.append(element('p',deck.player+' · '+deck.event+' · '+deck.format));
            article.append(element('p',deck.mainCount+' main-deck cards + '+deck.outsideCount+' outside cards'+(deck.matchedCount===null?'':' · '+deck.matchedCount+' matching '+(controls.zone.value==='main'?'main-deck':'recorded')+' copies')));
            const actions=element('div',null,{class:'ssp-actions'});actions.append(link('Read published decklist',deck.wiki),link('Download original GEMP import',deck.download));article.append(actions);
            article.append(element('p','Published list and original XML quantities reconciled. Import IDs are preserved; this pilot does not recalculate historical legality.',{class:'ssp-details'}));return article;
        }
        function render(push) {
            syncControls();error.hidden=true;copyArea.hidden=true;results.replaceChildren();
            try {
                const raw=readQuery();if(raw.mode==='decks'){raw.symbol='';raw.uniqueness='any';}
                const result=engine.search(data,raw);state.last=result;window.SharedSearchPilot.last=result;
                summary.textContent=result.records.length+' '+(result.kind==='cards'?'card printings':'published decklists')+' found · '+data.snapshotId;
                result.records.forEach(record=>results.append(result.kind==='cards'?cardResult(record):deckResult(record)));
                if(!result.records.length)results.append(element('p','No matches in this pilot snapshot. Reset filters or follow the source/catalog links for broader coverage.'));
                const query=Object.assign({},result.query,{display:controls.display.value});updateNavigation(query);
                if(push)history.replaceState(null,'',queryUrl(location.href,query));
                root.dispatchEvent(new CustomEvent('shared-search:results',{detail:{snapshotId:result.snapshotId,ids:result.ids,query:result.query}}));
            } catch(e) {summary.textContent='Search needs attention';error.textContent=e.message;error.hidden=false;state.last=null;window.SharedSearchPilot.last=null;}
        }
        form.addEventListener('submit',event=>{event.preventDefault();render(true);});
        controls.mode.addEventListener('change',()=>{if(controls.mode.value==='decks'){controls.symbol.value='';controls.uniqueness.value='any';}render(true);});
        controls.display.addEventListener('change',()=>render(true));
        reset.addEventListener('click',()=>{setQuery({});render(true);});
        share.addEventListener('click',()=>copy(queryUrl(location.href,Object.assign({},readQuery(),{display:controls.display.value}))));
        window.SharedSearchPilot={data:data,search:query=>engine.search(data,query),last:null,root:root};
        const params=new URLSearchParams(location.search);const initial={};
        Object.keys(controls).forEach(key=>{if(params.has('sp_'+key))initial[key]=params.get('sp_'+key);});
        try {
            const checked=engine.canonicalQuery(data,initial);
            if(initial.display&&!['symbols','readable'].includes(initial.display))throw new Error('Unknown text display mode.');
            setQuery(Object.assign({},checked,{display:initial.display||'symbols'}));render(false);
        } catch(e) {
            setQuery({});syncControls();summary.textContent='Search needs attention';error.textContent=e.message;error.hidden=false;updateNavigation({});
        }
    }
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
}());
