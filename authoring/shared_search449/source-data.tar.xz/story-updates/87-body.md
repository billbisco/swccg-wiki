> Spec per [docs/SPEC-PROCESS.md](https://github.com/swccg-guild/work/blob/main/docs/SPEC-PROCESS.md). **Status: Backlog.** Filed by Alpha11 (for Alpha6) as a child of #42 from Bill's answer to #42 Q4 (2026-11-03, 1:30 PM UTC-4). It can't move to Ready until the open questions are answered. **No coding before Ready.**

Parent: #42 (LOTR GEMP porting inventory). Explainer: `/workspace/handoff/lotr-feature-explainer-20261103.md` on Grok Bot's computer; repo copy [evidence/42/lotr-feature-explainer.md](https://github.com/swccg-guild/work/blob/main/evidence/42/lotr-feature-explainer.md). This feature is a late find listed in [evidence/42/lotr-port-inventory.md](https://github.com/swccg-guild/work/blob/main/evidence/42/lotr-port-inventory.md), section 3 (item B).

### Bill's words (verbatim)

**Bill, 2026-11-03 11:40 AM UTC-4 (#42 Q1):**

> 1. The answer to your question is probably yes to all of those.  I'm not sure exactly what the diffrence in the new deck builder is, or the player list is, or prize admin pages.  I don' tknow what the share links are per se.  So probably yes to all, but I just want to be thoughtful on some of these is all. 

**Bill, 2026-11-03 1:30 PM UTC-4 (#42 Q4: the announcements pop-up and the Format Definitions page):**

> Yes.  Make tickets for those too

### User story

As a player, I want a searchable **Format Definitions** page in GEMP's Help, where I can pick a format or type a card name and see which formats ban, restrict or allow it, with card pictures I can zoom, so that I can check what's legal without reading a long page.

### What LOTR has (inventory section 3, item B)

- `js/gemp-022/formatDefinitions.js` (588 lines) + `css/gemp-001/formatDefinitions.css`, with `cardPreview.js`/`.css` for the zoomable card preview. The server sends every format as data (`GET /hall/formats/json`, from `HallRequestHandler.java` and `game/formats/FormatDefinitions.java`, with a test `FormatDefinitionsTest.java`).
- The page draws one entry per format (`id="format-<code>"`) with a sticky format list and a filter that finds formats **by name or by a card on their lists**. Card lists show as name chips grouped by set, or as lazily loaded thumbnails; clicking one opens the zoomable preview. `#format-<code>` deep links scroll to a format; LOTR's Play pop-up (i) button links there.
- **Ours:** Help → Format Definitions (`includes/help/formatRules.html`, 76 lines) loads server-built HTML from `GET /hall/formats/html` (`HallRequestHandler.getFormats`; one `GET /hall/format/<code>` too). It has no filter, no card search, no card pictures and no per-format deep links. (Correction to the inventory, which called ours "static": it is server-built, but not searchable.)

### Requirements

- R1 A JSON version of our format data (`GET /hall/formats/json`) from the same format library as `/formats/html` (`swccgFormats.json` and its loader), with each format's name, code, summary, legal sets, banned/restricted/limited cards (name, side, set, blueprint id) and rule notes.
- R2 Help → Format Definitions draws one entry per format from that data, with a format list beside it.
- R3 A filter finds formats by format name **or by card name** (shows which formats ban, restrict or allow that card).
- R4 Card lists show as name chips by set, with an option for card images; clicking a card opens our zoomable card preview (our existing card zoom, or LOTR's `cardPreview.js` adapted).
- R5 Deep links `#format-<code>` (and `#help/formats` for the page) open the page scrolled to that format; these are the targets for #83's format share links.
- R6 Light and Dark side cards are both shown correctly (side-correct images and names).
- R7 Ported code keeps its LOTR source noted (repo, path, commit 9b73339) per #42 R4.

### Acceptance criteria

- [ ] AC1 Given Test, when `GET /hall/formats/json` is fetched, then it returns every format that `/hall/formats/html` lists, with the R1 fields. Output attached, and a check that format counts match.
- [ ] AC2 Given Help → Format Definitions on Test, then every format appears with its summary and card lists. Screenshot, desktop and 390 px.
- [ ] AC3 Given a card name typed in the filter (for example a card banned in one format), then only formats whose lists include it are shown, with the card highlighted. Screenshot.
- [ ] AC4 Given a card chip or thumbnail, when clicked, then the zoomable preview opens with the side-correct image. Screenshot.
- [ ] AC5 Given a link `…#format-<code>` opened in a new tab, then the page opens scrolled to that format. Screenshot.
- [ ] AC6 Given the reviewer compares 5 formats' card lists on the new page with the old page, then they match. Comparison attached.
- [ ] AC7 GEMP gates pass (named tests incl. a JSON endpoint test + full suite, PR linked); deployed to Test and verified, then to Play and verified.

### Out of scope

- Changing what any format allows (data only shown, not edited).
- Share buttons (#83).

### Dependencies

- Related: #42 (parent), #83 (Share links: format share links point to this page's `#format-<code>` deep links), #86 (announcements pop-up, the other late find), #11 (game rule options separate from format; may add rule notes to show).

### Open questions

- Q1 (@Bill): Card names only, or card pictures too?
  - **Plain-language version (Alpha11, 2026-11-03):** Example: a banned list as text chips "Hidden Base (Premiere)" vs small card images. **Suggested default:** text chips by default, with a "Card images" switch, like LOTR.
- Q2 (@Bill): Should the old page stay available?
  - **Plain-language version (Alpha11, 2026-11-03):** Example: keep the current Format Definitions page as "Simple view" until the new one is trusted. **Suggested default:** replace it once AC6 passes; keep `/hall/formats/html` working on the server.
- Q3 (@Bill): What else should a format entry show?
  - **Plain-language version (Alpha11, 2026-11-03):** Example: legal sets, banned cards, restricted cards, special rules, and a link to the wiki's format page. **Suggested default:** all of those, with the wiki link where one exists.

### Plan

*Draft by Alpha11, 2026-11-03. Parts marked (depends on Qn) are final once Bill answers.*

- **Approach:**
  1. Map our format library (`swccgFormats.json` and its loader, `HallRequestHandler.getFormats` / `buildFormatHtml`) to LOTR's `FormatDefinitions` JSON shape; write the field list in `evidence/87/fields.md`.
  2. Server: add `GET /hall/formats/json` in our `HallRequestHandler`, built from the same data as the HTML (R1) (AC1); unit test.
  3. Client: port `formatDefinitions.js`/`.css` into `js/gemp-016/`, load it from `includes/help/formatRules.html`, adapted to SWCCG sides and our card images; card preview via our zoom (R2–R4, R6) (AC2–AC4; depends on Q1, Q3).
  4. Deep links `#format-<code>` in `hallLinks.js` (R5) (AC5); coordinate with #83.
  5. Compare 5 formats old vs new (AC6; depends on Q2); Test → Play (AC7).
- **Repos / files touched:** our GEMP repo: `src/gemp-swccg-async/.../handler/HallRequestHandler.java`, the format library in `src/gemp-swccg-server/` (`swccgFormats.json` loader), `src/main/web/includes/help/formatRules.html`, new `js/gemp-016/formatDefinitions.js` and CSS, `hallLinks.js`; tests; swccg-guild/work `evidence/87/`.
- **Breakdown (Tasks):** JSON endpoint; page + filter + preview; deep links (shared with #83).
- **Risks / needs-bill approvals:** wrong legality shown is worse than no page (AC6 guards it); LOTR repo has no licence file (#42 AC4), so Bill OKs the port.
- **Verification (one line per AC):**
  - AC1: curl output and count check.
  - AC2–AC5: Test screenshots.
  - AC6: comparison file.
  - AC7: test log, PR link, Test and Play checks.

### Design log

Not required.

### Area

GEMP


## 14 November2026 — accepted shared-search direction and bounded pilot

Bill approved the holistic assessment, instructed updating existing stories, creating gaps, and proceeding with a small live Wiki/GEMP/SCOMPLINK pilot covering symbols, uniqueness and decklists containing a card. He explicitly authorizes first-principles judgment, including contradicting earlier assumptions where useful. [Assessment](https://github.com/swccg-guild/work/blob/main/evidence/435/search-design/search-and-display.md).

**Guiding principles:** optimize trustworthy answers and the user's job; share identities and public card-filter meanings rather than forcing all screens, defaults, data ownership or private filters to match. Preserve catalog/publication/text-state identity, provenance and unknowns. Distinguish release product, printed symbol and a symbol referenced in game text. The same public query over the same snapshot/scope should match; genuinely different scopes should be explicit. Faithful symbols and searchable/copyable semantic text can coexist.

**Implementation split:** [449](https://github.com/swccg-guild/work/issues/449) owns the small cross-system live pilot; [450](https://github.com/swccg-guild/work/issues/450) owns connected Wiki discovery beyond cards; [451](https://github.com/swccg-guild/work/issues/451) owns GEMP Current deck/My decks scopes. Existing32 remains the full public card-filter rollout,33 the shared public deck library,87 format search,173 deck-display research,435 symbol assets/meaning. No duplicate full deck database/index or upstream-PC deployment is planned. Full-story ownership/status is not silently changed by this pilot.

**Pilot defaults chosen under Bill's authorization:** use a clearly bounded public snapshot and three native entry points; our own labeled SCOMPLINK pilot, not the PC production service. Keep Wiki broad-search navigation, GEMP's selected play context and existing editing flow, and a quick SCOMPLINK lookup. Common queries cover symbol identity/aliases/roles, typed uniqueness, and real deck membership/counts. No hidden game state or private saved decks enter the public snapshot. Role/type/unknown/empty cases and native regressions are acceptance tests.

**Acceptance addition for this story:** consume or interoperate with449's pinned query/data contract, preserve context/date/version identities and source links, and retain a concrete coverage/gap ledger. The pilot does not by itself satisfy this story's full rollout AC. Archive.org hold remains absolute; metadata/backups may proceed but no request, capture or preservation-completion claim is allowed.

For87, format-search output should use the same format/card identities and explicit text/date context as449 and32. A card existing in the catalog, being format-legal and being implemented are separate facts. Keep the LOTR-format UI benefits without assuming Wiki histories come from the engine alone.
