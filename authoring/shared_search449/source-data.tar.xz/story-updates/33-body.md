> Spec per [docs/SPEC-PROCESS.md](https://github.com/swccg-guild/work/blob/main/docs/SPEC-PROCESS.md). **Status: Backlog.** Filed by Alpha5 from Bill's voice notes (2026-11-01, about 10:50 PM UTC-4). It can't move to Ready until the open questions are answered and the plan is filled in. **No coding, page edits or server changes before Ready.**

Related: #9 (era-accurate decklists), #32 (ScompLink: our own card search)

### Bill's words (verbatim, voice dictation, 2026-11-01)

> Another user story after this is tournament decklist. So we have tournament decklist. In our wiki. Could we make it so that, you know, in Scumplink we could... see tournament deck lists? Like, could Scumplink also be a source for filtering just if I just want to see tournament deck lists easy, or is that too... too much? within GIMP... itself, we have a library, right? But what... the library itself... enabled us to... have like folders... and we could, you know, grab... any year we wanted, any major tournament, any world championship, local tournament, whatever. And just grab a deck list that way. We've saved everything on the wiki. We should make sure that these deck lists are accessible in a convenient database form, so that the wiki can have it, so that GIMP could have it, so that if we wanted to, I'm not saying we need to, so that a version of Scumplink... could have it too. So... think about that.

(Chief's reading, not Bill's words: "Scumplink" = ScompLink / Scomp, scomp.starwarsccg.org; "GIMP" = GEMP.)

### User story

As a player, I want every tournament decklist we saved on the wiki to be available in one convenient database, so that the wiki can show it, GEMP's deck library can offer it in folders (any year, Worlds, major or local tournament) to grab and play, and, if we decide to, a version of ScompLink could show it too.

### Requirements

- R1 **One shared decklist database** built from the wiki decklist pages ("We've saved everything on the wiki"). Each deck record has at least: page title, player, event, event date or year, event type (Worlds / major / local / other), format, side, starting card or objective, card list (card ID + count), and its source citation. Exact fields are fixed in the plan.
- R2 **Card IDs, not just names:** every card in a record maps to a GEMP blueprint ID (side-correct, per the swccg-wiki-decklists rules). Cards that can't be mapped are listed per deck, never guessed.
- R3 **The wiki can have it:** the database is readable by the wiki (for example for hub tables or a decklist browser), with no change to how decklist pages look today unless Bill asks.
- R4 **GEMP can have it:** GEMP's deck library offers these decks grouped in folders by year and by event type (Worlds, major, local, and so on), and a player can grab any of them and use it, like library decks today.
- R5 **Stays in sync:** when a decklist page is added or changed on the wiki, the database (and GEMP's copy) picks it up on a defined schedule or trigger, without hand edits.
- R6 **ScompLink is optional** ("if we wanted to, I'm not saying we need to"): the database has a documented read format a future ScompLink (#32) could use. Building a ScompLink decklist view is **not** part of this Story.
- R7 Era-accurate card versions (#9) are respected once #9 defines them; until then the record stores the card as the wiki page links it.

### Acceptance criteria

- [ ] AC1 Given the wiki's decklist pages, when the export runs, then a database/export file is produced with one record per deck page that has a decklist, and a report lists every page skipped and why (no decklist section, no side, unmapped cards, and so on).
- [ ] AC2 Given a sample of at least 30 exported decks chosen by the reviewer across eras, when each is compared with its wiki page, then player, event, format, side and every card count match.
- [ ] AC3 Given an exported deck, when its card IDs are loaded into GEMP, then GEMP opens it with the same card counts as the wiki page; any card GEMP doesn't have is listed, not dropped silently.
- [ ] AC4 Given GEMP's deck library on Test, when a player opens it, then tournament decks appear in folders by year and by event type (Worlds, major, local, other), and the player can pick one and start a game with it. Screenshot attached.
- [ ] AC5 Given a decklist page is created or edited on the wiki, when the sync runs, then the database and GEMP's library show the change within the agreed interval (Q4). Test log attached.
- [ ] AC6 Given the database, when a wiki page or tool reads it, then at least one wiki use works (for example a list of decks for one event generated from the database). Screenshot attached.
- [ ] AC7 Given the read format is documented, when a reviewer reads the doc, then a future ScompLink (#32) could filter decks by year, event type, format, side and card without new fields. (Doc only; no ScompLink build.)
- [ ] AC8 GEMP gates pass (named tests + full suite, PR linked) and wiki gates pass for any wiki edit. Deployed to Test and verified, then to Play and verified.
- [ ] AC9 Given the export runs, when it finishes, then a gap report lists every exported deck page missing an Event line or card links (CardLink IDs), with the page name and what is missing; these pages are not skipped. Fixing them on the wiki is a separate follow-up Story.

### Out of scope

- A decklist view inside ScompLink (optional; would be its own Story under #32 if Bill wants it).
- Adding or fixing decklists on the wiki (the existing wiki workflow).
- Era-accurate card versions themselves (#9).
- Changing the look of wiki decklist pages.

Follow-up: wiki backfill Story (fill missing Event lines and card links on the wiki pages listed in the AC9 gap report; not filed yet).

### Analysis: "is that too much?" (Alpha5, 2026-11-01)

Facts checked today (read-only):

- **Wiki:** Category:Decklists has **17,974** article pages (API `categoryinfo`). Category:Dark Side decks has 3,378 and Light Side decks 3,408; Category:Championships 927. Not every page is a tournament deck: some are published constructed lists (for example fan-site decks with no event).
- **Page structure:** pages follow one skeleton (`== Deck info ==` bullets for Player / Event / Format / Side / Starting card / GEMP Importable deck, then `== Decklist ==` with `* Nx {{CardLink|…}}` lines; rules in the swccg-wiki-decklists skill). In a random sample of 300 pages: 298 had a Decklist section, 241 a Side line, 151 an Event line, 201 used CardLink, 166 had a GEMP Importable deck file, and all 300 cited a source. So the data is regular but not complete: about half have no Event line and about a third no CardLink IDs (sample estimate).
- **Existing data files:** many decks were built from per-batch JSON in `billbisco/swccg-wiki/authoring/` (for example `decktech-live.json`, `pc-pdf-old/out/`) by build scripts, but there is no single deck database today.
- **GEMP library today** (`billbisco/swccg-gemp` @ bf6a415): the "Deck Library" is the decks saved under a special `Librarian` player in GEMP's `deck` table (`DbDeckDAO`, `DeckRequestHandler` `/deck/libraryList` and `/deck/library`). The list is flat, split only into Dark / Light / other and filtered by format. **There are no folders.** The in-app help says it holds "starter decks, past championship decks, and more".

View:

- **Not too much, if the wiki stays the source of truth** and the database is a **generated export** (wiki pages → parser → JSON/SQLite file, card names mapped to GEMP IDs through the existing `Card:<id>` redirects). Editors keep editing wiki pages as today; nothing has to be entered twice. The reverse (database first, wiki generated) would change the whole wiki workflow and is not recommended.
- **Sync:** re-run the export on a schedule or from recent changes in Category:Decklists, then load changed decks into GEMP's library.
- **Rough effort (estimates, not commitments):**
  - Export + card-ID mapping + skip report: **M** (the hard part is the ~1/3 of pages without CardLink and the half without an Event line; those need backfill or a lookup from hub pages).
  - GEMP library folders (new grouping in the server list and the deck picker UI) + bulk load: **M**.
  - Sync job: **S**.
  - Wiki use of the data (one generated list): **S**.
  - Optional ScompLink decklist view: **M**, only if Bill wants it, as its own Story under #32.

### Open questions

- Q1 (@Bill): Which decks count as "tournament decklists"? All 17,974 decklist pages, or only decks tied to an event (and include published constructed lists or not)?
- Q2 (@Bill): GEMP folders: is "year, then Worlds / major / local" the right grouping? Who decides which events are "major"? (The wiki has no major/local field today.)
- Q3 (@Bill): GEMP's library today is a flat list with no folders. Did you mean the PC's GEMP, or a library you remember from another app? Either way, OK to add folders to ours?
- Q4 (@Bill): How fresh must the GEMP copy be after a wiki edit: daily, hourly, or on demand?
- Q5 (@Bill): Do you want the ScompLink decklist view at all? It is left out of this Story ("I'm not saying we need to"); say yes and it becomes its own Story under #32.

### Plan

*Draft by Alpha6, 2026-11-03. Parts marked (depends on Qn) are final once Bill answers.*

- **Approach:**
  1. An export script reads the wiki decklist pages in scope (default: decks tied to an event (depends on Q1)) through the API. It parses Deck info and Decklist, maps cards to GEMP ids through the `Card:<id>` redirects and CardLink targets, and writes JSON/SQLite plus skip and gap reports.
  2. GEMP: add folder grouping to the Deck Library (year → event type (depends on Q2/Q3)) and a bulk loader that imports exported decks under the Librarian account.
  3. A sync job re-exports changed pages from recent changes (daily by default (depends on Q4)) and reloads them into GEMP.
  4. One wiki use (a generated deck list for one event), plus a documented read format for a possible ScompLink view (doc only (depends on Q5)).
- **Repos / files touched:** `billbisco/swccg-wiki` (export tool, read-format doc), `billbisco/swccg-gemp` (library folders in `DeckRequestHandler`/`DbDeckDAO` and the deck picker UI; loader), the VPS (sync job), swccg-guild/work `evidence/33/`.
- **Breakdown (Tasks):** export + mapping; GEMP folders; sync; wiki use.
- **Risks / needs-bill approvals:** a new scheduled job on the VPS (cron/systemd = config change, `needs-bill`); GEMP DB load size (thousands of library decks); about a third of pages have no CardLink ids and about half no Event line (AC9 gap report; the backfill is a separate Story).
- **Verification (one line per AC):**
  - AC1: export file summary plus `evidence/33/skip-report.csv`.
  - AC2: `evidence/33/sample-30.csv` comparing 30 decks chosen by the reviewer across eras with their wiki pages, with 0 mismatches.
  - AC3: GEMP load-test output for exported decks, with card counts equal and missing cards listed.
  - AC4: Test screenshot of the library folders (year → event type (depends on Q2)), plus a game started from one deck.
  - AC5: a sync test log showing an edited sandbox deck appearing in the export and in GEMP within the agreed interval (depends on Q4).
  - AC6: screenshot of the wiki list generated from the database for one event.
  - AC7: a link to the read-format doc, with a filter example by year, event type, format, side and card.
  - AC8: PR link, named tests, full-suite log, wiki gate output, and Test then Play deploy evidence.
  - AC9: `evidence/33/gap-report.csv` listing pages missing an Event line or card links.

### Evidence required

In `evidence/<this ticket>/`: the export file summary and skip report (AC1), the 30-deck comparison table (AC2), GEMP load test output (AC3), library-folder screenshots on Test and Play (AC4), the sync test log (AC5), the wiki-use screenshot (AC6), the read-format doc link (AC7), PR links and test logs (AC8), the gap report (AC9).

### Design log

Not required for a Story; the source-of-truth and format decisions are recorded in a comment (and in a design log if this is split into an Epic).

### Area

Wiki (source of truth) and GEMP (library)


## 14 November2026 — accepted shared-search direction and bounded pilot

Bill approved the holistic assessment, instructed updating existing stories, creating gaps, and proceeding with a small live Wiki/GEMP/SCOMPLINK pilot covering symbols, uniqueness and decklists containing a card. He explicitly authorizes first-principles judgment, including contradicting earlier assumptions where useful. [Assessment](https://github.com/swccg-guild/work/blob/main/evidence/435/search-design/search-and-display.md).

**Guiding principles:** optimize trustworthy answers and the user's job; share identities and public card-filter meanings rather than forcing all screens, defaults, data ownership or private filters to match. Preserve catalog/publication/text-state identity, provenance and unknowns. Distinguish release product, printed symbol and a symbol referenced in game text. The same public query over the same snapshot/scope should match; genuinely different scopes should be explicit. Faithful symbols and searchable/copyable semantic text can coexist.

**Implementation split:** [449](https://github.com/swccg-guild/work/issues/449) owns the small cross-system live pilot; [450](https://github.com/swccg-guild/work/issues/450) owns connected Wiki discovery beyond cards; [451](https://github.com/swccg-guild/work/issues/451) owns GEMP Current deck/My decks scopes. Existing32 remains the full public card-filter rollout,33 the shared public deck library,87 format search,173 deck-display research,435 symbol assets/meaning. No duplicate full deck database/index or upstream-PC deployment is planned. Full-story ownership/status is not silently changed by this pilot.

**Pilot defaults chosen under Bill's authorization:** use a clearly bounded public snapshot and three native entry points; our own labeled SCOMPLINK pilot, not the PC production service. Keep Wiki broad-search navigation, GEMP's selected play context and existing editing flow, and a quick SCOMPLINK lookup. Common queries cover symbol identity/aliases/roles, typed uniqueness, and real deck membership/counts. No hidden game state or private saved decks enter the public snapshot. Role/type/unknown/empty cases and native regressions are acceptance tests.

**Acceptance addition for this story:** consume or interoperate with449's pinned query/data contract, preserve context/date/version identities and source links, and retain a concrete coverage/gap ledger. The pilot does not by itself satisfy this story's full rollout AC. Archive.org hold remains absolute; metadata/backups may proceed but no request, capture or preservation-completion claim is allowed.

For33, model deck occurrence/revision, counted entries, exact versus family identity, actual zones/setup roles, player/event/format/date/source and completeness. An incomplete list cannot prove a card absent. Reuse existing Wiki records/downloads as sources; starting cards displayed separately must not be counted again. Keep as-played history separate from a modern compatible import and surface unsupported mappings.
