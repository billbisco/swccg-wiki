> Spec per [docs/SPEC-PROCESS.md](https://github.com/swccg-guild/work/blob/main/docs/SPEC-PROCESS.md). **Status: Backlog.** Filed by Alpha11 from Bill's voice notes (2026-11-01, 10:50 PM UTC-4). It can't move to Ready until the open questions are answered and the plan is filled in. **No coding, page edits or server changes before Ready.**

Related: #11 (game rule options; filter by rule set / errata choice).
Related: #9 (era-accurate decklists; card versions by date).
Related: #5, #6, #7 (Virtual Legacy and errata stories; #7 supplies the errata'd versions the errata filter needs to be complete).
Related: #33 (tournament decklists in one shared database; optional ScompLink source).

### Bill's words (verbatim voice dictation, 2026-11-01 10:50 PM UTC-4; "GIMP" = GEMP, "Scumplink" / "Scomplink" = ScompLink / Scomp)

> Another user story is "ScompLink". We wanna update this. version for ourselves. We want it to do more things. For instance, I should be able to filter on more things. I should be able to filter on things that, based like, like uniqueness, right? So whatever I can filter with on Scumplink is something I should be able to filter on within GIMP. Whatever I can filter something on GIMP, I should be able to filter on Scumplink, right? I should be able to filter pretty much on almost anything I want to, right? We should make it really, really, really easy, right? That's, that's the goal here. https://scomp.starwarsccg.org/  We want our version to be better than the player's committee.  We should think about the important things Scomplink does:  Enable easy  card searching and filtering and keep that easiness level there and do better.  In my mind, we should also make it easier to filter by errata as well.

From the next story (tournament decklists, tracked in its own Story), the sentences about ScompLink:

> Could we make it so that, you know, in Scumplink we could... see tournament deck lists? Like, could Scumplink also be a source for filtering just if I just want to see tournament deck lists easy, or is that too... too much?

> We should make sure that these deck lists are accessible in a convenient database form, so that the wiki can have it, so that GIMP could have it, so that if we wanted to, I'm not saying we need to, so that a version of Scumplink... could have it too.

Bill (2026-11-03, 5:28 AM, answer to CardMaker #40 Q3, which applies to filters):

> I don't understand this question.  If a character is a Rebel; they are a Rebel.  If a character is an Alien; they are an alien.  It is possible for a character to be 2 types: Ex.  Imperial and Alien.  And so for cards that  disriminate based on type, they would check both boxes for better or for worse

### User story

As a player, deck builder or editor, I want our own ScompLink card search, better than the Players Committee's Scomp, so that I can search and filter cards on almost anything (including uniqueness and errata) as easily as today, with the same filters available in GEMP.

### Goal

Our own version of ScompLink that keeps what Scomp does well (easy card searching and filtering), keeps that easiness, and does better: filter on more things (pretty much almost anything, e.g. uniqueness), two-way filter parity with GEMP, and easier errata filtering.

### What the live Scomp has today (read-only look at https://scomp.starwarsccg.org, 2026-11-01)

- **Basic search:** Side (Any / Light / Dark); Type (Any, Admiral's Order, Character, Creature, Defensive Shield, Device, Effect, Epic Event, Interrupt, Jedi Test, Location, Objective, Podracer, Starship, Vehicle, Weapon); search field (Any / Title / Abbreviation / Gametext / Lore) plus a text box; Search and Reset Search buttons.
- **Advanced Search builder:** pick any card field, an operator (contains, doesn't contain, >, <, =, <=, >=, not) and a value, then add the condition with AND / OR / NOT. Fields offered: abbreviations, ability, armor, canceledBy, cancels, characteristics, combo, conceptBy, counterpart, darkSideIcons, deploy, destiny, destinyValues, errataDate, errataNotes, errataSymbol, extraText, ferocity, forfeit, gametext, hyperspeed, icons, landspeed, lightSideIcons, lore, maneuver, matching, matchingWeapon, parsec, personas, politics, power, printableSlipType, printableSlipUrl, pulledBy, pulls, rarity, rulings, set, side, subType, title, type, underlyingCardFor, uniqueness.
- **Display / options:** Text-Only Display, Show Text Instead of Images, Include Legacy Cards.
- **Results:** a table of Card Name, Side, Set, Type, Sub Type, Rare, Destiny, plus a card detail panel (type/subtype, destiny, power, ability, maneuver, armor, deploy, pulls, extra card data).
- **Export:** Export Light CDF, Export Dark CDF, Export SWIP.

Uniqueness and the errata fields can only be reached through the Advanced Search builder (free-text field + operator), not through simple pickers.

### What GEMP's deck builder filters on today (read from our GEMP source, card filter panel)

Side; Format (Open, Classic, Legacy, Premiere-era formats, etc.); Set; Card type (including subtypes, e.g. Character - Alien, Effect - Immediate, Starship - Capital); Rarity (including "any Common / Uncommon / Rare"); Product (cards, foil / non-foil, Virtual AI cards, packs/boxes); Sort by (title, card category, card type); Title contains; Lore contains; Gametext contains; Icon (e.g. Episode I, Grabber, Pilot, Scomp Link, Virtual set icons); Persona; numeric compare (=, >, >=, <, <=) on Destiny, Power, Ability, Deploy, Forfeit, Armor, Defense value, Maneuver, Hyperspeed, Landspeed.

Seen in one and not the other (examples): GEMP has Format, Product, Persona, Icon, Defense value and type subtypes as pickers; Scomp has uniqueness, errata fields, counterpart, pulls/pulledBy, cancels/canceledBy, matching/matchingWeapon, characteristics, politics, ferocity, parsec, rulings, AND/OR/NOT combinations and CDF/SWIP export. The full gap list is a Plan deliverable.

### Requirements

- R1 Our own ScompLink card search, a version for ourselves that does more than the Players Committee's Scomp ("better than the player's committee").
- R2 Keep what Scomp does well: easy card searching and filtering. It must stay "really, really, really easy": the common searches take no more effort than on Scomp today.
- R3 Filter on more things, "pretty much on almost anything", including **uniqueness** as a simple filter.
- R4 **Two-way parity with GEMP:** whatever can be filtered on in ScompLink can be filtered on in GEMP, and whatever can be filtered on in GEMP can be filtered on in ScompLink.
- R5 **Easier errata filtering** (exact meaning: Q3).
- R6 Everything Scomp offers today (basic search, advanced builder, display options, Legacy cards, exports) is still available, or dropping it is agreed with Bill (Q6).
- R7 **Several types per card:** a card with more than one type (for example a character that's both Imperial and Alien) matches a filter on each of its types.

### Acceptance criteria

- [ ] AC1 Given the gap list (Plan), then every filter in today's Scomp and every filter in GEMP's deck builder is listed with where it will live in ScompLink and in GEMP; Bill or Chief signs off on it.
- [ ] AC2 Given ScompLink, when a user picks a uniqueness value from a list (the values come from our card data), then only matching cards are shown, without typing an advanced condition.
- [ ] AC3 Given every filter in the agreed gap list, when it is used in ScompLink, then the same filter exists in GEMP's deck builder and returns the same cards for the same card pool (spot-check script or test over a fixed card list), and vice versa.
- [ ] AC4 Given errata filtering (per Q3), when a user filters for errata'd cards, then the matching cards are shown with simple controls (no hand-typed field names).
- [ ] AC5 Given the common searches (title text, side + type, gametext text), when done in ScompLink, then they take no more clicks or typing than on Scomp today. Side-by-side screenshots or a short click count.
- [ ] AC6 Given every Scomp feature listed above, then it is present in ScompLink or its removal is recorded with Bill's OK.
- [ ] AC7 Gates for the areas touched pass (GEMP tests green and PR linked for the GEMP side). Deployed to Test and verified, then to Play and verified.
- [ ] AC8 Given a two-type character (for example •Garindan, Imperial Spy: Alien/Imperial), when a user filters on Imperial and then on Alien, in ScompLink and in GEMP's deck builder, then the card appears in both results each time. Screenshots attached.

### Out of scope

- Tournament decklists in ScompLink (Bill: "I'm not saying we need to") — that belongs to the tournament decklist database Story; this Story only shouldn't block it.
- New card data or errata research (the errata stories #5–#7).
- Changing the Players Committee's Scomp.

### Open questions

- Q1 (@Bill): Where should our ScompLink live (URL, e.g. under swccg.com), and what's it called: "ScompLink" or another name?
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** Where should our card search live, and what should it be called? Example: `swccg.com/scomp` or `search.swccg.com`, named "ScompLink" or "Card Search". **Suggested default:** `swccg.com/scomp`, named ScompLink.
- Q2 (@Bill): Card data source: our GEMP card data, the wiki, or the same card data Scomp uses? Parity (R4) is easiest if ScompLink and GEMP read one source.
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** Where does the card search get its card data? Example: GEMP's card files (what games use), the wiki, or Scomp's own data. **Suggested default:** GEMP's card data, the one source of truth, so search results always match GEMP (same rule as the RG text source, #50).
- Q3 (@Bill): What does "easier to filter by errata" mean: show only cards that have errata, filter by errata date, choose pre- or post-errata versions (ties to #9 and #11), or all of these?
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** What does "easier to filter by errata" mean? Example: show only cards that have errata; show cards errata'd in 2001; or pick the old (pre-errata) or new text of Projected Telepathy. **Suggested default:** all three, starting with "has errata" plus old or new text.
- Q4 (@Bill): "Almost anything": any filters you want beyond Scomp's field list and GEMP's (e.g. lore keywords, characteristics as pickers, legality by format / date)?
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** Beyond what Scomp and GEMP filter today, what else do you want to filter on? Example: lore words ("spy", "leader"), characteristics from a pick list, or "legal in a format on a date". **Suggested default:** characteristics as a pick list, plus legal-by-format; more later.
- Q5 (@Bill): Parity edge cases: GEMP filters that are about the player's collection (Product: foil, packs/boxes, Virtual AI) — do these need to be in ScompLink? And Scomp's AND/OR/NOT advanced builder and CDF/SWIP export — do these need to be in GEMP's deck builder?
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** Some filters only make sense in one place. Do they need to be in both? Example: GEMP's "foil" or "in my collection" filters in the card search; Scomp's AND/OR/NOT builder and deck export in GEMP. **Suggested default:** no: collection filters stay in GEMP only, and the advanced builder and exports stay in ScompLink only.
- Q6 (@Bill): Can any Scomp feature be dropped, or must ScompLink keep all of them?
  - **In plain terms (Alpha5 triage, 2026-11-03 UTC-4):** Can we drop any Scomp feature? Example: the old display options, or the CDF/SWIP export. **Suggested default:** keep everything; anything dropped later needs your OK.
- Q7 (@Chief): Is this one Story, or should it split (ScompLink site; GEMP deck-builder filter additions) once the gap list exists?
  - Answer (decided by Chief, 2026-11-01): Yes, later. This Story will split into a ScompLink site Story and a GEMP filter-additions Story once the gap list exists. No new ticket until then. (Alpha11)

### Plan

*Draft, Alpha5, 2026-11-03 UTC-4. Steps marked "depends on Qn" wait for Bill (Q7 waits for Chief). Stays in Backlog.*

- **Approach:**
  1. Write the filter gap list first (AC1): every filter in Scomp and in GEMP's deck builder (`src/gemp-swccg-async/src/main/web/js/gemp-016/cards/CardFilter.js`, `deckBuildingUi.js`, `deckBuild.html`), with where each will live.
  2. Build ScompLink on one card-data source shared with GEMP.
  3. Add the missing filters to GEMP's deck builder.
  4. Write a parity test that runs the same filters over a fixed card list on both sides.
- **Repos / files touched:**
  - `billbisco/swccg-gemp`: deck-builder filters.
  - ScompLink site: location **depends on Q1**.
  - `swccg-guild/work`: gap list, evidence, and `docs/design-log/32-scomplink.md` if a decision is needed.
- **Breakdown (Tasks):**
  - T1 Gap list, signed off by Bill or Chief.
  - T2 Card-data source: **depends on Q2**.
  - T3 Errata filters: **depends on Q3**.
  - T4 Extra filters such as characteristics and legality by format: **depends on Q4**.
  - T5 Collection, export and builder parity edges: **depends on Q5**.
  - T6 Keep or drop each Scomp feature: **depends on Q6**.
  - T7 Uniqueness pick-list and two-type matching (AC2, AC8).
  - T8 Parity test (AC3).
  - T9 Click-count comparison (AC5).
  - T10 Split into a site Story and a GEMP Story after T1: **depends on Q7 (Chief)**.
- **Risks / needs-bill approvals:**
  - A new public site or subdomain is server configuration (`needs-bill`).
  - Two code bases drifting apart; the shared data source and the parity test guard against it.
- **Verification (one line per AC):**
  - AC1: the gap list with the sign-off comment linked.
  - AC2, AC4: screenshots.
  - AC3: parity test output in `evidence/32/parity.txt`.
  - AC5: a side-by-side click count.
  - AC6: a feature checklist against the Scomp list in this ticket.
  - AC7: GEMP test log and PR link, then Test and Play screenshots.
  - AC8: Garindan screenshots from both tools.

### Evidence required

- Gap list document (AC1)
- Screenshots of the uniqueness and errata filters and matching results in ScompLink and GEMP, on Test and on Play (AC2, AC4)
- Parity check output (AC3); click-count comparison (AC5); feature checklist (AC6)
- PR links and deploy evidence (AC7)

### Design log

Data-source and parity decisions go in a comment and in `docs/design-log/<n>-scomplink.md` if the plan needs one.

### Area

Site (also GEMP, for the deck-builder side of the parity requirement)





## 14 November2026 — accepted shared-search direction and bounded pilot

Bill approved the holistic assessment, instructed updating existing stories, creating gaps, and proceeding with a small live Wiki/GEMP/SCOMPLINK pilot covering symbols, uniqueness and decklists containing a card. He explicitly authorizes first-principles judgment, including contradicting earlier assumptions where useful. [Assessment](https://github.com/swccg-guild/work/blob/main/evidence/435/search-design/search-and-display.md).

**Guiding principles:** optimize trustworthy answers and the user's job; share identities and public card-filter meanings rather than forcing all screens, defaults, data ownership or private filters to match. Preserve catalog/publication/text-state identity, provenance and unknowns. Distinguish release product, printed symbol and a symbol referenced in game text. The same public query over the same snapshot/scope should match; genuinely different scopes should be explicit. Faithful symbols and searchable/copyable semantic text can coexist.

**Implementation split:** [449](https://github.com/swccg-guild/work/issues/449) owns the small cross-system live pilot; [450](https://github.com/swccg-guild/work/issues/450) owns connected Wiki discovery beyond cards; [451](https://github.com/swccg-guild/work/issues/451) owns GEMP Current deck/My decks scopes. Existing32 remains the full public card-filter rollout,33 the shared public deck library,87 format search,173 deck-display research,435 symbol assets/meaning. No duplicate full deck database/index or upstream-PC deployment is planned. Full-story ownership/status is not silently changed by this pilot.

**Pilot defaults chosen under Bill's authorization:** use a clearly bounded public snapshot and three native entry points; our own labeled SCOMPLINK pilot, not the PC production service. Keep Wiki broad-search navigation, GEMP's selected play context and existing editing flow, and a quick SCOMPLINK lookup. Common queries cover symbol identity/aliases/roles, typed uniqueness, and real deck membership/counts. No hidden game state or private saved decks enter the public snapshot. Role/type/unknown/empty cases and native regressions are acceptance tests.

**Acceptance addition for this story:** consume or interoperate with449's pinned query/data contract, preserve context/date/version identities and source links, and retain a concrete coverage/gap ledger. The pilot does not by itself satisfy this story's full rollout AC. Archive.org hold remains absolute; metadata/backups may proceed but no request, capture or preservation-completion claim is allowed.

For full32, public card-metadata filter parity is the goal; GEMP-private collection controls and exports/actions need context-appropriate behavior, not identical widgets. Source authority is a shared catalog with explicit field provenance, not an assumption that engine data describes every historical printing. Preserve existing basic/advanced/export capabilities while testing improvements. Existing open questions are retained historically; the pilot choices above resolve its bounded scope without blocking on a future public hostname or full rollout decision.
