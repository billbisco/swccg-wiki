> Spec per [docs/SPEC-PROCESS.md](https://github.com/swccg-guild/work/blob/main/docs/SPEC-PROCESS.md). **Status: In Progress — research expanded following Bill’s feedback.** Research and locally viewable static design demonstrators; no production product changes are authorized by this Story.

Related: #33 (shared database from wiki decklists feeding the wiki and GEMP library). This Story owns research on how readers discover and view decks, and where those views should live; it does not duplicate #33's database/export or GEMP-library implementation.

### Background

Bill asked for research into ways to display decks on the SWCCG wiki and whether the swccg.com website could offer another option. Ketura's user-provided Discord message describes Red Book as a DeckTech successor being developed with a reported archive of 9,245 decks from Decipher forums, DeckTech, GamePlayersNetwork, TLHH and CC. The stated plan includes search, comments, GEMP export, user-submitted decks, historical events and tournament reports. Ketura estimated it may take a couple of months to prepare. These are attributed claims, not independently verified facts or commitments.

The provided screenshot illustrates a possible deck page with card images, draw testing/statistics, author notes and comments. Treat it as an example, not as a required design or proof that Red Book is available.

### User story

As a SWCCG player or historical deck researcher, I want to find and understand historical and modern decks through a clear, searchable, sourced display, so that I can study how decks were built, follow links to the players and events, and use a list in GEMP when an importable version exists.

As the wiki/site maintainer, I want to compare the wiki, swccg.com and Red Book as places to display decks, so that I can choose an approach that serves readers while preserving provenance and avoiding needless duplicate maintenance.

### Requirements

- R1. Inventory the current wiki deck pages, indexes/catalogs, source attribution and GEMP downloads relevant to this decision. Identify demonstrated gaps with examples.
- R2. Assess Red Book only from accessible public evidence or information already provided: confirmed capabilities, stated plans, data/provenance, linking/export options and unknowns must be clearly distinguished.
- R3. Compare wiki-first, Red Book-first, a linked/hybrid model, a swccg.com-hosted view, and minimal cross-linking.
- R4. Assess reader journeys for historical research, finding a deck by player/event/archetype, and taking an available list into GEMP.
- R5. Compare preservation/durability, source attribution, findability, interaction, accessibility/mobile use, moderation, technical feasibility, ownership/maintenance, and failure/offline behavior.
- R6. Keep the relationship to #33 explicit. Recommend how a deck display could consume or link to its work without assuming a shared database, API, partnership, or Red Book access.
- R7. Identify rights/provenance questions before recommending republication or bulk import. Public availability alone is not evidence of republication permission.
- R8. Produce a concise decision memo with evidence, trade-offs, recommendation, unresolved questions, dependencies and a small reversible next step. Do not contact Ketura or other community members without Bill's direction.

### Acceptance criteria

- [ ] AC1. The current-state inventory links concrete wiki deck/index/download examples and distinguishes implemented behavior from planned behavior.
- [ ] AC2. The Red Book assessment labels each item as confirmed, reported/planned, or unknown and cites the evidence available; no integration capability is assumed.
- [ ] AC3. A comparison matrix covers all five options and the R5 criteria, with source links or a short evidence note for each material judgment.
- [ ] AC4. The memo describes the three R4 reader journeys and shows where each option succeeds, fails or depends on another system.
- [ ] AC5. The recommendation states how it relates to #33, what remains the historical source of truth, and what would happen if Red Book or a site integration were unavailable.
- [ ] AC6. Rights, provenance, data quality, maintenance and moderation questions are recorded as open questions where evidence is insufficient; no permission or partnership is implied.
- [ ] AC7. The memo recommends one reversible next step and names any follow-up Stories/Tasks; no implementation, import, outreach or wiki changes are included in this Story.

### Out of scope

- Production implementation or deployment of a deck interface, API, integration or sync. Bill separately authorized a local static UI prototype as a research demonstrator.
- Importing or copying Red Book's reported archive or its commentary.
- Bulk-editing wiki deck pages or changing the current wiki deck layout.
- Contacting Ketura/community members, agreeing to a partnership, or asserting reuse rights.

### Open questions — append answers, never delete

- Q1 (@Bill): Should the eventual recommendation treat Red Book as a potential partner/data source only if its maintainers confirm availability and terms, or should the evaluation limit itself to public linking and user workflows? Research should document the distinction either way.
  - **Answer (Bill, 2026-11-05):** Red Book is Ketura’s own decklist site, currently being built and not yet public. Partnership is not a concern for this research. The screenshot is a design idea/reference to include alongside research into other deck displays; it is not a live product or integration requirement.
- Q2 (research): What concrete public Red Book demo/documentation and export/link behavior can be verified? If inaccessible, record the evidence gap and keep the option conditional.
  - **Answer (research):** Per Bill’s clarification, Red Book is in development and not public yet. The Discord message reports planned capabilities, and the screenshot is a design reference; there is no live product behavior to verify. The memo compares it as a prospective deck site without assuming its future behavior.
- Q3 (research): Which wiki deck sources and downloadable formats are most representative for historical and modern reader journeys? Select examples during research and explain the selection.
  - **Answer (research):** The memo uses the 1996 Worlds page with conflicting transcriptions and a GEMP download, the 2026 Worlds event/forum files and correction trail, and a DeckTech archive entry, explaining their relevance in the memo.

### Plan

1. Read-only audit of existing wiki deck display/index patterns and #33's scope.
2. Inspect available Red Book public materials and the supplied screenshot; separate observed interface from reported plans.
3. Map the reader journeys and compare the five options against R5.
4. Write the decision memo and proposed next step; update this Story with the evidence and recommendation.

### Plan details

- **Approach:** Research and decision memo only; preserve links to evidence and avoid assumptions about external access or integration.
- **Repos/surfaces:** swccg-guild/work (this Story and evidence); wiki.swccg.com; swccg.com; the user-provided Red Book Discord description and screenshot; public deck-site comparators; #33 for dependency/scope comparison.
- **Breakdown:** No child work is planned until the recommendation identifies a concrete implementation path.
- **Risks:** Red Book is not public yet, so its reported count and planned behavior cannot be independently verified; future availability is unknown. The wiki and swccg.com catalog scopes differ, so counts should not be treated as unique-deck totals.
- **Verification, mapped 1:1 to acceptance criteria:**
  - AC1 — `evidence/173/deck-display-research.md`, “Current SWCCG surfaces”; linked catalog, 1996 Worlds record and sources/download behavior.
  - AC2 — same memo, “Red Book evidence boundary”; evidence-level table separates Bill-confirmed context, Ketura-reported plans/count, screenshot-observed ideas and unknown live behavior.
  - AC3 — same memo, “Display options”; five-option matrix evaluates preservation, attribution, findability, interaction, accessibility/mobile, moderation, feasibility/ownership and failure/offline behavior, with evidence notes.
  - AC4 — same memo, “Reader journeys across the five options”; compares historical research, finding by player/event/archetype and taking a list into GEMP across all five options.
  - AC5 — same memo, recommendation and failure/offline analysis; establishes the wiki record as historical source, relates the website view to #33, and does not depend on Red Book.
  - AC6 — same memo, “Open questions / evidence gaps”; records source rights, provenance, data quality, moderation and scope as unresolved where evidence is insufficient; no permission or partnership is implied.
  - AC7 — same memo, “Proposed next step”; recommends a reversible storyboard and identifies a conditional follow-up implementation Story, without creating or implementing it in #173.

### Evidence required

Add the decision memo and any small supporting comparison/reader-journey artifacts under evidence/<this ticket>/ in swccg-guild/work, and link them from the issue.

### Delivered research

- [Decision memo](https://github.com/swccg-guild/work/blob/main/evidence/173/deck-display-research.md)
- [Desktop/mobile storyboard, example walkthroughs and proposed first release](https://github.com/swccg-guild/work/blob/main/evidence/173/deck-display-storyboard.md)

The initial completion report is superseded. Expanded analytical research and a revised static demonstrator are delivered below; this Story remains open for research/design review. No production implementation is authorized.


### Research correction — Bill, 2026-11-05

The previous PASS report and completion are superseded. Bill requested deeper primary-source research into ThronesDB and MTG Arena deck displays, useful deck metadata, and SWCCG-specific analysis such as destiny curves. Study decklist uses, quantities/composition, economy, starting setup, draw probability, context-sensitive statistics and succinct presentation. The supplied Red Book screenshot includes statistics and must be considered in that analysis. Produce a research addendum and revise the static prototype as a design demonstrator. This remains a research Story; no live product deployment is requested.

### Expanded analytical research evidence — 2026-11-05

- [Deep deck-analysis research: primary-source comparisons, decklist uses, metadata model, calculations and limitations](https://github.com/swccg-guild/work/blob/main/evidence/173/deck-analysis-research.md).
- Added scope: destiny distribution and threshold probabilities, scoped base deploy demand, composition and roles, starting/setup populations, exact opening-hand probability, source/text-state coverage, and succinct desktop/mobile presentation.
- ThronesDB: operated a real deck's draw/odds tools and inspected pinned chart/simulator source. Arena: studied official builder footage/screenshots and Deck Details design notes; the current native Deck Details modal was not operated. CardCastle, Deckstats, Untapped, historical SWCCG strategy, rules, and SWCCGDB code add comparison evidence, with access limits recorded.
- Local static demonstrator revised with quantity-weighted calculations, full/post-setup selector, clickable destiny bars, threshold control, deploy/type summaries and an auditable per-card data table. This is a 20-card analytical fixture, not a legal tournament deck or validated GEMP export.
- Independent numerical checks pass: full pool 20, destiny sum 28, mean 1.40; after one starting location 19, mean 28/19; two-copy opening-eight probability 65.2632% and 67.8363% respectively. Zero/unknown distinction, decimal values and copy weighting checked.

Research review must assess the analytical model and presentation as well as hosting/discovery. No final design approval or production readiness is claimed.

### Real-deck gallery requirements — Bill, 2026-11-05

Bill requested deckbuilder/display examples using actual full 60-card wiki lists, a couple from the 2026 Retro GEMPC and a couple from the 2026 World Championships, with regular/light and dark versions of every example. This supersedes the earlier 20-card demonstrator.

- [x] AC8. Four complete source decks are shown: Timo Dusel's Ralltiir Operations and Hidden Base (Retro GEMPC), and Brian Fred's ISB Operations and Diplomatic Mission To Alderaan (Worlds Top 8). Each 60-card blueprint/quantity multiset matches its original wiki-hosted GEMP XML. Outside cards remain separate.
- [x] AC9. All four examples work in regular/light and dark modes in all three proposed layouts; a side-by-side theme comparison is included. 24/24 rendered combinations checked.
- [x] AC10. Readers can compare a compact reader, visual card stacks and builder workbench, with source links, card inspection and calculated destiny/deploy/composition/hand tools. Builder edits are local drafts; reset restores the actual list.

[Real-deck gallery evidence, source links and verification](https://github.com/swccg-guild/work/blob/main/evidence/173/real-deck-gallery.md). Local gallery and theme-comparison pages are delivered in chat. The finder uses the same-side subset from these source decks; it is a prototype, not a complete production card database. Story remains open as research.

### Live wiki test — authorized by Bill, 2026-11-05

Bill requested a Test wiki page duplicating the website gallery for full-functionality comparison. This explicitly authorizes the isolated wiki sandbox and its scoped component loader, without a production deck-page rollout.

- [x] AC11. The [native wiki test](https://wiki.swccg.com/wiki/User:Memory_Core_ChatGPT/Deck_display_test) includes the same four real 60-card decks, all three layouts and both themes. All 24 combinations pass live anonymous-reader checks.
- [x] AC12. Live wiki controls provide the website's deck/card filtering, destiny/deploy/composition charts, threshold and opening odds, setup selection, card inspection, sample hands, copy/download links, local builder edits/reset and regular/dark comparison. Interaction checks and independent results are recorded.
- [x] AC13. Component styles and loading are isolated to the test page; an ordinary source deck article retains its prior display. Native comparison has no iframe or localhost dependency; the narrow-screen builder fits a 390-pixel viewport. Wikitext lint/parse and JavaScript syntax checks pass; edited pages and sources are backed up.

[Parity verification and changed-page revisions](https://github.com/swccg-guild/work/blob/main/evidence/173/wiki-website-parity.md) · [Wiki light/dark comparison](https://wiki.swccg.com/wiki/User:Memory_Core_ChatGPT/Deck_display_test?compare=1&deck=worlds-brian-ds&layout=visual). The finder and local draft persistence have the same prototype limits on both surfaces. This comparison increment is delivered; the broader research/design Story remains open.


## 14 November2026 — accepted shared-search direction and bounded pilot

Bill approved the holistic assessment, instructed updating existing stories, creating gaps, and proceeding with a small live Wiki/GEMP/SCOMPLINK pilot covering symbols, uniqueness and decklists containing a card. He explicitly authorizes first-principles judgment, including contradicting earlier assumptions where useful. [Assessment](https://github.com/swccg-guild/work/blob/main/evidence/435/search-design/search-and-display.md).

**Guiding principles:** optimize trustworthy answers and the user's job; share identities and public card-filter meanings rather than forcing all screens, defaults, data ownership or private filters to match. Preserve catalog/publication/text-state identity, provenance and unknowns. Distinguish release product, printed symbol and a symbol referenced in game text. The same public query over the same snapshot/scope should match; genuinely different scopes should be explicit. Faithful symbols and searchable/copyable semantic text can coexist.

**Implementation split:** [449](https://github.com/swccg-guild/work/issues/449) owns the small cross-system live pilot; [450](https://github.com/swccg-guild/work/issues/450) owns connected Wiki discovery beyond cards; [451](https://github.com/swccg-guild/work/issues/451) owns GEMP Current deck/My decks scopes. Existing32 remains the full public card-filter rollout,33 the shared public deck library,87 format search,173 deck-display research,435 symbol assets/meaning. No duplicate full deck database/index or upstream-PC deployment is planned. Full-story ownership/status is not silently changed by this pilot.

**Pilot defaults chosen under Bill's authorization:** use a clearly bounded public snapshot and three native entry points; our own labeled SCOMPLINK pilot, not the PC production service. Keep Wiki broad-search navigation, GEMP's selected play context and existing editing flow, and a quick SCOMPLINK lookup. Common queries cover symbol identity/aliases/roles, typed uniqueness, and real deck membership/counts. No hidden game state or private saved decks enter the public snapshot. Role/type/unknown/empty cases and native regressions are acceptance tests.

**Acceptance addition for this story:** consume or interoperate with449's pinned query/data contract, preserve context/date/version identities and source links, and retain a concrete coverage/gap ledger. The pilot does not by itself satisfy this story's full rollout AC. Archive.org hold remains absolute; metadata/backups may proceed but no request, capture or preservation-completion claim is allowed.

For173, retain research/display ownership and references;449 implements the newly authorized bounded search pilot,33 owns public deck data and451 owns native current/saved-deck scope. The research-only restrictions of173 do not become a hidden permission blocker for the separately authorized449 implementation.
